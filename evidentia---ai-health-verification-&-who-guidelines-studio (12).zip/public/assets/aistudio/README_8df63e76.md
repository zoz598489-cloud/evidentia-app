# Evidentia — backend (v1.1)

Backend for **Osler's Hippocrates / Evidentia** (Milestone 2): splits a health post into claims, checks each against a sourced
evidence library, grades the evidence, cross-checks several AI models, and **abstains when evidence is insufficient**.
Four prototype fields: sports injuries, food safety, mental health (teen depression + ADHD), skin diseases. Arabic + English.

* **Zero runtime dependencies**: Python 3.10+ standard library + SQLite. (Optional extras: `requirements-optional.txt`.)
* Includes a **web UI** at `/ui` (no build step, no CDN), a **68-entry** evidence library, structured logging,
  forward-only DB migrations, request validation and abuse protection.

## Run

```bash
./run.sh                                   # or: python3 -m evidentia.server      -> http://127.0.0.1:8000/ui
python3 -m unittest discover -s tests      # 80 tests
python3 scripts/compare_matching.py        # compare matching modes on the built-in sets or your own file
python3 -m evidentia.migrate status        # database migrations (status | up | backup | new NAME)
```

Dev mode prints an ADMIN KEY on start; set `EVIDENTIA_ADMIN_KEY` (>= 16 chars) for anything shared. All settings: `.env.example`.
Docker: `docker build -t evidentia . && docker run -p 8000:8000 -v evidentia:/data -e EVIDENTIA_ADMIN_KEY=... evidentia`
(non-root user, `/health` healthcheck). CI: `.github/workflows/ci.yml` (tests on 3.10-3.12, migrations, coverage, Docker build + smoke test).

## What changed in 1.1 (per the improvement report)

| Report item | What was done | Notes |
|---|---|---|
| 1. Dependencies | `pyproject.toml`, `requirements.txt` (core: none), `requirements-optional.txt`, `requirements-dev.txt` | Optional versions are **ranges**; run `pip freeze > requirements.lock` where you install them. |
| 2. DB migrations | `evidentia/migrations/*.sql` + runner (`db.py`) + CLI (`migrate.py`): checksums, per-migration transactions, automatic backup before changing a database that holds data, refuses a DB newer than the code | Stdlib equivalent of Alembic (Alembic needs SQLAlchemy, which this project does not use). v1.0 databases are adopted with no data loss (tested). |
| 3. Logging & error tracking | JSON logs (`logs.py`), per-request `X-Request-ID`, optional **Sentry** (`SENTRY_DSN`, no PII, scrubbed), admin `GET /metrics` | Logs hold method, route template, status and timing only: never IPs, queries or bodies. loguru/structlog not installed offline; stdlib `logging` is used. |
| 4. Tests | Split per module: `test_nlp`, `test_engine`, `test_server`, `test_experts`, `test_radar`, `test_learning_community`, `test_evaluation`, `test_db_migrations`, `test_logging` | 28 -> 80 tests. Coverage is reported in CI (not measured locally: `coverage` was not installable). |
| 5. Security | CORS **allow-list** (default: none), per-IP rate limits with `Retry-After`, brute-force lockout on admin/expert auth, security headers (+ strict CSP on `/ui`), request timeouts, body/Content-Length checks, `X-Forwarded-For` only when `EVIDENTIA_TRUST_PROXY=1`, schema validation | Validation uses a small built-in validator (`schemas.py`) that reports **all** field errors at once; Pydantic could not be installed offline. Swap it in if you move to FastAPI. |
| 6. CI/CD | `.github/workflows/ci.yml`, `Dockerfile` (non-root + healthcheck), `.dockerignore` | The workflow is syntax-checked but **has not run on GitHub**. |

Your three options: **(a) 22 new library entries** (46 -> 68) in all four fields, each with an Arabic version;
**(b) embeddings** (`EVIDENTIA_EMBEDDINGS=off|ngram|sentence-transformers`); **(c) the web UI**.

## Honest results and limits

* **New library entries are unreviewed.** All 22 start as `pending-expert-review` with organisation-level sources
  (CDC, AAP, AAD, USDA...). 54 of 68 entries are pending in total. Confidence stays reduced until two verified experts agree
  (`POST /reviews`). Please have a qualified person check them before anyone relies on them.
* **Embeddings: no measured benefit yet.** The offline `ngram` mode scored the same as TF-IDF on the built-in sets (8/12 and 20/24,
  0 wrong definitive verdicts in both). `sentence-transformers` could not be installed or run here, so it is **untested**, and its
  calibration constants (`floor`/`ceil` in `embeddings.py`) are guesses. Run `scripts/compare_matching.py` on an expert-confirmed set
  before enabling it. Design rule: embeddings may only *raise* a lexical score, and a claim that names an entity the statement lacks is penalised.
* **Matching got stricter on purpose.** Testing found two real hazards: negation words inside library statements flipped verdicts, and a
  look-alike claim ("A sprain is as serious as a fracture") was endorsed. Fixes: affirmative phrasing is now enforced by a test, negation
  flips need a close match, and any definitive true/false needs `DEFINITIVE_SIM >= 0.5`, otherwise the engine abstains. Lexical matching
  still cannot understand meaning; a real model (see `anthropic` / `openai-compatible`) or an NLI step is the proper next step.
* **Evaluation:** on the provisional 24-claim sample the system gets 20/24 with 0 overconfident errors; the offline stand-in baseline
  gets 18/24 with 6. The accuracy gain is 8.3 pp, so `meets_preregistered_thresholds` is **false** (needs 10 pp). The thresholds were not
  changed. These numbers are not evidence for the hypothesis: the labels are not expert-confirmed and the baseline is not a real AI model.
* **Not verified here:** the UI in a real browser (JS syntax-checked and rendered against real API output with a DOM stub; served with a strict
  CSP), the live Anthropic/OpenAI adapters, Sentry against a real project, the GitHub workflow, Python 3.10/3.11 (tests ran on 3.12 only).
* Educational content, not medical advice. Put TLS in front, set `EVIDENTIA_ADMIN_KEY`, set `EVIDENTIA_CORS_ORIGINS` only if another
  origin must call the API, and restrict `/radar`, `/metrics` and `/evaluation` to your network.

## Feature map (document -> code)

| Milestone 2 feature | Where |
|---|---|
| Claim breakdown | `nlp.split_claims` |
| **Scientific Evidence Court** + **Claim-Evidence Map** | `engine.check_claim` -> `evidence.court` |
| **AI Disagreement Detector** | `providers.py`, `disagreement` in `/check`, `POST /compare-models` |
| **Intelligent Abstention Engine** | `abstained` + `abstain_reason` (`evidence_insufficient`, `no_matching_evidence`, `low_confidence_match`, `models_disagree_no_evidence`) |
| Explanation, consequences, safest action; AR/EN; cultural adaptation | `engine.py` (`culture` changes examples only, never verdicts) |
| Professional guidance first for crisis / medication changes | `engine.safety_triage` |
| **Verified Expert Supervision** + audit trail | `experts.py` |
| **Health Rumor Radar** (topic-level, k-anonymity, no raw text/IP) | `radar.py` |
| Modules with before/after test, survey, cultural-adaptation test, public feedback | `learning.py`, `community.py` |
| Hypothesis test (+10 pp accuracy, -30% overconfident errors) | `evaluation.py`, `POST /evaluation/run` |

## Endpoints (summary — `GET /routes` lists all)

Public: `POST /check`, `POST /compare-models`, `GET /library[?field=&q=&limit=]`, `GET /library/{id}`, `GET /fields`, `GET /models`, `GET /health`,
`GET /ui`, `POST /feedback`, `GET /feedback/summary`, `GET /modules`, `GET /modules/{m}/questions`, `POST /modules/{m}/sessions`,
`POST /modules/{m}/attempts`, `GET /modules/{m}/results`, `POST /survey`, `GET /survey/summary`, `POST /cultural-test/responses`,
`GET /cultural-test/summary`, `POST /experts/register`.
Expert (`X-Expert-Token`): `GET /reviews/queue`, `POST /reviews`, `POST /reviews/queue/{id}/resolve`, `POST /library/{id}/amend`.
Admin (`X-Admin-Key`): `GET /experts`, `POST /experts/{id}/verify|reject`, `POST /radar/ingest`, `GET /radar/trends|hotspots`,
`POST /evaluation/run`, `GET /evaluation/runs`, `GET /metrics`.

Validation errors return `400 {"error": "validation failed", "details": [{"field", "message"}, ...]}`.
`/check` body: `text` (<= 5000 chars), `lang` (`auto|en|ar`), `culture` (`generic|eg|us`), `region` (optional, never inferred),
`models`, `share_for_review` (default **false**), `log` (anonymous topic count, default true).

## Real AI models

Set `ANTHROPIC_API_KEY` and/or `OPENAI_API_KEY` and those models join the Disagreement Detector automatically and can be the evaluation
baseline: `POST /evaluation/run {"baseline": "anthropic"}`. These adapters use plain HTTPS and were **not exercised against the live APIs**
in the build environment (no network); test them once with your keys. The 80-claim test set must be confirmed by independent experts first
(`confirmed_by_expert: true`) and uploaded to `POST /evaluation/run`.
