# Changelog

## 1.1.0
- Added: web UI (`/ui`), 22 library entries (68 total, all pending expert review), optional embeddings mode, migrations runner + CLI,
  JSON logging + request ids + optional Sentry, `/metrics`, request-schema validation, CORS allow-list, brute-force lockout,
  security headers, `pyproject.toml`, Docker hardening, GitHub Actions CI, `scripts/compare_matching.py`.
- Changed: CORS is now an allow-list (`EVIDENTIA_CORS_ORIGINS`, default none) instead of `*`; validation errors list every field problem;
  library statements are phrased affirmatively (enforced by a test); a definitive verdict now needs a match score >= 0.5.
- Fixed: negation words inside library statements could flip verdicts; look-alike claims could be endorsed; `babies/baby` and
  `injuries/injury` did not match; invalid `Content-Length` returned 500.
- Removed: `EVIDENTIA_CORS_ORIGIN` (replaced by `EVIDENTIA_CORS_ORIGINS`).

## 1.0.0
- First release: engine, expert workflow, radar, modules, evaluation harness.
