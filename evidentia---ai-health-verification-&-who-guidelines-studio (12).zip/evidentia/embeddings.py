"""
evidentia.embeddings — Multi-model Vector Embeddings & Similarity Calculation.
Supports:
1. Sentence-Transformers (multilingual MiniLM / E5)
2. OpenAI text-embedding-3-small / text-embedding-3-large
3. Google Gemini text-embedding-004
4. High-precision character/word N-Gram + TF-IDF with L2 normalization (zero-dependency stdlib fallback)
Compatible with Python 3.10, 3.11, 3.12.
"""

from __future__ import annotations
import math
import os
import hashlib
import json
from typing import List, Dict, Any, Optional
from evidentia.nlp import normalize_text, extract_medical_entities, calculate_entity_mismatch_penalty

# In-memory LRU-like cache for embeddings
_EMBEDDING_CACHE: Dict[str, List[float]] = {}
MAX_CACHE_SIZE = 5000

def _l2_normalize(vector: List[float]) -> List[float]:
    """Normalizes a vector to unit length (L2 norm)."""
    norm = math.sqrt(sum(x * x for x in vector))
    if norm == 0.0:
        return vector
    return [x / norm for x in vector]

def compute_cosine_similarity(vec_a: List[float], vec_b: List[float]) -> float:
    """Calculates cosine similarity between two unit vectors."""
    if not vec_a or not vec_b or len(vec_a) != len(vec_b):
        return 0.0
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    return max(-1.0, min(1.0, dot))


class NgramTFIDFEmbeddingProvider:
    """
    Standard library zero-dependency embedding provider.
    Combines word tokens and character 3-grams with Murmur-style hash projections
    and L2 normalization. Generates 256-dimensional dense vectors.
    """
    DIM = 256

    def embed(self, text: str) -> List[float]:
        norm = normalize_text(text)
        if not norm:
            return [0.0] * self.DIM

        vec = [0.0] * self.DIM
        tokens = norm.split()

        # Word unigrams
        for tok in tokens:
            h = int(hashlib.md5(tok.encode("utf-8")).hexdigest()[:8], 16) % self.DIM
            vec[h] += 2.0

        # Character tri-grams for typo and morphology tolerance
        padded = f"^{norm}$"
        for i in range(len(padded) - 2):
            tri = padded[i : i + 3]
            h = int(hashlib.sha256(tri.encode("utf-8")).hexdigest()[:8], 16) % self.DIM
            vec[h] += 0.8

        return _l2_normalize(vec)


class SentenceTransformersProvider:
    """Uses sentence-transformers if installed."""
    def __init__(self, model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"):
        self.model_name = model_name
        self._model = None

    def _load(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self.model_name)

    def embed(self, text: str) -> List[float]:
        self._load()
        emb = self._model.encode(text, normalize_embeddings=True)
        return [float(x) for x in emb.tolist()]


class OpenAIEmbeddingProvider:
    """Uses OpenAI embeddings API via HTTPS / client."""
    def __init__(self, api_key: str, model: str = "text-embedding-3-small"):
        self.api_key = api_key
        self.model = model

    def embed(self, text: str) -> List[float]:
        import urllib.request
        url = "https://api.openai.com/v1/embeddings"
        payload = json.dumps({"input": text, "model": self.model}).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            vec = data["data"][0]["embedding"]
            return _l2_normalize(vec)


class GeminiEmbeddingProvider:
    """Uses Google Gemini text-embedding-004."""
    def __init__(self, api_key: str, model: str = "text-embedding-004"):
        self.api_key = api_key
        self.model = model

    def embed(self, text: str) -> List[float]:
        import urllib.request
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:embedContent?key={self.api_key}"
        payload = json.dumps({"content": {"parts": [{"text": text}]}}).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            vec = data["embedding"]["values"]
            return _l2_normalize(vec)


class EmbeddingEngine:
    """
    Unified Embedding orchestrator with auto-selection and caching.
    Modes:
      - 'sentence-transformers'
      - 'openai'
      - 'gemini'
      - 'ngram' (default, stdlib, fully offline)
    """
    def __init__(self):
        self.mode = os.getenv("EVIDENTIA_EMBEDDINGS", "ngram").lower()
        self._ngram = NgramTFIDFEmbeddingProvider()
        self._st = None
        self._openai = None
        self._gemini = None

    def get_embedding(self, text: str, force_provider: Optional[str] = None) -> List[float]:
        cache_key = f"{force_provider or self.mode}:{text}"
        if cache_key in _EMBEDDING_CACHE:
            return _EMBEDDING_CACHE[cache_key]

        provider = force_provider or self.mode
        vector = None

        if provider == "sentence-transformers":
            try:
                if self._st is None:
                    model_name = os.getenv("EVIDENTIA_EMB_MODEL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
                    self._st = SentenceTransformersProvider(model_name)
                vector = self._st.embed(text)
            except Exception:
                vector = self._ngram.embed(text)
        elif provider == "openai":
            api_key = os.getenv("OPENAI_API_KEY", "")
            if api_key:
                try:
                    if self._openai is None:
                        self._openai = OpenAIEmbeddingProvider(api_key)
                    vector = self._openai.embed(text)
                except Exception:
                    vector = self._ngram.embed(text)
            else:
                vector = self._ngram.embed(text)
        elif provider == "gemini":
            api_key = os.getenv("GEMINI_API_KEY", "")
            if api_key:
                try:
                    if self._gemini is None:
                        self._gemini = GeminiEmbeddingProvider(api_key)
                    vector = self._gemini.embed(text)
                except Exception:
                    vector = self._ngram.embed(text)
            else:
                vector = self._ngram.embed(text)
        else:
            vector = self._ngram.embed(text)

        if len(_EMBEDDING_CACHE) >= MAX_CACHE_SIZE:
            _EMBEDDING_CACHE.clear()
        _EMBEDDING_CACHE[cache_key] = vector
        return vector

    def match_claim_to_statement(self, claim: str, statement: str) -> float:
        """
        Calculates similarity score with entity penalty enforcement.
        Design rule: embeddings may raise a lexical score, but a claim that names
        an entity the statement lacks is penalised.
        """
        vec_claim = self.get_embedding(claim)
        vec_stmt = self.get_embedding(statement)
        raw_sim = compute_cosine_similarity(vec_claim, vec_stmt)

        # Entity penalty check
        claim_ents = extract_medical_entities(claim)
        stmt_ents = extract_medical_entities(statement)
        penalty = calculate_entity_mismatch_penalty(claim_ents, stmt_ents)

        final_score = max(0.0, raw_sim - penalty)
        return round(final_score, 4)

# Global default instance
EMBEDDINGS = EmbeddingEngine()
