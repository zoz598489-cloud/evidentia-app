"""
evidentia.memory — Multi-Tier Conversation Memory & Context Management.
Supports:
1. Short-Term Memory Buffer: exact recent turns with token budgeting.
2. Long-Term Memory: recursive clinical summarization of older conversational turns.
3. User Clinical Profile & Context: tracks patient context, language, preferences.
4. Auto-pruning to stay within model context limits.
Compatible with Python 3.10, 3.11, 3.12.
"""

from __future__ import annotations
import time
import uuid
from typing import List, Dict, Any, Optional
from evidentia.logs import get_logger

logger = get_logger("evidentia.memory")

class MessageTurn:
    def __init__(self, role: str, content: str, verified_claims: Optional[List[Dict[str, Any]]] = None):
        self.role = role
        self.content = content
        self.verified_claims = verified_claims or []
        self.timestamp = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role": self.role,
            "content": self.content,
            "verified_claims": self.verified_claims,
            "timestamp": self.timestamp
        }


class ConversationSession:
    """
    Manages a single conversational session with dual-layer memory:
    - Short-term sliding window (exact turns)
    - Long-term rolling summary (synthesized background)
    """
    def __init__(self, session_id: Optional[str] = None, max_short_term_turns: int = 4):
        self.session_id = session_id or f"sess_{uuid.uuid4().hex[:10]}"
        self.max_short_term_turns = max_short_term_turns
        self.short_term_buffer: List[MessageTurn] = []
        self.long_term_summary: str = ""
        self.user_profile: Dict[str, Any] = {
            "lang": "auto",
            "culture": "generic",
            "topics_discussed": set(),
            "flags": set(),
        }
        self.created_at = time.time()
        self.last_active_at = time.time()

    def add_interaction(
        self,
        user_message: str,
        assistant_message: str,
        verified_claims: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        """Adds a round of conversation and compresses older turns into long-term summary."""
        self.last_active_at = time.time()
        self.short_term_buffer.append(MessageTurn("user", user_message))
        self.short_term_buffer.append(MessageTurn("assistant", assistant_message, verified_claims))

        # Update topics
        lower = user_message.lower()
        for topic in ["sports", "nutrition", "mental_health", "skin", "medication", "pregnancy"]:
            if topic in lower:
                self.user_profile["topics_discussed"].add(topic)

        # Trigger summarization if buffer exceeds capacity
        if len(self.short_term_buffer) > (self.max_short_term_turns * 2):
            self._compress_buffer()

    def _compress_buffer(self) -> None:
        """Transfers oldest turns from short-term buffer into long-term clinical summary."""
        turns_to_compress = self.short_term_buffer[:2]
        self.short_term_buffer = self.short_term_buffer[2:]

        summary_snippets = []
        for t in turns_to_compress:
            summary_snippets.append(f"[{t.role.upper()}]: {t.content[:120]}...")

        compressed_text = " | ".join(summary_snippets)
        if self.long_term_summary:
            self.long_term_summary = f"{self.long_term_summary}; Previous discussion included: {compressed_text}"
        else:
            self.long_term_summary = f"Prior context: {compressed_text}"

        logger.debug(f"Session {self.session_id} compressed memory. Long-term summary length: {len(self.long_term_summary)}")

    def get_full_context_prompt(self, max_tokens: int = 1200) -> str:
        """Constructs an integrated system context block for LLM prompts."""
        lines = []

        # 1. User Profile & Preferences
        topics = ", ".join(self.user_profile["topics_discussed"]) or "None identified yet"
        lines.append(f"Patient/User Context: Language={self.user_profile.get('lang')}, Region={self.user_profile.get('culture')}, Focus Areas={topics}")

        # 2. Long-term memory summary
        if self.long_term_summary:
            lines.append(f"Historical Conversation Summary: {self.long_term_summary}")

        # 3. Short-term dialogue history
        lines.append("Recent Dialogue History:")
        for turn in self.short_term_buffer:
            prefix = "User" if turn.role == "user" else "Evidentia"
            lines.append(f"  {prefix}: {turn.content}")

        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "last_active_at": self.last_active_at,
            "short_term_turn_count": len(self.short_term_buffer),
            "long_term_summary": self.long_term_summary,
            "topics": list(self.user_profile["topics_discussed"]),
            "recent_turns": [t.to_dict() for t in self.short_term_buffer[-4:]]
        }


class MemoryManager:
    """Manages active conversation sessions across the application."""
    def __init__(self):
        self.sessions: Dict[str, ConversationSession] = {}

    def get_or_create_session(self, session_id: Optional[str] = None) -> ConversationSession:
        if not session_id or session_id not in self.sessions:
            sess = ConversationSession(session_id)
            self.sessions[sess.session_id] = sess
            return sess
        return self.sessions[session_id]

    def list_sessions(self) -> List[Dict[str, Any]]:
        return [s.to_dict() for s in self.sessions.values()]

    def prune_stale_sessions(self, max_idle_seconds: float = 86400.0) -> int:
        now = time.time()
        stale = [sid for sid, s in self.sessions.items() if (now - s.last_active_at) > max_idle_seconds]
        for sid in stale:
            del self.sessions[sid]
        return len(stale)

# Global Memory Manager instance
MEMORY = MemoryManager()
