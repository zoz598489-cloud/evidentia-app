"""
Evidentia Backend - Enterprise End-to-End AI System (v2.0)
Health-claim verification, RAG architecture, Multi-Model Orchestration,
Semantic Caching, Conversation Memory, Guardrails, and Honest Abstention Engine.
"""

__version__ = "2.0.0"
__author__ = "Osler's Hippocrates / Evidentia Team"
