"""
evidentia.db — Forward-Only Database Migration Runner with Transaction Isolation and Checksums.
Compatible with Python 3.10, 3.11, 3.12 standard library sqlite3.
"""

from __future__ import annotations
import hashlib
import os
import shutil
import sqlite3
import time
from pathlib import Path
from typing import List, Tuple, Dict, Any, Optional

DB_PATH_DEFAULT = "evidentia.db"
MIGRATIONS_DIR = Path(__file__).parent / "migrations"

def get_db_path() -> str:
    return os.getenv("EVIDENTIA_DB", DB_PATH_DEFAULT)

def get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = db_path or get_db_path()
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def compute_checksum(content: str) -> str:
    return hashlib.sha256(content.strip().encode("utf-8")).hexdigest()

class MigrationRunner:
    """Manages forward-only migrations safely."""
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or get_db_path()

    def ensure_migration_table(self, conn: sqlite3.Connection) -> None:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS schema_migrations (
                id TEXT PRIMARY KEY,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                checksum TEXT NOT NULL
            );
        """)
        conn.commit()

    def get_applied_migrations(self, conn: sqlite3.Connection) -> Dict[str, str]:
        self.ensure_migration_table(conn)
        cursor = conn.execute("SELECT id, checksum FROM schema_migrations ORDER BY id ASC;")
        return {row["id"]: row["checksum"] for row in cursor.fetchall()}

    def get_migration_files(self) -> List[Path]:
        if not MIGRATIONS_DIR.exists():
            return []
        files = list(MIGRATIONS_DIR.glob("*.sql"))
        files.sort(key=lambda p: p.name)
        return files

    def backup_database(self) -> Optional[str]:
        if not os.path.exists(self.db_path) or os.path.getsize(self.db_path) == 0:
            return None
        backup_name = f"{self.db_path}.bak.{int(time.time())}"
        shutil.copy2(self.db_path, backup_name)
        return backup_name

    def status(self) -> List[Dict[str, Any]]:
        conn = get_connection(self.db_path)
        try:
            applied = self.get_applied_migrations(conn)
            files = self.get_migration_files()
            status_list = []
            for f in files:
                m_id = f.stem
                is_applied = m_id in applied
                content = f.read_text(encoding="utf-8")
                checksum = compute_checksum(content)
                status_list.append({
                    "id": m_id,
                    "applied": is_applied,
                    "file": f.name,
                    "checksum_match": (applied.get(m_id) == checksum) if is_applied else None
                })
            return status_list
        finally:
            conn.close()

    def migrate_up(self) -> List[str]:
        files = self.get_migration_files()
        conn = get_connection(self.db_path)
        applied_names = []
        try:
            applied = self.get_applied_migrations(conn)
            pending = [f for f in files if f.stem not in applied]

            if not pending:
                return []

            # Create backup if database holds existing tables
            self.backup_database()

            for f in pending:
                m_id = f.stem
                content = f.read_text(encoding="utf-8")
                checksum = compute_checksum(content)

                # Run each migration in an isolated transaction
                with conn:
                    conn.executescript(content)
                    conn.execute(
                        "INSERT INTO schema_migrations (id, checksum) VALUES (?, ?);",
                        (m_id, checksum)
                    )
                applied_names.append(m_id)
            return applied_names
        finally:
            conn.close()
