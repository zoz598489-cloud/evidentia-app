-- Migration 002: Performance Indexes
CREATE INDEX IF NOT EXISTS idx_evidence_field ON evidence_library(field);
CREATE INDEX IF NOT EXISTS idx_evidence_status ON evidence_library(status);
CREATE INDEX IF NOT EXISTS idx_reviews_evidence ON reviews(evidence_id);
CREATE INDEX IF NOT EXISTS idx_radar_topic_time ON radar_events(topic, timestamp);
