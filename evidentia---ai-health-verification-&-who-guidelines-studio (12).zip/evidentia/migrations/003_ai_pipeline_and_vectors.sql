-- Migration 003: Enterprise AI Pipeline, Vector Chunks & Audit Trail
CREATE TABLE IF NOT EXISTS document_chunks (
    id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    content TEXT NOT NULL,
    embedding_json TEXT,
    field TEXT,
    authority TEXT,
    strategy TEXT DEFAULT 'paragraph',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_chunks_doc ON document_chunks(document_id);
CREATE INDEX IF NOT EXISTS idx_chunks_field ON document_chunks(field);

CREATE TABLE IF NOT EXISTS ai_audit_log (
    id TEXT PRIMARY KEY,
    session_id TEXT,
    prompt_hash TEXT NOT NULL,
    primary_provider TEXT NOT NULL,
    fallback_used INTEGER DEFAULT 0,
    provider_chain TEXT,
    latency_ms REAL NOT NULL,
    status TEXT NOT NULL,
    cached INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_time ON ai_audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_session ON ai_audit_log(session_id);

CREATE TABLE IF NOT EXISTS conversation_sessions (
    id TEXT PRIMARY KEY,
    user_context_json TEXT,
    long_term_summary TEXT,
    turn_count INTEGER DEFAULT 0,
    last_active REAL NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
