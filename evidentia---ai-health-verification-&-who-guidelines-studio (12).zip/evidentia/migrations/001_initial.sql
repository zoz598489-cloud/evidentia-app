-- Migration 001: Initial Core Schema for Evidentia
CREATE TABLE IF NOT EXISTS schema_migrations (
    id TEXT PRIMARY KEY,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    checksum TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evidence_library (
    id TEXT PRIMARY KEY,
    statement_en TEXT NOT NULL,
    statement_ar TEXT NOT NULL,
    field TEXT NOT NULL,
    authority TEXT NOT NULL,
    evidence_level TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending-expert-review',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS experts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    specialty TEXT NOT NULL,
    verified INTEGER DEFAULT 0,
    token_hash TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reviews (
    id TEXT PRIMARY KEY,
    evidence_id TEXT NOT NULL,
    expert_id TEXT NOT NULL,
    verdict TEXT NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(evidence_id) REFERENCES evidence_library(id),
    FOREIGN KEY(expert_id) REFERENCES experts(id)
);

CREATE TABLE IF NOT EXISTS radar_events (
    id TEXT PRIMARY KEY,
    topic TEXT NOT NULL,
    region TEXT,
    lang TEXT NOT NULL,
    timestamp REAL NOT NULL
);
