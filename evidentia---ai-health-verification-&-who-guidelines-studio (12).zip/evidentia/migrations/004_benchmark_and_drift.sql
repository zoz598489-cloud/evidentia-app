-- Migration 004: Clinical Benchmark, Drift Tracking & Authoritative Persistent Store
CREATE TABLE IF NOT EXISTS clinical_evaluations (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    sample_size INTEGER NOT NULL,
    accuracy REAL NOT NULL,
    precision_rate REAL NOT NULL,
    recall_rate REAL NOT NULL,
    specificity_rate REAL NOT NULL,
    f1_score REAL NOT NULL,
    cohens_kappa REAL NOT NULL,
    cusum_drift_score REAL NOT NULL DEFAULT 0.0,
    drift_status TEXT NOT NULL DEFAULT 'STABLE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_eval_created ON clinical_evaluations(created_at);

CREATE TABLE IF NOT EXISTS evaluation_queries (
    id TEXT PRIMARY KEY,
    evaluation_id TEXT,
    sequence_num INTEGER NOT NULL,
    category TEXT NOT NULL,
    claim_text TEXT NOT NULL,
    ground_truth TEXT NOT NULL,
    prediction TEXT NOT NULL,
    confidence REAL NOT NULL,
    rolling_accuracy REAL NOT NULL,
    physician_consensus TEXT NOT NULL,
    pmid TEXT,
    is_match INTEGER NOT NULL,
    drift_flag INTEGER DEFAULT 0,
    latency_ms REAL NOT NULL DEFAULT 15.0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(evaluation_id) REFERENCES clinical_evaluations(id)
);

CREATE INDEX IF NOT EXISTS idx_query_eval ON evaluation_queries(evaluation_id);
CREATE INDEX IF NOT EXISTS idx_query_seq ON evaluation_queries(sequence_num);
CREATE INDEX IF NOT EXISTS idx_query_cat ON evaluation_queries(category);

CREATE TABLE IF NOT EXISTS persistent_authority_sources (
    id TEXT PRIMARY KEY,
    organization TEXT NOT NULL,
    organization_name_en TEXT NOT NULL,
    organization_name_ar TEXT NOT NULL,
    title_en TEXT NOT NULL,
    title_ar TEXT NOT NULL,
    summary_en TEXT NOT NULL,
    summary_ar TEXT NOT NULL,
    official_url TEXT NOT NULL,
    category TEXT NOT NULL,
    evidence_level TEXT NOT NULL,
    recommendation_grade TEXT NOT NULL,
    year TEXT NOT NULL,
    icd11_code TEXT,
    trust_score INTEGER DEFAULT 100,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_auth_org ON persistent_authority_sources(organization);
CREATE INDEX IF NOT EXISTS idx_auth_cat ON persistent_authority_sources(category);
