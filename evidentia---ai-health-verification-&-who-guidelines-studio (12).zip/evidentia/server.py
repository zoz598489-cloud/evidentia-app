"""
evidentia.server — Production-Ready HTTP REST API Server for Evidentia Backend v2.0.
Features:
- Full Enterprise AI Pipeline Endpoints (/check, /api/v2/verify, /api/v2/rag/*, /api/v2/orchestrate, etc.)
- CORS allow-list & Security Headers
- Request ID tracing (X-Request-ID)
- Schema Validation
- Automated SQLite migration on startup
- Pure Python 3.10, 3.11, 3.12 Standard Library http.server (can run standalone or behind reverse proxy/Express)
"""

from __future__ import annotations
import http.server
import json
import os
import sys
import time
import urllib.parse
import uuid
from typing import Dict, Any, Optional

from evidentia.logs import get_logger, record_request_metric, get_metrics_summary, setup_sentry
from evidentia.engine import ENGINE
from evidentia.rag import RAG
from evidentia.providers import ORCHESTRATOR
from evidentia.cache import SEMANTIC_CACHE
from evidentia.guardrails import GUARDRAILS
from evidentia.memory import MEMORY
from evidentia.db import MigrationRunner
from evidentia.fhir import FHIR_ENGINE, SAMPLE_FHIR_PROFILES
from evidentia.validation import VALIDATION_BENCHMARK
from evidentia.authoritative_sources import AUTHORITATIVE_REGISTRY

logger = get_logger("evidentia.server")

class EvidentiaAPIHandler(http.server.BaseHTTPRequestHandler):
    server_version = "EvidentiaAI/2.0.0"

    def _send_json(self, status: int, data: Any, req_id: str, start_time: float):
        duration_ms = (time.time() - start_time) * 1000.0
        record_request_metric(self.command, self.path.split("?")[0], status, duration_ms)

        body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Request-ID", req_id)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")

        # CORS allow-list
        allowed_origins = os.getenv("EVIDENTIA_CORS_ORIGINS", "*").strip()
        req_origin = self.headers.get("Origin", "")
        if allowed_origins == "*" or (req_origin and req_origin in [o.strip() for o in allowed_origins.split(",")]):
            self.send_header("Access-Control-Allow-Origin", req_origin or "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, DELETE")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Admin-Key, X-Expert-Token, X-Request-ID")

        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        req_id = self.headers.get("X-Request-ID", str(uuid.uuid4()))
        self._send_json(200, {"status": "ok"}, req_id, time.time())

    def _read_body_json(self) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length <= 0:
                return None, "Empty request body"
            if length > 500_000:
                return None, "Request body exceeds maximum size (500KB)"
            raw = self.rfile.read(length).decode("utf-8")
            return json.loads(raw), None
        except Exception as e:
            return None, f"Malformed JSON: {str(e)}"

    def do_GET(self):
        start_time = time.time()
        req_id = self.headers.get("X-Request-ID", str(uuid.uuid4()))
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path in ("/health", "/api/v2/health"):
            data = {
                "status": "HEALTHY",
                "version": "2.0.0",
                "timestamp": time.time(),
                "providers": list(ORCHESTRATOR.providers.keys()),
                "embeddings_mode": os.getenv("EVIDENTIA_EMBEDDINGS", "ngram"),
                "rag_documents_count": len(RAG.in_memory_store.chunks),
                "cache_stats": SEMANTIC_CACHE.get_stats(),
            }
            return self._send_json(200, data, req_id, start_time)

        if path == "/metrics":
            return self._send_json(200, get_metrics_summary(), req_id, start_time)

        if path in ("/models", "/api/v2/models"):
            models = [
                {"id": "evidentia_ultra", "name": "Evidentia Ultra Sovereign AI (النموذج السيادي الخاص بك)", "type": "proprietary_core", "status": "active"},
                {"id": "gemini", "name": "Google Gemini 3.8 Flash", "type": "cloud", "status": "active"},
                {"id": "claude", "name": "Anthropic Claude 3.5 Sonnet", "type": "cloud", "status": "active"},
                {"id": "openai", "name": "OpenAI GPT-4o-mini", "type": "cloud", "status": "active"},
                {"id": "medpalm", "name": "Med-PaLM 2 Clinical Guidelines Specialist", "type": "specialized_medical", "status": "active"},
                {"id": "biomistral", "name": "BioMistral-7B (Fine-tuned Clinical SLM)", "type": "specialized_medical", "status": "active"},
                {"id": "cochrane_judge", "name": "Cochrane Meta-Analytic Judge (Level 1 EBM)", "type": "meta_analysis", "status": "active"},
                {"id": "rx_agent", "name": "Clinical Pharmacology & DDI Specialist", "type": "pharmacovigilance", "status": "active"},
                {"id": "epidemiology_ai", "name": "WHO Outbreak & Public Health Intelligence", "type": "epidemiology", "status": "active"},
                {"id": "ollama", "name": "Local Sovereign Model (Llama 3 / vLLM)", "type": "local", "status": "available"},
                {"id": "standin", "name": "Evidentia Rule Baseline", "type": "offline_fallback", "status": "ready"}
            ]
            return self._send_json(200, {"models": models, "total_models": len(models)}, req_id, start_time)

        if path in ("/fields", "/api/v2/fields"):
            fields = [
                {
                    "id": "orthopedics",
                    "name_en": "Sports Injuries & Orthopedics",
                    "name_ar": "طب العظام وإصابات الملاعب",
                    "authority": "AAOS / Cochrane Musculoskeletal Group",
                    "topics_en": "Acute sprains, fractures, RICE protocol, ligament rehabilitation, cartilage erosion",
                    "topics_ar": "التواءات الكاحل الحادة، الكسور، بروتوكولات RICE، تأهيل الأربطة، خشونة المفاصل"
                },
                {
                    "id": "infectious_diseases",
                    "name_en": "Infectious Diseases & AMR",
                    "name_ar": "الأمراض المعدية ومقاومة مضادات الميكروبات",
                    "authority": "World Health Organization (WHO) / CDC",
                    "topics_en": "Antimicrobial resistance, viral vs bacterial infections, influenza, norovirus, sepsis",
                    "topics_ar": "مقاومة المضادات الحيوية، العدوى الفيروسية مقابل البكتيرية، الإنفلونزا، تعقيم اليدين، الإنتان"
                },
                {
                    "id": "cardiology",
                    "name_en": "Cardiology & Vascular Medicine",
                    "name_ar": "أمراض القلب والأوعية الدموية وضغط الدم",
                    "authority": "WHO / American Heart Association (AHA)",
                    "topics_en": "Hypertension, sodium reduction, acute myocardial infarction, LDL cholesterol, stroke",
                    "topics_ar": "ارتفاع ضغط الدم، تقليل استهلاك الملح والصوديوم، الجلطات القلبية، دهون الدم، السكتات"
                },
                {
                    "id": "pharmacology",
                    "name_en": "Pharmacology & Drug Safety (DDI)",
                    "name_ar": "علم الأدوية وسلامة الدواء والتداخلات الدوائية",
                    "authority": "US FDA / RxNorm / EMA",
                    "topics_en": "Drug-drug interactions, NSAIDs & Warfarin bleeding risk, beta-blocker contraindications",
                    "topics_ar": "تفاعلات الأدوية الخطرة، نزيف المسكنات مع مميعات الدم، موانع استعمال حاصرات بيتا"
                },
                {
                    "id": "pediatrics",
                    "name_en": "Pediatrics & Child Health",
                    "name_ar": "طب الأطفال وصحة الرضع والنمو",
                    "authority": "American Academy of Pediatrics (AAP) / WHO / UNICEF",
                    "topics_en": "Exclusive breastfeeding, infant botulism honey restriction, MMR vaccine safety, ADHD",
                    "topics_ar": "الرضاعة الطبيعية المطلقة، منع العسل للرضع، أمان اللقاحات ونفي التوحد، علاج فرط الحركة"
                },
                {
                    "id": "food_safety",
                    "name_en": "Food Safety & Foodborne Pathogens",
                    "name_ar": "سلامة الغذاء وميكروبيولوجيا التغذية",
                    "authority": "USDA / FDA / WHO Food Safety",
                    "topics_en": "Two-hour danger zone, Salmonella & Campylobacter in poultry, internal cooking temperatures",
                    "topics_ar": "قاعدة الساعتين لحفظ الدواجن، تكاثر السالمونيلا، درجات الحرارة الآمنة لحفظ وطهي الطعام"
                },
                {
                    "id": "dermatology",
                    "name_en": "Dermatology & Skin Disorders",
                    "name_ar": "الأمراض الجلدية والعناية بالبشرة",
                    "authority": "American Academy of Dermatology (AAD) / Cochrane Skin",
                    "topics_en": "Atopic dermatitis (eczema), topical corticosteroids, broad-spectrum sunscreen SPF 30+",
                    "topics_ar": "الإكزيما التأتبية، مراهم الكورتيزون الموضعية، واقيات الشمس والوقاية من سرطانات الجلد"
                },
                {
                    "id": "neurology_psychiatry",
                    "name_en": "Neurology & Mental Health",
                    "name_ar": "طب الأعصاب والصحة النفسية",
                    "authority": "WHO Mental Health / APA / Cochrane Neurology",
                    "topics_en": "FAST stroke identification, seizure emergency protocols, cognitive behavioral therapy, SSRIs",
                    "topics_ar": "التعرف الفوري على السكتة الدماغية FAST، إسعافات الصرع الصحيحة، العلاج السلوكي للاكتئاب"
                },
                {
                    "id": "endocrinology",
                    "name_en": "Endocrinology & Diabetes",
                    "name_ar": "الغدد الصماء والسكري والتمثيل الغذائي",
                    "authority": "American Diabetes Association (ADA) / Endocrine Society",
                    "topics_en": "HbA1c diagnostic criteria, Metformin pharmacology, corticosteroid hyperglycemia, thyroid disorders",
                    "topics_ar": "معايير تشخيص السكر التراكمي، كفاءة المتفورمين، اضطرابات السكر، قصور وعواصف الغدة الدرقية"
                },
                {
                    "id": "emergency_medicine",
                    "name_en": "Emergency Medicine & Critical Care",
                    "name_ar": "طب الطوارئ والحالات الحرجة",
                    "authority": "Emergency Medicine Colleges / WHO Emergency Care",
                    "topics_en": "Cervical spine immobilization, poisoning and toxin ingestion protocols, acute trauma triage",
                    "topics_ar": "تثبيت فقرات العنق في الحوادث، بروتوكولات التسمم الحاد، فرز الحالات الحرجة والإسعاف الفوري"
                }
            ]
            return self._send_json(200, {"count": len(fields), "fields": fields}, req_id, start_time)

        if path in ("/api/v2/fhir/profiles", "/fhir/profiles"):
            return self._send_json(200, {"profiles": SAMPLE_FHIR_PROFILES}, req_id, start_time)

        if path in ("/api/v2/validation/benchmark", "/benchmark"):
            return self._send_json(200, VALIDATION_BENCHMARK.get_benchmark_report(), req_id, start_time)

        if path in ("/api/v2/benchmark/drift", "/benchmark/drift"):
            window = int(query.get("window", ["5"])[0])
            return self._send_json(200, VALIDATION_BENCHMARK.get_drift_timeline(rolling_window=window), req_id, start_time)

        if path in ("/api/v2/database/tables", "/database/tables"):
            from evidentia.db import get_connection
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;")
            tables_meta = []
            for row in cur.fetchall():
                tname = row["name"]
                count_cur = conn.cursor()
                count_cur.execute(f"SELECT COUNT(*) as cnt FROM {tname};")
                cnt = count_cur.fetchone()["cnt"]
                info_cur = conn.cursor()
                info_cur.execute(f"PRAGMA table_info({tname});")
                cols = [c["name"] for c in info_cur.fetchall()]
                tables_meta.append({
                    "table_name": tname,
                    "row_count": cnt,
                    "columns": cols
                })
            conn.close()
            return self._send_json(200, {
                "database": "evidentia.db (SQLite 3.x WAL)",
                "total_tables": len(tables_meta),
                "tables": tables_meta
            }, req_id, start_time)

        if path in ("/api/v2/database/query", "/database/query"):
            table = query.get("table", ["evaluation_queries"])[0]
            limit = min(100, int(query.get("limit", ["50"])[0]))
            offset = int(query.get("offset", ["0"])[0])
            from evidentia.db import get_connection
            conn = get_connection()
            cur = conn.cursor()
            # Prevent injection by verifying table name against known schema
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name = ?;", (table,))
            if not cur.fetchone():
                conn.close()
                return self._send_json(400, {"error": f"Invalid table '{table}'"}, req_id, start_time)
            cur.execute(f"SELECT * FROM {table} LIMIT ? OFFSET ?;", (limit, offset))
            rows = [dict(r) for r in cur.fetchall()]
            count_cur = conn.cursor()
            count_cur.execute(f"SELECT COUNT(*) as cnt FROM {table};")
            total_cnt = count_cur.fetchone()["cnt"]
            conn.close()
            return self._send_json(200, {
                "table": table,
                "total_count": total_cnt,
                "limit": limit,
                "offset": offset,
                "rows": rows
            }, req_id, start_time)

        if path == "/api/v2/cache/stats":
            return self._send_json(200, SEMANTIC_CACHE.get_stats(), req_id, start_time)

        if path == "/api/v2/memory/sessions":
            return self._send_json(200, {"sessions": MEMORY.list_sessions()}, req_id, start_time)

        if path in ("/api/v2/authorities/sources", "/authorities/sources"):
            return self._send_json(200, {
                "organizations": AUTHORITATIVE_REGISTRY.get_connected_organizations(),
                "total_guidelines_indexed": len(AUTHORITATIVE_REGISTRY.items),
                "authorities_active": ["WHO", "CDC", "COCHRANE", "NIH_PUBMED", "NICE", "MEDLINE_PLUS"]
            }, req_id, start_time)

        if path in ("/api/v2/authorities/guidelines", "/authorities/guidelines"):
            org = query.get("org", [""])[0]
            items = [it.to_dict() for it in AUTHORITATIVE_REGISTRY.items]
            if org:
                items = [it for it in items if it["organization"].upper() == org.upper()]
            return self._send_json(200, {"count": len(items), "guidelines": items}, req_id, start_time)

        if path in ("/api/v2/rag/documents", "/rag/documents"):
            docs = RAG.get_ingested_documents(limit=50)
            return self._send_json(200, {
                "count": len(docs),
                "total_chunks_in_store": len(RAG.in_memory_store.chunks),
                "documents": docs
            }, req_id, start_time)

        if path in ("/library", "/api/v2/library"):
            q = query.get("q", [""])[0]
            field = query.get("field", [""])[0]
            docs = list(RAG.in_memory_store.chunks.values())
            if field:
                docs = [d for d in docs if d.metadata.get("field") == field]
            if q:
                docs = [d for d in docs if q.lower() in d.text.lower()]
            return self._send_json(200, {"count": len(docs), "entries": [d.to_dict() for d in docs[:50]]}, req_id, start_time)

        if path == "/routes":
            routes = [
                {"method": "GET", "path": "/health", "desc": "Healthcheck and system readiness"},
                {"method": "GET", "path": "/metrics", "desc": "Prometheus/JSON performance metrics"},
                {"method": "GET", "path": "/models", "desc": "Active AI models and provider status"},
                {"method": "GET", "path": "/fields", "desc": "Supported clinical medical fields"},
                {"method": "GET", "path": "/library", "desc": "Search evidence library facts"},
                {"method": "POST", "path": "/check", "desc": "Main verification endpoint with full AI pipeline"},
                {"method": "POST", "path": "/api/v2/rag/query", "desc": "Hybrid search (Dense + BM25) across vector store"},
                {"method": "POST", "path": "/api/v2/rag/ingest", "desc": "Ingest and chunk documents into vector store"},
                {"method": "POST", "path": "/api/v2/orchestrate", "desc": "Multi-model prompt with automatic cascade fallback"},
                {"method": "POST", "path": "/compare-models", "desc": "Cross-check stances across Claude, OpenAI, and Gemini"},
                {"method": "GET", "path": "/api/v2/cache/stats", "desc": "Semantic cache hit ratio & latency reduction stats"},
                {"method": "GET", "path": "/api/v2/authorities/sources", "desc": "Connected global health authorities (WHO, CDC, Cochrane, NIH)"},
                {"method": "POST", "path": "/api/v2/authorities/search", "desc": "Search WHO guidelines & authoritative reviews with direct URLs"},
            ]
            return self._send_json(200, {"routes": routes}, req_id, start_time)

        self._send_json(404, {"error": "Endpoint not found", "path": path}, req_id, start_time)

    def do_POST(self):
        start_time = time.time()
        req_id = self.headers.get("X-Request-ID", str(uuid.uuid4()))
        path = self.path.split("?")[0]
        body, err = self._read_body_json()

        if err:
            return self._send_json(400, {"error": "Invalid request body", "details": err}, req_id, start_time)

        # 1. Main End-to-End Verification Endpoint: /check or /api/v2/verify
        if path in ("/check", "/api/v2/verify"):
            text = (body.get("text") or "").strip()
            if not text:
                return self._send_json(400, {"error": "Missing 'text' parameter"}, req_id, start_time)

            lang = body.get("lang", "auto")
            culture = body.get("culture", "generic")
            session_id = body.get("session_id")
            models = body.get("models")
            use_cache = body.get("use_cache", True)
            patient_profile = body.get("patient_profile")

            result = ENGINE.verify_full_post(
                text=text,
                session_id=session_id,
                lang=lang,
                culture=culture,
                models=models,
                use_cache=use_cache,
                patient_profile=patient_profile
            )
            return self._send_json(200, result, req_id, start_time)

        # 2. RAG Hybrid Search Endpoint
        if path == "/api/v2/rag/query":
            query = (body.get("query") or "").strip()
            if not query:
                return self._send_json(400, {"error": "Missing 'query' field"}, req_id, start_time)
            top_k = int(body.get("top_k", 4))
            field = body.get("field")
            alpha = float(body.get("alpha", 0.65))

            results = RAG.in_memory_store.search_hybrid(
                query_text=query,
                top_k=top_k,
                alpha=alpha,
                filters={"field": field} if field else None
            )
            return self._send_json(200, {
                "query": query,
                "top_k": top_k,
                "alpha": alpha,
                "results": [r.to_dict() for r in results]
            }, req_id, start_time)

        # 3. RAG Document Ingestion Endpoint
        if path == "/api/v2/rag/ingest":
            doc_text = (body.get("text") or "").strip()
            title = body.get("title", "Clinical Document")
            field = body.get("field", "general_medicine")
            authority = body.get("authority", "Clinical Guidelines Board")
            evidence_level = body.get("evidence_level", "Level 1: Systematic Review")
            strategy = body.get("strategy", "paragraph")
            doc_id = body.get("document_id")

            if not doc_text:
                return self._send_json(400, {"error": "Missing 'text' to ingest"}, req_id, start_time)

            ingest_res = RAG.ingest_document(
                text=doc_text,
                title=title,
                field=field,
                authority=authority,
                evidence_level=evidence_level,
                chunk_strategy=strategy,
                document_id=doc_id
            )

            res_data = ingest_res.to_dict() if hasattr(ingest_res, "to_dict") else {
                "chunk_ids": list(ingest_res),
                "chunk_count": len(ingest_res),
                "document_id": doc_id or "doc_custom",
                "title": title,
                "strategy": strategy
            }
            res_data["status"] = "INGESTED"
            res_data["rag_total_chunks"] = len(RAG.in_memory_store.chunks)
            return self._send_json(201, res_data, req_id, start_time)

        # 4. Multi-Model Orchestrator with Fallback Cascade
        if path == "/api/v2/orchestrate":
            prompt = (body.get("prompt") or "").strip()
            system_prompt = body.get("system_prompt", "You are Evidentia, a clinical evidence expert.")
            preferred = body.get("preferred_provider", "gemini")

            if not prompt:
                return self._send_json(400, {"error": "Missing 'prompt'"}, req_id, start_time)

            try:
                res = ORCHESTRATOR.execute_with_fallback(prompt, system_prompt, preferred)
                return self._send_json(200, res, req_id, start_time)
            except Exception as e:
                return self._send_json(500, {"error": str(e)}, req_id, start_time)

        # 5. Model Disagreement Cross-Check Endpoint: /compare-models
        if path in ("/compare-models", "/api/v2/compare-models"):
            claim = (body.get("claim") or body.get("text") or "").strip()
            if not claim:
                return self._send_json(400, {"error": "Missing 'claim' parameter"}, req_id, start_time)
            models = body.get("models")
            evidence_ctx = body.get("evidence_context", "")

            disagreement = ORCHESTRATOR.cross_check_claim(claim, evidence_ctx, models)
            return self._send_json(200, disagreement, req_id, start_time)

        # 6. Guardrail Inspection Endpoint
        if path == "/api/v2/guardrails/inspect":
            input_text = (body.get("text") or "").strip()
            report = GUARDRAILS.inspect_input(input_text)
            return self._send_json(200, report, req_id, start_time)

        # 7. HL7 FHIR Context & Contraindication Evaluation Endpoint
        if path in ("/api/v2/fhir/evaluate", "/fhir/evaluate"):
            claim = (body.get("claim") or body.get("text") or "").strip()
            profile = body.get("patient_profile") or body.get("profile_id", "PAT-02")
            if not claim:
                return self._send_json(400, {"error": "Missing 'claim' or 'text'"}, req_id, start_time)
            
            p_obj = SAMPLE_FHIR_PROFILES.get(profile) if isinstance(profile, str) else profile
            if not p_obj:
                return self._send_json(404, {"error": f"Patient profile '{profile}' not found"}, req_id, start_time)

            eval_res = FHIR_ENGINE.evaluate_claim_with_patient(claim, p_obj)
            return self._send_json(200, eval_res, req_id, start_time)

        # 8. Semantic Cache Management
        if path == "/api/v2/cache/clear":
            SEMANTIC_CACHE.clear()
            return self._send_json(200, {"status": "CLEARED"}, req_id, start_time)

        # 9. Authoritative Sources (WHO, CDC, Cochrane, NIH) Search Endpoint
        if path in ("/api/v2/authorities/search", "/authorities/search"):
            query_str = (body.get("query") or body.get("text") or "").strip()
            top_k = int(body.get("top_k", 3))
            org_filter = body.get("organization") or body.get("org")
            results = AUTHORITATIVE_REGISTRY.search(query_str, top_k=top_k, organization_filter=org_filter)
            return self._send_json(200, {
                "query": query_str,
                "top_k": top_k,
                "matches": results,
                "who_referenced": any(r["organization"] == "WHO" for r in results)
            }, req_id, start_time)

        self._send_json(404, {"error": "Endpoint not found", "path": path}, req_id, start_time)

    def do_DELETE(self):
        start_time = time.time()
        req_id = self.headers.get("X-Request-ID", str(uuid.uuid4()))
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path in ("/api/v2/rag/documents", "/api/v2/rag/document", "/rag/documents"):
            doc_id = query.get("id", [""])[0] or query.get("document_id", [""])[0]
            if not doc_id:
                return self._send_json(400, {"error": "Missing query param 'id' or 'document_id'"}, req_id, start_time)
            deleted_count = RAG.delete_document(doc_id)
            return self._send_json(200, {
                "status": "DELETED",
                "document_id": doc_id,
                "chunks_removed": deleted_count,
                "rag_total_chunks": len(RAG.in_memory_store.chunks)
            }, req_id, start_time)

        self._send_json(404, {"error": "Endpoint not found", "path": path}, req_id, start_time)



def run_server(host: str = "0.0.0.0", port: int = 8000):
    """Starts the Evidentia Backend Server."""
    setup_sentry()

    # Automatically check and apply pending database migrations
    if os.getenv("EVIDENTIA_AUTO_MIGRATE", "1") == "1":
        try:
            runner = MigrationRunner()
            applied = runner.migrate_up()
            if applied:
                logger.info(f"Database migrations applied: {applied}")
        except Exception as e:
            logger.error(f"Migration error on startup: {e}")

    server_address = (host, port)
    httpd = http.server.HTTPServer(server_address, EvidentiaAPIHandler)
    logger.info(f"Evidentia AI Enterprise Backend v2.0 listening on http://{host}:{port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("Evidentia server shutting down gracefully.")
        httpd.server_close()


def main():
    host = os.getenv("EVIDENTIA_HOST", "0.0.0.0")
    port = int(os.getenv("EVIDENTIA_PORT", "8000"))
    run_server(host, port)

if __name__ == "__main__":
    main()
