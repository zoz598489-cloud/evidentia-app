"""
evidentia.fhir — HL7 FHIR (Fast Healthcare Interoperability Resources) Integration
Supports:
1. FHIR R4 Patient Resource parsing (Conditions, Medications, Allergies)
2. Drug-Drug Interaction (DDI) & Contraindication Detection Engine
3. Standard Medical Ontologies (RxNorm, ICD-10, SNOMED CT)
4. Patient-Specific Contextual Risk Assessment
Compatible with Python 3.10, 3.11, 3.12.
"""

from __future__ import annotations
import json
from typing import Dict, Any, List, Optional
from evidentia.logs import get_logger

logger = get_logger("evidentia.fhir")

# Standard clinical drug-drug & condition-drug rule base
KNOWN_CONTRAINDICATIONS = [
    {
        "id": "CI-001",
        "category": "DRUG_DRUG_INTERACTION",
        "severity": "CRITICAL",
        "trigger_drugs": ["nsaid", "ibuprofen", "naproxen", "diclofenac", "aspirin", "بروفين", "أسبرين"],
        "conflicting_drugs": ["warfarin", "eliquis", "apixaban", "xarelto", "heparin", "وارفارين", "مضاد تجلط"],
        "warning_en": "High Hemorrhagic Risk: Concomitant use of NSAIDs with anticoagulants substantially elevates gastrointestinal and systemic bleeding risks.",
        "warning_ar": "خطر نزيف حاد: تناول مضادات الالتهاب غير الستيرويدية (NSAIDs) بالتزامن مع مضادات التجلط يضاعف احتمالية النزيف الهضمي الحاد."
    },
    {
        "id": "CI-002",
        "category": "DISEASE_DRUG_CONTRAINDICATION",
        "severity": "CRITICAL",
        "trigger_conditions": ["asthma", "copd", "bronchospasm", "ربو", "حساسية صدر"],
        "conflicting_drugs": ["propranolol", "atenolol", "beta blocker", "بيتا بلوكر", "اندرال"],
        "warning_en": "Bronchospasm Hazard: Non-selective beta-blockers antagonize beta-2 pulmonary receptors, precipitating life-threatening bronchospasm in asthma patients.",
        "warning_ar": "خطر ضيق التنفس الحاد: حاصرات بيتا غير الانتقائية تغلق مستقبلات الشعب الهوائية مما يؤدي لنوبات ربو حادة ومهددة للحياة."
    },
    {
        "id": "CI-003",
        "category": "DISEASE_DRUG_CONTRAINDICATION",
        "severity": "HIGH",
        "trigger_conditions": ["diabetes", "type 2 diabetes", "سكر", "داء السكري"],
        "conflicting_drugs": ["prednisone", "corticosteroid", "dexamethasone", "كورتيزون", "ديكساميثازون"],
        "warning_en": "Hyperglycemia Alert: Systemic corticosteroids stimulate gluconeogenesis and induce peripheral insulin resistance, risking severe diabetic ketoacidosis.",
        "warning_ar": "تحذير اضطراب السكر: الكورتيكوستيرويدات الجهازية ترفع مقاومة الإنسولين في الأنسجة وتسبب ارتفاعات حادة وخطيرة في سكر الدم."
    },
    {
        "id": "CI-004",
        "category": "DISEASE_DRUG_CONTRAINDICATION",
        "severity": "HIGH",
        "trigger_conditions": ["hypertension", "high blood pressure", "ضغط دم", "ارتفاع ضغط الدم"],
        "conflicting_drugs": ["pseudoephedrine", "phenylephrine", "decongestant", "سودوافدرين", "مذيب احتقان"],
        "warning_en": "Hypertensive Crisis Risk: Alpha-adrenergic decongestants cause systemic vasoconstriction, sharply elevating blood pressure in hypertensive patients.",
        "warning_ar": "خطر نوبة ارتفاع الضغط: مضادات الاحتقان المحتوية على محفزات ألفا تؤدي لتقبض وعائي عام يرفع ضغط الدم بشكل مفاجئ وخطير."
    },
    {
        "id": "CI-005",
        "category": "DISEASE_INTERVENTION_CONTRAINDICATION",
        "severity": "MODERATE",
        "trigger_conditions": ["raynaud", "peripheral neuropathy", "severe arterial disease", "رينود", "اعتلال عصبي"],
        "conflicting_drugs": ["ice", "cryotherapy", "cold application", "ثلج", "كمادات ثلج"],
        "warning_en": "Vasospasm / Frostbite Risk: Prolonged ice application in patients with Raynaud's phenomenon or severe neuropathy risks tissue necrosis and delayed healing.",
        "warning_ar": "خطر تلف الأنسجة: تطبيق الثلج المطول لدى مرضى متلازمة رينود أو اعتلال الأعصاب الطرفية يهدد بحدوث تلف موضعي بالأنسجة وتفاقم التشنج الوعائي."
    }
]

# Sample pre-defined FHIR R4 Patient Records for Clinical Testing
SAMPLE_FHIR_PROFILES = {
    "PAT-01": {
        "resourceType": "Patient",
        "id": "PAT-01",
        "name": [{"use": "official", "family": "Hassan", "given": ["Kareem"]}],
        "gender": "male",
        "birthDate": "1994-06-15",
        "profile_title": "Healthy Active Adult (No Known Comorbidities)",
        "profile_title_ar": "شاب معافى ولا يعاني من أمراض مزمنة",
        "conditions": [],
        "medications": [],
        "allergies": []
    },
    "PAT-02": {
        "resourceType": "Patient",
        "id": "PAT-02",
        "name": [{"use": "official", "family": "El-Sayed", "given": ["Mahmoud"]}],
        "gender": "male",
        "birthDate": "1958-11-20",
        "profile_title": "Elderly Diabetic with Stage 3 CKD & Hypertension",
        "profile_title_ar": "مريض سكري مزمن واعتلال كلوي وضغط دم مرتفع",
        "conditions": [
            {"code": "E11.9", "display": "Type 2 diabetes mellitus without complications", "system": "http://hl7.org/fhir/sid/icd-10"},
            {"code": "I10", "display": "Essential (primary) hypertension", "system": "http://hl7.org/fhir/sid/icd-10"},
            {"code": "N18.3", "display": "Chronic kidney disease, stage 3", "system": "http://hl7.org/fhir/sid/icd-10"}
        ],
        "medications": [
            {"medication": "Metformin 1000mg BID", "code": "6809", "system": "http://www.nlm.nih.gov/research/umls/rxnorm"},
            {"medication": "Lisinopril 20mg Daily", "code": "29046", "system": "http://www.nlm.nih.gov/research/umls/rxnorm"},
            {"medication": "Amlodipine 5mg Daily", "code": "17767", "system": "http://www.nlm.nih.gov/research/umls/rxnorm"}
        ],
        "allergies": [
            {"substance": "Penicillin", "criticality": "high", "manifestation": "Anaphylaxis"}
        ]
    },
    "PAT-03": {
        "resourceType": "Patient",
        "id": "PAT-03",
        "name": [{"use": "official", "family": "Ibrahim", "given": ["Fatima"]}],
        "gender": "female",
        "birthDate": "1987-03-12",
        "profile_title": "Moderate Persistent Asthma & Allergic Rhinitis",
        "profile_title_ar": "مريضة ربو شعبي وحساسية أنفية مزمنة",
        "conditions": [
            {"code": "J45.40", "display": "Moderate persistent asthma, uncomplicated", "system": "http://hl7.org/fhir/sid/icd-10"},
            {"code": "J30.9", "display": "Allergic rhinitis, unspecified", "system": "http://hl7.org/fhir/sid/icd-10"}
        ],
        "medications": [
            {"medication": "Fluticasone / Salmeterol Inhaler", "code": "284635", "system": "http://www.nlm.nih.gov/research/umls/rxnorm"},
            {"medication": "Albuterol rescue inhaler", "code": "435", "system": "http://www.nlm.nih.gov/research/umls/rxnorm"}
        ],
        "allergies": [
            {"substance": "Aspirin / NSAIDs", "criticality": "high", "manifestation": "Severe Bronchospasm"}
        ]
    },
    "PAT-04": {
        "resourceType": "Patient",
        "id": "PAT-04",
        "name": [{"use": "official", "family": "Soliman", "given": ["Omar"]}],
        "gender": "male",
        "birthDate": "1952-08-04",
        "profile_title": "Cardiac Patient with Atrial Fibrillation on Anticoagulation",
        "profile_title_ar": "مريض رجفان أذيني يتناول مضادات التجلط الفموية (Warfarin)",
        "conditions": [
            {"code": "I48.91", "display": "Unspecified atrial fibrillation", "system": "http://hl7.org/fhir/sid/icd-10"},
            {"code": "I25.10", "display": "Atherosclerotic heart disease", "system": "http://hl7.org/fhir/sid/icd-10"}
        ],
        "medications": [
            {"medication": "Warfarin 5mg Daily", "code": "11289", "system": "http://www.nlm.nih.gov/research/umls/rxnorm"},
            {"medication": "Atorvastatin 40mg Daily", "code": "83367", "system": "http://www.nlm.nih.gov/research/umls/rxnorm"}
        ],
        "allergies": []
    }
}


class FHIRContextEngine:
    """Parses and checks FHIR R4 medical records against proposed claims and interventions."""

    @staticmethod
    def parse_patient_profile(profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalizes patient data from FHIR R4 bundle or simplified JSON."""
        conditions = []
        for c in profile_data.get("conditions", []):
            if isinstance(c, dict):
                conditions.append(c.get("display", c.get("code", "")).lower())
            elif isinstance(c, str):
                conditions.append(c.lower())

        medications = []
        for m in profile_data.get("medications", []):
            if isinstance(m, dict):
                medications.append(m.get("medication", m.get("display", "")).lower())
            elif isinstance(m, str):
                medications.append(m.lower())

        allergies = []
        for a in profile_data.get("allergies", []):
            if isinstance(a, dict):
                allergies.append(a.get("substance", "").lower())
            elif isinstance(a, str):
                allergies.append(a.lower())

        return {
            "id": profile_data.get("id", "ANON"),
            "conditions": conditions,
            "medications": medications,
            "allergies": allergies,
            "raw": profile_data
        }

    @classmethod
    def evaluate_claim_with_patient(
        cls,
        claim_text: str,
        patient_profile: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Cross-checks a claim against a patient's active FHIR record for drug interactions,
        contraindications, or specific medical hazards.
        """
        parsed_pt = cls.parse_patient_profile(patient_profile)
        lower_claim = claim_text.lower()

        detected_alerts: List[Dict[str, Any]] = []

        # 1. Check against known clinical contraindications
        for rule in KNOWN_CONTRAINDICATIONS:
            # Check Drug-Drug interaction
            if rule["category"] == "DRUG_DRUG_INTERACTION":
                claim_has_trigger = any(t in lower_claim for t in rule.get("trigger_drugs", []))
                patient_has_conflict = any(
                    any(c in med for c in rule.get("conflicting_drugs", []))
                    for med in parsed_pt["medications"]
                )
                if claim_has_trigger and patient_has_conflict:
                    detected_alerts.append({
                        "rule_id": rule["id"],
                        "category": rule["category"],
                        "severity": rule["severity"],
                        "alert_en": rule["warning_en"],
                        "alert_ar": rule["warning_ar"],
                        "reason": "Direct drug-drug interaction with patient's active medication regimen."
                    })

            # Check Condition-Drug contraindication
            elif rule["category"] in ["DISEASE_DRUG_CONTRAINDICATION", "DISEASE_INTERVENTION_CONTRAINDICATION"]:
                claim_has_drug = any(t in lower_claim for t in rule.get("conflicting_drugs", []))
                patient_has_disease = any(
                    any(cond in p_cond for cond in rule.get("trigger_conditions", []))
                    for p_cond in parsed_pt["conditions"]
                )
                if claim_has_drug and patient_has_disease:
                    detected_alerts.append({
                        "rule_id": rule["id"],
                        "category": rule["category"],
                        "severity": rule["severity"],
                        "alert_en": rule["warning_en"],
                        "alert_ar": rule["warning_ar"],
                        "reason": "Direct contraindication with patient's chronic clinical condition."
                    })

        # 2. Check patient allergies
        for allergy in parsed_pt["allergies"]:
            if allergy and allergy in lower_claim:
                detected_alerts.append({
                    "rule_id": "ALGY-001",
                    "category": "KNOWN_PATIENT_ALLERGY",
                    "severity": "CRITICAL",
                    "alert_en": f"Patient has documented severe hypersensitivity to '{allergy.capitalize()}'. Exposure strictly contraindicated.",
                    "alert_ar": f"المريض لديه حساسية سريرية موثقة ومعروفة تجاه '{allergy}'. التعرض لهذا الدواء أو المادة محظور تماماً.",
                    "reason": "Direct match with active allergy record."
                })

        safe_for_patient = len(detected_alerts) == 0

        return {
            "patient_id": parsed_pt["id"],
            "patient_profile_title": patient_profile.get("profile_title", "Custom Patient"),
            "safe_for_patient": safe_for_patient,
            "alerts_count": len(detected_alerts),
            "alerts": detected_alerts,
            "fhir_version": "HL7 FHIR Release 4 (R4)",
            "evaluated_conditions_count": len(parsed_pt["conditions"]),
            "evaluated_medications_count": len(parsed_pt["medications"])
        }

FHIR_ENGINE = FHIRContextEngine()
