"""
evidentia.nlp — Text Normalization, Semantic Chunking, Claim Segmentation,
and Negation Analysis for Arabic and English medical claims.
Compatible with Python 3.10, 3.11, 3.12.
"""

from __future__ import annotations
import re
from typing import List, Dict, Any, Tuple

# Arabic diacritics and ligatures regex
AR_DIACRITICS = re.compile(r"[\u064B-\u0652\u0670\u0640]")
AR_ALEF_REGEX = re.compile(r"[إأآا]")
AR_YAA_REGEX = re.compile(r"[ىي]")
AR_HAA_REGEX = re.compile(r"[ةه]")

# Negation particles
AR_NEGATIONS = {
    "لا", "ليس", "ليست", "لم", "لن", "غير", "ما", "بدون", "بلا", "كلا", "ممنوع", "إياك", "حذار"
}
EN_NEGATIONS = {
    "not", "never", "no", "cannot", "can't", "won't", "doesn't", "don't",
    "shouldn't", "isn't", "aren't", "neither", "nor", "none", "without", "hardly"
}

# Critical medical entities where mismatch implies distinct conditions
MEDICAL_ENTITIES = {
    "sprain", "fracture", "break", "tear", "strain", "dislocation",
    "baby", "infant", "child", "adult", "pregnant",
    "antibiotic", "virus", "bacteria", "fungus", "infection",
    "vaccine", "autism", "fever", "paracetamol", "ibuprofen", "aspirin",
    "depression", "adhd", "anxiety", "schizophrenia", "bipolar",
    "eczema", "psoriasis", "melanoma", "acne", "rash",
    "كسر", "التواء", "تمزق", "خلع", "رضة",
    "رضيع", "طفل", "بالغ", "حامل",
    "مضاد_حيوي", "فيروس", "بكتيريا", "فطريات", "عدوى",
    "لقاح", "توحد", "حمى", "باراسيتامول", "ايبوبروفين", "اسبرين",
    "اكتئاب", "فرط_الحركة", "قلق", "صدفية", "اكزيما", "حب_الشباب"
}

def normalize_text(text: str, lang: str = "auto") -> str:
    """Normalizes text for matching: strips diacritics, unifies letters, lowercases."""
    if not text:
        return ""
    text = text.strip()

    # Detect language if auto
    has_arabic = bool(re.search(r"[\u0600-\u06FF]", text))
    if has_arabic or lang == "ar":
        # Remove Arabic tashkeel & tatweel
        text = AR_DIACRITICS.sub("", text)
        text = AR_ALEF_REGEX.sub("ا", text)
        text = AR_YAA_REGEX.sub("ي", text)
        text = AR_HAA_REGEX.sub("ه", text)

    # Standard clean-up
    text = text.lower()
    text = re.sub(r"[^\w\s\u0600-\u06FF]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def tokenize(text: str) -> List[str]:
    """Tokenizes normalized text into words."""
    norm = normalize_text(text)
    return [w for w in norm.split() if w]


def detect_negation(text: str) -> bool:
    """Detects whether a sentence or claim expresses a negative stance."""
    tokens = tokenize(text)
    for tok in tokens:
        if tok in AR_NEGATIONS or tok in EN_NEGATIONS:
            return True
    return False


def is_affirmatively_phrased(statement: str) -> bool:
    """
    Enforces the Evidentia architectural rule:
    Evidence library statements must be phrased affirmatively to prevent false negation flips.
    """
    return not detect_negation(statement)


def extract_medical_entities(text: str) -> set[str]:
    """Extracts known medical keywords to detect look-alike claims."""
    norm = normalize_text(text)
    tokens = set(norm.split())
    found = set()
    for ent in MEDICAL_ENTITIES:
        ent_norm = normalize_text(ent)
        if ent_norm in tokens or ent_norm in norm:
            found.add(ent)
    return found


def calculate_entity_mismatch_penalty(claim_entities: set[str], evidence_entities: set[str]) -> float:
    """
    Returns a penalty between 0.0 and 0.5 if a claim contains distinct medical entities
    that the evidence statement does not address (e.g. 'sprain' vs 'fracture').
    """
    if not claim_entities:
        return 0.0
    missing = claim_entities - evidence_entities
    if missing:
        # e.g., claim talks about 'fracture' while evidence is only about 'sprain'
        return min(0.45, len(missing) * 0.25)
    return 0.0


def split_claims(text: str) -> List[str]:
    """
    Splits a user health post or article into individual testable claims.
    Handles sentence delimiters, Arabic conjunctions (و، فـ، لكن), and bullet points.
    """
    if not text or not text.strip():
        return []

    # Clean lines
    lines = [line.strip("-*• \t\r") for line in text.splitlines() if line.strip()]
    raw_sentences: List[str] = []

    for line in lines:
        # Split by punctuation (. ? ! ؛ ;)
        parts = re.split(r"[.?!؛;]+", line)
        for p in parts:
            p_clean = p.strip()
            if p_clean:
                # Also split by strong Arabic conjunctions if long enough
                if len(p_clean) > 80 and (" ولكن " in p_clean or " غير أن " in p_clean or " بينما " in p_clean):
                    subparts = re.split(r"\s+(?:ولكن|غير أن|بينما|however|whereas|but)\s+", p_clean, flags=re.IGNORECASE)
                    raw_sentences.extend([s.strip() for s in subparts if s.strip()])
                else:
                    raw_sentences.append(p_clean)

    # Filter out empty or trivial phrases (under 3 words)
    claims = [s for s in raw_sentences if len(s.split()) >= 3]
    return claims if claims else [text.strip()]


class ChunkingStrategy:
    """Advanced chunking strategies for RAG document processing."""

    @staticmethod
    def sliding_window(text: str, chunk_size: int = 150, overlap: int = 30) -> List[Dict[str, Any]]:
        """Splits text by token length with specified overlap."""
        tokens = text.split()
        if not tokens:
            return []
        chunks = []
        step = max(1, chunk_size - overlap)
        chunk_idx = 0
        for i in range(0, len(tokens), step):
            window = tokens[i : i + chunk_size]
            chunk_text = " ".join(window)
            chunks.append({
                "chunk_id": f"chunk_{chunk_idx}",
                "text": chunk_text,
                "start_token": i,
                "end_token": i + len(window),
                "strategy": "sliding_window"
            })
            chunk_idx += 1
            if i + chunk_size >= len(tokens):
                break
        return chunks

    @staticmethod
    def paragraph_boundary(text: str, min_chars: int = 50) -> List[Dict[str, Any]]:
        """Splits text naturally along paragraphs and double newlines."""
        raw_paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
        chunks = []
        for idx, p in enumerate(raw_paras):
            if len(p) >= min_chars:
                chunks.append({
                    "chunk_id": f"para_{idx}",
                    "text": p,
                    "length": len(p),
                    "strategy": "paragraph_boundary"
                })
        return chunks

    @staticmethod
    def semantic_claim_boundary(text: str) -> List[Dict[str, Any]]:
        """Splits text into discrete medical claims for atomic verification."""
        claims = split_claims(text)
        return [
            {
                "chunk_id": f"claim_{idx}",
                "text": c,
                "entities": list(extract_medical_entities(c)),
                "strategy": "semantic_claim"
            }
            for idx, c in enumerate(claims)
        ]
