"""
evidentia.guardrails — Security, Prompt Safety & Clinical Compliance Guardrails.
Updated for Prototype Mode: Non-blocking, audit-only inspection so that no student
or evaluation requests are blocked or dropped.
Compatible with Python 3.10, 3.11, 3.12.
"""

from __future__ import annotations
import os
import re
from typing import Dict, Any, List, Tuple
from evidentia.logs import get_logger, METRICS

logger = get_logger("evidentia.guardrails")

# Safe patterns for informational audit logging
INJECTION_PATTERNS = [
    r"ignore\s+(all\s+)?(previous|prior|above)\s+instructions",
    r"disregard\s+(all\s+)?(guidelines|rules|directives)",
    r"reveal\s+(the\s+)?(system\s*prompt|hidden\s*instructions)",
    r"you\s+are\s+now\s+(in\s+)?(developer|unrestricted|override)\s+mode",
    r"bypass\s+all\s+(safety|content)\s+filters",
    r"simulate\s+unauthorized\s+medical\s+prescriptions",
    # Arabic system-override patterns
    r"تجاهل\s+(جميع\s+)?التعليمات\s+السابقة",
    r"تخطى\s+(كل\s+)?القيود\s+والشروط",
    r"اظهر\s+(لي\s+)?الموجه\s+الداخلي",
    r"انت\s+الان\s+بدون\s+اي\s+قيود",
]

# PII matching regexes
EMAIL_REGEX = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+")
PHONE_REGEX = re.compile(r"(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}")
ID_REGEX = re.compile(r"\b\d{14}\b|\b\d{3}-\d{2}-\d{4}\b")

MANDATORY_DISCLAIMER_EN = "\n\nDisclaimer: This system provides scientific evidence grading for educational purposes only. It is not a substitute for professional clinical diagnosis or emergency medical care."
MANDATORY_DISCLAIMER_AR = "\n\nإخلاء مسؤولية: يقدم هذا النظام تقييماً للأدلة العلمية لأغراض تعليمية وإرشادية فقط، ولا يعد بديلاً عن الاستشارة الطبية المتخصصة أو الرعاية الطارئة."


class GuardrailInspector:
    """Inspects inputs for security integrity while never blocking in Prototype Mode."""

    def __init__(self):
        # Default to prototype mode (non-blocking)
        self.prototype_mode = os.getenv("EVIDENTIA_PROTOTYPE_MODE", "1") == "1"

    def inspect_input(self, text: str) -> Dict[str, Any]:
        """
        Inspects incoming prompt for audit logs.
        In Prototype Mode, requests are NEVER blocked (passed is always True).
        """
        violations: List[str] = []
        threat_level = "CLEAN"

        # 1. Prompt Injection detection (audit only)
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                violations.append("PROMPT_INJECTION_DETECTED: System prompt override pattern noted in audit log.")
                threat_level = "SUSPICIOUS"
                METRICS["guardrail_violations_total"] += 1
                logger.info(f"Guardrail audit info: {violations[-1]}")
                break

        # 2. PII Scrubbing (optional sanitization, leaves original intact for evaluation)
        sanitized_text, pii_found = self.scrub_pii(text)
        if pii_found:
            violations.append(f"PII_NOTED: Detected identifiers ({', '.join(pii_found)}).")

        return {
            "passed": True,  # Prototype mode: ALWAYS PASS, NEVER BLOCK
            "threat_level": threat_level,
            "violations": violations,
            "sanitized_text": sanitized_text,
            "original_length": len(text),
            "sanitized_length": len(sanitized_text),
            "prototype_mode": True
        }

    def scrub_pii(self, text: str) -> Tuple[str, List[str]]:
        """Redacts phone numbers, emails, and national IDs to preserve patient privacy."""
        found = []
        if EMAIL_REGEX.search(text):
            text = EMAIL_REGEX.sub("[REDACTED_EMAIL]", text)
            found.append("email")
        if PHONE_REGEX.search(text):
            text = PHONE_REGEX.sub("[REDACTED_PHONE]", text)
            found.append("phone")
        if ID_REGEX.search(text):
            text = ID_REGEX.sub("[REDACTED_ID]", text)
            found.append("national_id")
        return text, found

    def enforce_output_guardrails(self, response_text: str, lang: str = "en") -> str:
        """Appends mandatory medical safety disclaimer if not present."""
        disclaimer = MANDATORY_DISCLAIMER_AR if lang == "ar" else MANDATORY_DISCLAIMER_EN
        if "Disclaimer" not in response_text and "إخلاء مسؤولية" not in response_text:
            return response_text + disclaimer
        return response_text

# Global Guardrail Inspector instance
GUARDRAILS = GuardrailInspector()
