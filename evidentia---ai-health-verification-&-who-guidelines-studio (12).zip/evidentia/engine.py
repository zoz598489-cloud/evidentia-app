"""
evidentia.engine — Scientific Evidence Court, Claim-Evidence Mapping,
AI Disagreement Detection, and Intelligent Abstention Engine.
Compatible with Python 3.10, 3.11, 3.12.
"""

from __future__ import annotations
import time
from typing import Dict, Any, List, Optional
from evidentia.nlp import split_claims, normalize_text, detect_negation
from evidentia.rag import RAG, SearchResult
from evidentia.providers import ORCHESTRATOR
from evidentia.guardrails import GUARDRAILS
from evidentia.memory import MEMORY
from evidentia.cache import SEMANTIC_CACHE
from evidentia.logs import get_logger
from evidentia.fhir import FHIR_ENGINE, SAMPLE_FHIR_PROFILES
from evidentia.authoritative_sources import AUTHORITATIVE_REGISTRY

logger = get_logger("evidentia.engine")

DEFINITIVE_SIM_THRESHOLD = 0.50  # Must have >= 0.50 similarity to issue definitive verdict

class VerificationEngine:
    """Enterprise Health Claim Verification & Scientific Evidence Court."""

    def safety_triage(self, text: str) -> Optional[Dict[str, Any]]:
        """Checks for immediate medical emergencies or mental health crises."""
        lower = text.lower()
        if any(w in lower for w in ["suicide", "انتحار", "kill myself", "انهي حياتي", "overdose"]):
            return {
                "triage_alert": "CRISIS_INTERVENTION",
                "urgency": "IMMEDIATE",
                "message": (
                    "If you or someone you know is struggling or in crisis, help is available. "
                    "In the US, call or text 988. In the UK, call 111. In Egypt, call 080-8880700 or local emergency 123."
                ),
                "message_ar": (
                    "إذا كنت أنت أو أي شخص تعرفه يمر بأزمة نفسية أو خطر فوري، يرجى طلب المساعدة فوراً. "
                    "في مصر، اتصل بالخط الساخن للأمانة العامة للصحة النفسية: 080-8880700 أو الطوارئ 123. خط النجدة متاح دائماً."
                ),
                "action_required": "SEEK_IMMEDIATE_PROFESSIONAL_HELP"
            }
        return None

    def check_claim(
        self,
        claim: str,
        lang: str = "auto",
        culture: str = "generic",
        models: Optional[List[str]] = None,
        patient_profile: Optional[Dict[str, Any] | str] = None
    ) -> Dict[str, Any]:
        """
        Verifies a single medical claim against the Scientific Evidence Court.
        Applies Intelligent Abstention Engine if evidence is insufficient,
        and evaluates personalized patient contraindications via HL7 FHIR.
        """
        claim_has_negation = detect_negation(claim)

        # 1. Retrieve top matching evidence from RAG knowledge base
        search_results: List[SearchResult] = RAG.retrieve_evidence_for_claim(claim, top_k=3)
        top_match = search_results[0] if search_results else None
        top_score = top_match.score if top_match else 0.0

        # 2. Intelligent Abstention Engine logic
        abstained = False
        abstain_reason = None
        verdict = "UNCERTAIN"
        confidence = round(top_score, 2)

        if not top_match or top_score < 0.25:
            abstained = True
            abstain_reason = "no_matching_evidence"
            verdict = "ABSTAIN_NO_EVIDENCE"
            explanation = "No indexed clinical guideline or peer-reviewed evidence matches this specific claim."
        elif top_score < DEFINITIVE_SIM_THRESHOLD:
            abstained = True
            abstain_reason = "low_confidence_match"
            verdict = "ABSTAIN_LOW_CONFIDENCE"
            explanation = f"Top evidence match is tangential (score: {top_score:.2f} < 0.50). Abstaining to prevent misattribution."
        else:
            # We have solid evidence (score >= 0.50)
            # Check negation inversion: affirmative evidence + negated user claim = REFUTED
            if claim_has_negation:
                verdict = "REFUTED"
                explanation = f"Clinical consensus contradicts the negative phrasing: {top_match.doc.text}"
            else:
                verdict = "VERIFIED_ACCURATE"
                explanation = f"Supported by {top_match.doc.metadata.get('authority', 'Authoritative source')}: {top_match.doc.text}"

        # 3. AI Disagreement Detector cross-check
        disagreement_info = ORCHESTRATOR.cross_check_claim(
            claim=claim,
            evidence_context=top_match.doc.text if top_match else "",
            models=models
        )

        # If models disagree and our evidence is borderline, abstain safely
        if disagreement_info["disagreement_detected"] and top_score < 0.70:
            abstained = True
            abstain_reason = "models_disagree_insufficient_evidence"
            verdict = "ABSTAIN_DISAGREEMENT"
            explanation = "External AI models produced conflicting stances and local evidence is insufficient to break the tie."

        # 4. HL7 FHIR Patient-Specific Contextual Evaluation
        fhir_evaluation = None
        if patient_profile:
            p_obj = SAMPLE_FHIR_PROFILES.get(patient_profile) if isinstance(patient_profile, str) else patient_profile
            if p_obj:
                fhir_evaluation = FHIR_ENGINE.evaluate_claim_with_patient(claim, p_obj)

        # 5. Cultural adaptation of guidance (Egypt, US, Gulf, Generic)
        practical_advice = self._adapt_advice(verdict, top_match, culture)

        # 6. Global Authoritative Sources (WHO, CDC, Cochrane, NIH) Cross-Reference
        authoritative_report = AUTHORITATIVE_REGISTRY.verify_against_who_and_authorities(claim)

        return {
            "claim": claim,
            "verdict": verdict,
            "abstained": abstained,
            "abstain_reason": abstain_reason,
            "confidence": confidence,
            "match_score": top_score,
            "scientific_court": {
                "matched_evidence": top_match.doc.to_dict() if top_match else None,
                "evidence_level": top_match.doc.metadata.get("evidence_level") if top_match else "Unranked",
                "authority": top_match.doc.metadata.get("authority") if top_match else "None",
                "pmid": top_match.doc.metadata.get("pmid") if top_match else None,
                "doi": top_match.doc.metadata.get("doi") if top_match else None,
                "pubmed_url": top_match.doc.metadata.get("pubmed_url") if top_match else None,
            },
            "authoritative_concurrence": authoritative_report,
            "explanation": explanation,
            "practical_advice": practical_advice,
            "ai_disagreement": disagreement_info,
            "fhir_evaluation": fhir_evaluation,
            "timestamp": time.time(),
        }

    def _adapt_advice(self, verdict: str, top_match: Optional[SearchResult], culture: str) -> Dict[str, str]:
        """Provides culturally grounded, practical next steps without altering the science."""
        if culture == "eg":
            return {
                "lifestyle_note": "يمكنك استشارة طبيب الرعاية الأولية في المركز الصحي أو التأمين الصحي الشامل.",
                "practical_tip": "تجنب الوصفات العشبية غير الموثقة كبديل للأدوية الأساسية."
            }
        elif culture == "us":
            return {
                "lifestyle_note": "Consult your primary care physician or board-certified specialist.",
                "practical_tip": "Check FDA-approved medication guides before adjusting treatment plans."
            }
        return {
            "lifestyle_note": "Consult a licensed healthcare professional for individualized diagnostic assessment.",
            "practical_tip": "Follow established clinical practice guidelines from accredited health agencies."
        }

    def verify_full_post(
        self,
        text: str,
        session_id: Optional[str] = None,
        lang: str = "auto",
        culture: str = "generic",
        models: Optional[List[str]] = None,
        use_cache: bool = True,
        patient_profile: Optional[Dict[str, Any] | str] = None
    ) -> Dict[str, Any]:
        """
        Full End-to-End AI Pipeline execution:
        1. Guardrails & Safety Inspection
        2. Emergency Triage Check
        3. Semantic Cache Lookup (instant latency drop)
        4. Claim Breakdown & Normalization
        5. Scientific Evidence Court Verification
        6. HL7 FHIR Patient Context & Contraindications
        7. Memory Context update
        8. Cache Store & Output Guardrails
        """
        start_time = time.time()

        # Step 1: Input Inspection (Prototype Mode: Non-blocking audit)
        guardrail_report = GUARDRAILS.inspect_input(text)
        sanitized_input = guardrail_report.get("sanitized_text", text)

        # Step 2: Emergency Safety Triage
        triage = self.safety_triage(sanitized_input)
        if triage:
            return {
                "status": "TRIAGE_EMERGENCY",
                "triage": triage,
                "input": sanitized_input,
                "duration_ms": round((time.time() - start_time) * 1000, 2)
            }

        # Step 3: Semantic Cache Lookup (Bypass cache if patient-specific evaluation requested)
        if use_cache and not patient_profile:
            cached_data, sim_score = SEMANTIC_CACHE.lookup(sanitized_input)
            if cached_data:
                cached_data["cached"] = True
                cached_data["cache_similarity"] = sim_score
                cached_data["duration_ms"] = round((time.time() - start_time) * 1000, 2)
                return cached_data

        # Step 4: Claim Segmentation
        extracted_claims = split_claims(sanitized_input)

        # Step 5: Verification of each claim
        claim_verdicts = []
        for claim in extracted_claims:
            verdict = self.check_claim(
                claim,
                lang=lang,
                culture=culture,
                models=models,
                patient_profile=patient_profile
            )
            claim_verdicts.append(verdict)

        # Overall summary verdict
        any_refuted = any(c["verdict"] == "REFUTED" for c in claim_verdicts)
        all_verified = all(c["verdict"] == "VERIFIED_ACCURATE" for c in claim_verdicts)
        any_abstained = any(c["abstained"] for c in claim_verdicts)

        if any_refuted:
            overall_verdict = "CONTAINS_FALSE_CLAIMS"
        elif all_verified:
            overall_verdict = "EVIDENCE_BACKED"
        elif any_abstained:
            overall_verdict = "PARTIALLY_UNCONFIRMED_ABSTAINED"
        else:
            overall_verdict = "MIXED_OR_INCONCLUSIVE"

        # Overall FHIR safety summary
        patient_summary = None
        if patient_profile:
            all_alerts = []
            for cv in claim_verdicts:
                if cv.get("fhir_evaluation") and cv["fhir_evaluation"].get("alerts"):
                    all_alerts.extend(cv["fhir_evaluation"]["alerts"])
            p_obj = SAMPLE_FHIR_PROFILES.get(patient_profile) if isinstance(patient_profile, str) else patient_profile
            patient_summary = {
                "patient_id": p_obj.get("id") if p_obj else "CUSTOM",
                "profile_title": p_obj.get("profile_title") if p_obj else "Custom Patient Profile",
                "safe_for_patient": len(all_alerts) == 0,
                "total_alerts": len(all_alerts),
                "alerts": all_alerts
            }

        # Step 6: Memory update
        if session_id:
            sess = MEMORY.get_or_create_session(session_id)
            sess.add_interaction(
                user_message=sanitized_input,
                assistant_message=f"Overall assessment: {overall_verdict}. Evaluated {len(claim_verdicts)} claims.",
                verified_claims=claim_verdicts
            )

        # Aggregate Authoritative Health Bodies Consulted (WHO, CDC, Cochrane, NIH)
        all_citations = []
        who_validated = False
        for cv in claim_verdicts:
            auth_concurrence = cv.get("authoritative_concurrence", {})
            if auth_concurrence.get("who_concurrence", {}).get("concurred"):
                who_validated = True
            all_citations.extend(auth_concurrence.get("evidence_citations", []))

        seen_urls = set()
        deduped_citations = []
        for cit in all_citations:
            if cit["url"] not in seen_urls:
                seen_urls.add(cit["url"])
                deduped_citations.append(cit)

        duration_ms = round((time.time() - start_time) * 1000, 2)
        response_payload = {
            "status": "COMPLETED",
            "overall_verdict": overall_verdict,
            "claims_count": len(claim_verdicts),
            "claims": claim_verdicts,
            "patient_context": patient_summary,
            "authoritative_summary": {
                "who_validated": who_validated,
                "authorities_consulted": ["WHO", "CDC", "Cochrane", "NIH/PubMed", "NICE"],
                "citations_count": len(deduped_citations),
                "citations": deduped_citations
            },
            "guardrail_report": guardrail_report,
            "duration_ms": duration_ms,
            "cached": False,
            "session_id": session_id,
            "disclaimer": GUARDRAILS.enforce_output_guardrails("", lang="ar" if lang == "ar" else "en").strip()
        }

        # Step 7: Store in Semantic Cache for future queries (if generic, not patient-specific)
        if use_cache and not patient_profile:
            SEMANTIC_CACHE.store(sanitized_input, response_payload)

        return response_payload

# Global Verification Engine instance
ENGINE = VerificationEngine()
