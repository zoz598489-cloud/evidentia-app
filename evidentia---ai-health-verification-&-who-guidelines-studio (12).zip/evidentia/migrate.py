"""
evidentia.migrate — Database Migration CLI.
Usage:
  python -m evidentia.migrate status
  python -m evidentia.migrate up
  python -m evidentia.migrate backup
  python -m evidentia.migrate new <name>
"""

import sys
import os
from pathlib import Path
from evidentia.db import MigrationRunner, MIGRATIONS_DIR

def main():
    args = sys.argv[1:]
    command = args[0] if args else "status"
    runner = MigrationRunner()

    if command == "status":
        items = runner.status()
        print("\n--- Evidentia Migration Status ---")
        for item in items:
            state = "[APPLIED]" if item["applied"] else "[PENDING]"
            check = "✓ Checksum OK" if item.get("checksum_match") is True else ("(Pending)" if not item["applied"] else "✗ MISMATCH")
            print(f"{state} {item['id']} ({item['file']}) - {check}")
        print("----------------------------------\n")

    elif command == "up":
        applied = runner.migrate_up()
        if applied:
            print(f"Successfully applied {len(applied)} migrations: {', '.join(applied)}")
        else:
            print("Database is already up to date.")

    elif command == "backup":
        bk = runner.backup_database()
        if bk:
            print(f"Created database backup: {bk}")
        else:
            print("No existing database to backup.")

    elif command == "new":
        if len(args) < 2:
            print("Error: Specify a migration name, e.g. python -m evidentia.migrate new add_embeddings")
            sys.exit(1)
        name = args[1].strip().lower().replace(" ", "_")
        existing = runner.get_migration_files()
        next_num = len(existing) + 1
        filename = f"{next_num:03d}_{name}.sql"
        new_path = MIGRATIONS_DIR / filename
        new_path.write_text(f"-- Migration {next_num:03d}: {name}\n\n", encoding="utf-8")
        print(f"Created new migration: {new_path}")

    else:
        print(f"Unknown command '{command}'. Available: status | up | backup | new <name>")
        sys.exit(1)

if __name__ == "__main__":
    main()
