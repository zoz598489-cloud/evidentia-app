"""
evidentia.logs — Structured JSON logging, Request Tracking, Sentry Integration, and Metrics.
Guaranteed compatibility with Python 3.10, 3.11, and 3.12.
"""

from __future__ import annotations
import json
import logging
import os
import sys
import time
import uuid
from typing import Any, Dict, Optional

# Metrics store in-memory
METRICS: Dict[str, Any] = {
    "requests_total": 0,
    "requests_by_status": {},
    "requests_by_route": {},
    "ai_queries_total": 0,
    "ai_fallbacks_total": 0,
    "cache_hits_total": 0,
    "cache_misses_total": 0,
    "guardrail_violations_total": 0,
    "latencies_ms": [],
}

class JsonFormatter(logging.Formatter):
    """Formats log records as structured single-line JSON without PII."""
    def format(self, record: logging.LogRecord) -> str:
        payload: Dict[str, Any] = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if hasattr(record, "request_id"):
            payload["request_id"] = record.request_id
        if hasattr(record, "method"):
            payload["method"] = record.method
        if hasattr(record, "path"):
            payload["path"] = record.path
        if hasattr(record, "status"):
            payload["status"] = record.status
        if hasattr(record, "duration_ms"):
            payload["duration_ms"] = record.duration_ms
        if hasattr(record, "extra_data") and isinstance(record.extra_data, dict):
            # scrub PII before writing
            payload.update({k: v for k, v in record.extra_data.items() if k not in ("ip", "query", "body", "token")})
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def setup_sentry() -> bool:
    """
    Initializes Sentry SDK if SENTRY_DSN is set and sentry_sdk is installed.
    Configured with strict PII scrubbing for health-claim privacy.
    """
    dsn = os.getenv("SENTRY_DSN", "").strip()
    if not dsn:
        return False
    try:
        import sentry_sdk
        from sentry_sdk.integrations.logging import LoggingIntegration

        def before_send(event: Dict[str, Any], hint: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            # Scrub user IP and potential health statements from tags or request bodies
            if "user" in event:
                event["user"].pop("ip_address", None)
            if "request" in event:
                req = event["request"]
                req.pop("data", None)
                if "headers" in req:
                    req["headers"].pop("Authorization", None)
                    req["headers"].pop("X-Admin-Key", None)
                    req["headers"].pop("X-Expert-Token", None)
            return event

        sentry_sdk.init(
            dsn=dsn,
            traces_sample_rate=float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", "0.2")),
            environment=os.getenv("EVIDENTIA_ENV", "production"),
            release=os.getenv("EVIDENTIA_VERSION", "2.0.0"),
            integrations=[LoggingIntegration(level=logging.INFO, event_level=logging.ERROR)],
            before_send=before_send,
            send_default_pii=False,
        )
        return True
    except ImportError:
        logging.getLogger("evidentia").warning("SENTRY_DSN provided but sentry-sdk package is not installed.")
        return False
    except Exception as e:
        logging.getLogger("evidentia").error(f"Failed to initialize Sentry: {e}")
        return False


def get_logger(name: str = "evidentia") -> logging.Logger:
    """Returns a configured logger with JSON formatting."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        level_name = os.getenv("EVIDENTIA_LOG_LEVEL", "INFO").upper()
        logger.setLevel(getattr(logging, level_name, logging.INFO))
        handler = logging.StreamHandler(sys.stdout)
        fmt_type = os.getenv("EVIDENTIA_LOG_FORMAT", "json").lower()
        if fmt_type == "json":
            handler.setFormatter(JsonFormatter(datefmt="%Y-%m-%dT%H:%M:%SZ"))
        else:
            handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s"))
        logger.addHandler(handler)
        logger.propagate = False
    return logger


def record_request_metric(method: str, route: str, status: int, duration_ms: float) -> None:
    """Aggregates HTTP request metrics."""
    METRICS["requests_total"] += 1
    status_key = f"{status // 100}xx"
    METRICS["requests_by_status"][status_key] = METRICS["requests_by_status"].get(status_key, 0) + 1
    METRICS["requests_by_route"][route] = METRICS["requests_by_route"].get(route, 0) + 1
    METRICS["latencies_ms"].append(round(duration_ms, 2))
    if len(METRICS["latencies_ms"]) > 1000:
        METRICS["latencies_ms"] = METRICS["latencies_ms"][-500:]


def get_metrics_summary() -> Dict[str, Any]:
    """Computes summary statistics for Prometheus or /metrics endpoint."""
    latencies = sorted(METRICS["latencies_ms"])
    p50 = latencies[len(latencies) // 2] if latencies else 0.0
    p95 = latencies[int(len(latencies) * 0.95)] if latencies else 0.0
    p99 = latencies[int(len(latencies) * 0.99)] if latencies else 0.0

    return {
        "requests_total": METRICS["requests_total"],
        "requests_by_status": METRICS["requests_by_status"],
        "requests_by_route": METRICS["requests_by_route"],
        "ai_queries_total": METRICS["ai_queries_total"],
        "ai_fallbacks_total": METRICS["ai_fallbacks_total"],
        "cache": {
            "hits": METRICS["cache_hits_total"],
            "misses": METRICS["cache_misses_total"],
            "hit_ratio": round(METRICS["cache_hits_total"] / max(1, (METRICS["cache_hits_total"] + METRICS["cache_misses_total"])), 3)
        },
        "guardrail_violations": METRICS["guardrail_violations_total"],
        "latency_ms": {
            "p50": p50,
            "p95": p95,
            "p99": p99,
        }
    }
