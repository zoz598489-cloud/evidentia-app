/**
 * Osler's Hippocrates - Complete 65-Question Master Evaluation Bank
 * Source: Osler_s_Hippocrates_-_Complete_65-Question_Evaluation___Awareness_Master_Bank_9a766bea.pdf
 * Contains 4 Sections:
 * 1. Demographics & Privacy (Q1 - Q5)
 * 2. UX & Platform Journey (Q6 - Q15)
 * 3. Health & Skin Awareness Quiz (Q16 - Q50) [35 Questions]
 * 4. Advanced Optional Expert & Engineer Section + General Feedback (Q51 - Q65) [15 Questions]
 */

export interface MasterQuestion {
  id: string; // e.g., 'q1', 'q2', ... 'q65'
  number: number;
  section: 1 | 2 | 3 | 4;
  type: 'email' | 'text' | 'textarea' | 'choice' | 'scale' | 'boolean' | 'disclaimer';
  titleAr: string;
  titleEn: string;
  descriptionAr?: string;
  descriptionEn?: string;
  required: boolean;
  options?: {
    value: string;
    labelAr: string;
    labelEn: string;
    isCorrect?: boolean;
  }[];
  scaleMin?: number;
  scaleMax?: number;
  scaleLabels?: { minAr: string; maxAr: string; minEn: string; maxEn: string };
  citation?: string;
  targetRole?: 'all' | 'clinicians' | 'engineers';
}

export const MASTER_SECTIONS = [
  {
    id: 1,
    titleAr: "1. بيانات المستخدم والتفضيلات الأمنية (Demographics & Privacy)",
    titleEn: "1. User Demographics & Privacy Preferences",
    rangeText: "أسئلة 1 - 5",
    badge: "إلزامي / Mandatory",
    descriptionAr: "حقول التحقق من الهوية وحفظ الردود بشكل محمي ومقيد للمالك فقط",
    descriptionEn: "Identity verification fields and strict owner-restricted access control"
  },
  {
    id: 2,
    titleAr: "2. تجربة المنصة ورحلة الادعاء الطبي (UX & Platform Journey)",
    titleEn: "2. Platform Experience & Clinical Verification Journey",
    rangeText: "أسئلة 6 - 15",
    badge: "تجربة المستخدم / UX Audit",
    descriptionAr: "تقييم وضوح تدفق الفحص، مؤشر الثقة، والإقرار الطبي الإلزامي",
    descriptionEn: "Assessment of claim ingestion clarity, confidence score, and mandatory disclaimer"
  },
  {
    id: 3,
    titleAr: "3. بنك التوعية الصحية وأمراض الجلد والبيئة الاجتماعية (Health & Skin Awareness)",
    titleEn: "3. Clinical Health, Dermatology & Social Awareness Quiz",
    rangeText: "أسئلة 16 - 50 (35 سؤالاً)",
    badge: "اختبار معتمد 35 نقطة / 35-Pt Quiz",
    descriptionAr: "اختبار توعوي وسريري مبني على معايير منظمة الصحة العالمية (WHO) وأدلة NHS و Cochrane",
    descriptionEn: "Clinical awareness assessment based on WHO guidelines, NHS, and Cochrane meta-analyses"
  },
  {
    id: 4,
    titleAr: "4. القسم الاختياري المتقدم للخبراء والمهندسين (Optional Advanced Section)",
    titleEn: "4. Advanced Expert & System Architecture Feedback",
    rangeText: "أسئلة 51 - 65 (15 سؤالاً)",
    badge: "اختياري متقدم / Optional",
    descriptionAr: "ملاحظات الأطباء السريريين ومهندسي الذكاء الاصطناعي حول RAG و Semantic Cache",
    descriptionEn: "Clinical and systems engineering feedback on Hybrid RAG, Semantic Cache, and Failover"
  }
];

export const MASTER_QUESTIONS_65: MasterQuestion[] = [
  // ================= SECTION 1: DEMOGRAPHICS & PRIVACY (Q1 - Q5) =================
  {
    id: 'q1',
    number: 1,
    section: 1,
    type: 'email',
    titleAr: "س:1: البريد الإلكتروني (Mandatory Email Collection)",
    titleEn: "Q1: Respondent Email (Mandatory Email Collection)",
    descriptionAr: "حقل نصي إجباري ومتحقق منه لتأمين البيانات وحفظ الردود في ملف Google Sheets الخاص بـ zoz598489@gmail.com حصراً",
    descriptionEn: "Mandatory verified text field to ensure data integrity and route to owner sheet: zoz598489@gmail.com (Restricted)",
    required: true
  },
  {
    id: 'q2',
    number: 2,
    section: 1,
    type: 'choice',
    titleAr: "س:2: اختر لغة العرض / Preferred Language",
    titleEn: "Q2: Preferred Language / لغة العرض",
    required: true,
    options: [
      { value: 'ar', labelAr: "العربية", labelEn: "Arabic" },
      { value: 'en', labelAr: "English", labelEn: "English" }
    ]
  },
  {
    id: 'q3',
    number: 3,
    section: 1,
    type: 'text',
    titleAr: "س:3: الاسم الكامل (اختياري) / Full Name (Optional)",
    titleEn: "Q3: Full Name (Optional) / الاسم الكامل",
    required: false
  },
  {
    id: 'q4',
    number: 4,
    section: 1,
    type: 'choice',
    titleAr: "س:4: الفئة العمرية / Age Bracket",
    titleEn: "Q4: Age Bracket / الفئة العمرية",
    required: true,
    options: [
      { value: '<18', labelAr: "أقل من 18 سنة", labelEn: "Under 18" },
      { value: '18-30', labelAr: "18 - 30 سنة", labelEn: "18 - 30" },
      { value: '31-50', labelAr: "31 - 50 سنة", labelEn: "31 - 50" },
      { value: '>50', labelAr: "أكثر من 50 سنة", labelEn: "Over 50" }
    ]
  },
  {
    id: 'q5',
    number: 5,
    section: 1,
    type: 'text',
    titleAr: "س:5: مكان الإقامة الحالي (البلد والمدينة) / Location",
    titleEn: "Q5: Current Location (Country & City) / مكان الإقامة",
    descriptionAr: "حقل إجابة قصيرة ديناميكي لحفظ تفضيلات الدولة المختارة",
    descriptionEn: "Dynamic text field for country and city",
    required: true
  },

  // ================= SECTION 2: UX & PLATFORM JOURNEY (Q6 - Q15) =================
  {
    id: 'q6',
    number: 6,
    section: 2,
    type: 'choice',
    titleAr: "س:6: هل كانت خطوات إدخال الادعاء الطبي واستلام التقرير النهائي سهلة وسلسة؟",
    titleEn: "Q6: Was the user journey from claim input to the final verification report smooth and easy?",
    required: true,
    options: [
      { value: 'Yes', labelAr: "نعم", labelEn: "Yes" },
      { value: 'No', labelAr: "لا", labelEn: "No" }
    ]
  },
  {
    id: 'q7',
    number: 7,
    section: 2,
    type: 'choice',
    titleAr: "س:7: هل كان مؤشر درجة الثقة (Confidence Score) المئوي واضحاً ومفهوماً؟",
    titleEn: "Q7: Was the percentage Confidence Score clear and easy to understand?",
    required: true,
    options: [
      { value: 'Yes', labelAr: "نعم", labelEn: "Yes" },
      { value: 'No', labelAr: "لا", labelEn: "No" }
    ]
  },
  {
    id: 'q8',
    number: 8,
    section: 2,
    type: 'disclaimer',
    titleAr: "س:8: [إقرار إلزامي] هل تدرك أن منصة Osler's Hippocrates أداة تدقيق وتوعية ولا تستبدل الطبيب؟",
    titleEn: "Q8: [Mandatory Disclaimer] Do you acknowledge that Osler's Hippocrates is an educational/verification tool and does NOT replace a medical doctor?",
    required: true,
    options: [
      { value: 'agree', labelAr: "أقر وأفهم ذلك", labelEn: "I acknowledge and agree" },
      { value: 'disagree', labelAr: "لا أقر", labelEn: "I do not agree" }
    ]
  },
  {
    id: 'q9',
    number: 9,
    section: 2,
    type: 'scale',
    titleAr: "س:9: كيف تقيم تجربة المشاركة المباشرة بنقرة واحدة عبر واتساب (1-Click WhatsApp)؟",
    titleEn: "Q9: How do you rate the 1-click WhatsApp instant report sharing experience?",
    required: true,
    scaleMin: 1,
    scaleMax: 5,
    scaleLabels: { minAr: "1 (سيئة جداً)", maxAr: "5 (ممتازة)", minEn: "1 (Poor)", maxEn: "5 (Excellent)" }
  },
  {
    id: 'q10',
    number: 10,
    section: 2,
    type: 'choice',
    titleAr: "س:10: هل ساعدك الرابط الدائم (Permanent Link) في نشر الحقائق الطبية للآخرين؟",
    titleEn: "Q10: Did the Permanent Link feature help in sharing verified medical facts with others?",
    required: true,
    options: [
      { value: 'Yes', labelAr: "نعم", labelEn: "Yes" },
      { value: 'No', labelAr: "لا", labelEn: "No" }
    ]
  },
  {
    id: 'q11',
    number: 11,
    section: 2,
    type: 'choice',
    titleAr: "س:11: ما هو الوقت الاستغراقي التقريبي الذي واجهته للحصول على التقرير؟",
    titleEn: "Q11: What was the approximate turnaround latency experienced to generate your report?",
    required: true,
    options: [
      { value: '<1s', labelAr: "أقل من ثانية", labelEn: "Less than 1 second" },
      { value: '1-3s', labelAr: "1 - 3 ثوانٍ", labelEn: "1 - 3 seconds" },
      { value: '>5s', labelAr: "أكثر من 5 ثوانٍ", labelEn: "More than 5 seconds" }
    ]
  },
  {
    id: 'q12',
    number: 12,
    section: 2,
    type: 'choice',
    titleAr: "س:12: هل المراجع والمصادر الطبية السريرية في نهاية التقرير كانت واضحة وقابلة للنقر؟",
    titleEn: "Q12: Were the clinical references and authoritative citations at the end of the report clear and clickable?",
    required: true,
    options: [
      { value: 'Yes', labelAr: "نعم", labelEn: "Yes" },
      { value: 'No', labelAr: "لا", labelEn: "No" }
    ]
  },
  {
    id: 'q13',
    number: 13,
    section: 2,
    type: 'choice',
    titleAr: "س:13: هل تجد الواجهة البصرية المزدوجة (عربي/إنجليزي) مريحة أثناء الاستخدام؟",
    titleEn: "Q13: Do you find the bilingual visual interface (Arabic/English) comfortable and responsive?",
    required: true,
    options: [
      { value: 'Yes', labelAr: "نعم", labelEn: "Yes" },
      { value: 'No', labelAr: "لا", labelEn: "No" }
    ]
  },
  {
    id: 'q14',
    number: 14,
    section: 2,
    type: 'scale',
    titleAr: "س:14: ما مدى ثقتك في دقة التوثيق والمراجعات الطبية الصادرة من المنصة؟",
    titleEn: "Q14: What is your level of trust in the documentation and clinical citations provided by the platform?",
    required: true,
    scaleMin: 1,
    scaleMax: 5,
    scaleLabels: { minAr: "1 (منخفضة)", maxAr: "5 (عالية جداً)", minEn: "1 (Low)", maxEn: "5 (Very High)" }
  },
  {
    id: 'q15',
    number: 15,
    section: 2,
    type: 'textarea',
    titleAr: "س:15: ما هي اقتراحاتك لتطوير واجهة مستخدم Osler's Hippocrates؟",
    titleEn: "Q15: What are your suggestions to enhance Osler's Hippocrates user interface?",
    descriptionAr: "حقل نصي ممتد (فقرة)",
    descriptionEn: "Long-form paragraph response",
    required: false
  },

  // ================= SECTION 3: HEALTH & SKIN AWARENESS BANK (Q16 - Q50) [35 QUESTIONS] =================
  {
    id: 'q16',
    number: 16,
    section: 3,
    type: 'boolean',
    titleAr: "س:16: [True/False] الإكزيما التأتبية (Atopic Eczema) مرض جلدي غير معدٍ ولا ينقل باللمس.",
    titleEn: "Q16: [True/False] Atopic Eczema is a non-contagious skin condition and cannot be transmitted via physical touch.",
    required: true,
    citation: "معايير NHS وأدلة أمراض الجلد",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q17',
    number: 17,
    section: 3,
    type: 'boolean',
    titleAr: "س:17: [True/False] عدوى القوباء الحلقية (Ringworm) هي عدوى فطرية تنتقل عبر الأدوات والمناشف المشتركة.",
    titleEn: "Q17: [True/False] Ringworm (Tinea corporis) is a fungal infection that spreads via shared fomites like towels.",
    required: true,
    citation: "إرشادات منظمة الصحة العالمية (WHO) للعدوى الفطرية",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q18',
    number: 18,
    section: 3,
    type: 'choice',
    titleAr: "س:18: التصرف الصحيح والآمن عند ظهور طفح جلدي مفاجئ ومستمر هو:",
    titleEn: "Q18: What is the correct, safe course of action upon developing a sudden persistent skin rash?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( أخذ وصفة من وسائل التواصل الاجتماعي", labelEn: "A. Taking an unverified social media remedy", isCorrect: false },
      { value: 'B', labelAr: "ب( استشارة أخصائي جلدية معتمد", labelEn: "B. Consulting a certified dermatologist / clinician", isCorrect: true },
      { value: 'C', labelAr: "ج( استخدام كريم جيران", labelEn: "C. Borrowing a neighbor's leftover topical cream", isCorrect: false }
    ]
  },
  {
    id: 'q19',
    number: 19,
    section: 3,
    type: 'boolean',
    titleAr: "س:19: [True/False] تؤثر عادات النوم المنتظمة والدعم الأسري والبيئي مباشرة على الصحة النفسية للمراهقين.",
    titleEn: "Q19: [True/False] Regular sleep architecture, family stability, and social support directly impact adolescent mental health.",
    required: true,
    citation: "إرشادات منظمة الصحة العالمية (WHO) للصحة النفسية",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q20',
    number: 20,
    section: 3,
    type: 'boolean',
    titleAr: "س:20: [True/False] يمكن استخدام المضادات الحيوية لعلاج العدوى الفيروسية مثل الانفلونزا.",
    titleEn: "Q20: [True/False] Antibiotics can be used effectively to treat viral infections such as influenza and colds.",
    required: true,
    citation: "المضادات الحيوية تقتل البكتيريا فقط وليس الفيروسات (WHO AMR Guidelines)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: false },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: true }
    ]
  },
  {
    id: 'q21',
    number: 21,
    section: 3,
    type: 'choice',
    titleAr: "س:21: ما هي العلامة الأولية الرئيسية لارتفاع ضغط الدم القاتل الصامت؟",
    titleEn: "Q21: What is the primary hallmark presentation of high blood pressure (the silent killer)?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( ألم حاد بالشعر", labelEn: "A. Severe hair pain", isCorrect: false },
      { value: 'B', labelAr: "ب( غالباً لا توجد أعراض واضحة مسبقة", labelEn: "B. Often asymptomatic with no prior signs", isCorrect: true },
      { value: 'C', labelAr: "ج( تغير لون الأظافر", labelEn: "C. Instant nail discoloration", isCorrect: false }
    ]
  },
  {
    id: 'q22',
    number: 22,
    section: 3,
    type: 'boolean',
    titleAr: "س:22: [True/False] الممارسة الرياضية المعتدلة بانتظام تقلل من خطر الإصابة بأمراض القلب والأوعية.",
    titleEn: "Q22: [True/False] Consistent moderate aerobic exercise significantly lowers cardiovascular disease risks.",
    required: true,
    citation: "إرشادات جمعية القلب الأمريكية (AHA / WHO)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q23',
    number: 23,
    section: 3,
    type: 'boolean',
    titleAr: "س:23: [True/False] شرب الماء بكتل كبيرة ومفاجئة أثناء التمرين أفضل من الشرب المنتظم للجرعات.",
    titleEn: "Q23: [True/False] Chugging large boluses of water abruptly during heavy workout is superior to steady sipping.",
    required: true,
    citation: "فسيولوجيا الرياضة والترطيب (Sports Medicine Guidelines)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: false },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: true }
    ]
  },
  {
    id: 'q24',
    number: 24,
    section: 3,
    type: 'choice',
    titleAr: "س:24: الخطوة الأولى في الإسعاف الأولي لحروق الدرجة الأولى السطحية هي:",
    titleEn: "Q24: What is the proper first-aid step for superficial first-degree thermal burns?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( وضع الثلج المباشر", labelEn: "A. Applying direct ice chunks", isCorrect: false },
      { value: 'B', labelAr: "ب( تعريض الحرق للماء الجاري الفاتر", labelEn: "B. Cooling under cool/tepid running tap water", isCorrect: true },
      { value: 'C', labelAr: "ج( وضع معجون أسنان", labelEn: "C. Smearing toothpaste or butter", isCorrect: false }
    ]
  },
  {
    id: 'q25',
    number: 25,
    section: 3,
    type: 'boolean',
    titleAr: "س:25: [True/False] مرض السكري من النوع الثاني يمكن الحد من مخاطره وتجنبه باتباع نمط حياة صحي.",
    titleEn: "Q25: [True/False] Type 2 Diabetes onset can be largely prevented or delayed through healthy dietary and lifestyle habits.",
    required: true,
    citation: "معايير ADA والجمعية الدولية للسكري",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q26',
    number: 26,
    section: 3,
    type: 'boolean',
    titleAr: "س:26: [True/False] تجنب غسل الخضروات بالماء الجاري يكفي للتخلص من بقايا المبيدات الحشرية.",
    titleEn: "Q26: [True/False] Avoiding washing vegetables under running water is sufficient to remove pesticide residues.",
    required: true,
    citation: "إرشادات سلامة الغذاء (FDA / WHO Food Safety)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: false },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: true }
    ]
  },
  {
    id: 'q27',
    number: 27,
    section: 3,
    type: 'choice',
    titleAr: "س:27: ما هي النسبة التقديرية للبالغين الذين يعانون من مشاكل الأرق والاضطرابات المحددة للنوم؟",
    titleEn: "Q27: What is the approximate global prevalence of adults experiencing clinical insomnia or sleep disturbances?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( 5%", labelEn: "A. ~5%", isCorrect: false },
      { value: 'B', labelAr: "ب( حوالي 30%", labelEn: "B. Approximately ~30%", isCorrect: true },
      { value: 'C', labelAr: "ج( 80%", labelEn: "C. ~80%", isCorrect: false }
    ]
  },
  {
    id: 'q28',
    number: 28,
    section: 3,
    type: 'boolean',
    titleAr: "س:28: [True/False] الجفاف الخفيف يمكن أن يؤثر سلباً على التركيز والوظائف الإدراكية اليومية.",
    titleEn: "Q28: [True/False] Even mild hypohydration (1-2% fluid deficit) degrades cognitive focus, mood, and alertness.",
    required: true,
    citation: "دراسات الأداء الإدراكي والترطيب السريري",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q29',
    number: 29,
    section: 3,
    type: 'boolean',
    titleAr: "س:29: [True/False] السجائر الإلكترونية (Vapes) خالية تماماً من المخاطر والأضرار على الجهاز التنفسي.",
    titleEn: "Q29: [True/False] Electronic cigarettes (vapes) are completely free of pulmonary toxins and respiratory harms.",
    required: true,
    citation: "تحذيرات CDC ومنظمة الصحة العالمية (WHO Tobacco Free Initiative)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: false },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: true }
    ]
  },
  {
    id: 'q30',
    number: 30,
    section: 3,
    type: 'choice',
    titleAr: "س:30: السبب الرئيسي لتطور ظاهرة مقاومة مضادات البكتيريا (AMR) هو:",
    titleEn: "Q30: What is the foremost driver accelerating Antimicrobial Resistance (AMR)?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( شرب القهوة", labelEn: "A. Daily coffee consumption", isCorrect: false },
      { value: 'B', labelAr: "ب( الاستخدام المفرط والعشوائي للمضادات الحيوية", labelEn: "B. Overuse and indiscriminate misuse of antibiotics", isCorrect: true },
      { value: 'C', labelAr: "ج( ممارسة الرياضة", labelEn: "C. Regular physical exercise", isCorrect: false }
    ]
  },
  {
    id: 'q31',
    number: 31,
    section: 3,
    type: 'boolean',
    titleAr: "س:31: [True/False] فيتامين D يتم تصنيعه في الجسم عند التعرض المعتدل لأشعة الشمس.",
    titleEn: "Q31: [True/False] Vitamin D3 is endogenously synthesized in human skin upon moderate UVB sunlight exposure.",
    required: true,
    citation: "إرشادات الأكاديمية الأمريكية لطب الغدد الصماء",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q32',
    number: 32,
    section: 3,
    type: 'choice',
    titleAr: "س:32: ما هي الوجبة المثالية قبل التمارين الرياضية بكثافة متوسطة؟",
    titleEn: "Q32: What is the optimal pre-workout meal composition 2-3 hours prior to moderate training?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( وجبة دهنية ثقيلة", labelEn: "A. High-fat greasy fried food", isCorrect: false },
      { value: 'B', labelAr: "ب( كربوهيدرات معقدة مع كمية معتدلة من البروتين", labelEn: "B. Complex carbohydrates paired with moderate lean protein", isCorrect: true },
      { value: 'C', labelAr: "ج( الامتناع التام عن الأكل", labelEn: "C. Prolonged total fast", isCorrect: false }
    ]
  },
  {
    id: 'q33',
    number: 33,
    section: 3,
    type: 'boolean',
    titleAr: "س:33: [True/False] التوتر المزمن يؤدي إلى زيادة إفراز هرمون الكورتيزول مما يؤثر سلباً على المناعة.",
    titleEn: "Q33: [True/False] Chronic psychological stress elevates cortisol secretion, dysregulating systemic immune defenses.",
    required: true,
    citation: "أبحاث علم المناعة العصبي (Psychoneuroimmunology)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q34',
    number: 34,
    section: 3,
    type: 'choice',
    titleAr: "س:34: التصرف الصحيح عند التعرض للشمس لمنع حروق الجلد والتجاعيد المبكرة:",
    titleEn: "Q34: What is the gold-standard recommendation to safeguard skin from photocarcinogenesis and photoaging?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( استخدام واقي شمس واسع الطيف (Broad Spectrum)", labelEn: "A. Applying Broad Spectrum SPF sunscreen regularly", isCorrect: true },
      { value: 'B', labelAr: "ب( غسل الوجه بالصابون الجاف", labelEn: "B. Washing skin with abrasive soap", isCorrect: false },
      { value: 'C', labelAr: "ج( عدم الشرب", labelEn: "C. Fluid restriction", isCorrect: false }
    ]
  },
  {
    id: 'q35',
    number: 35,
    section: 3,
    type: 'boolean',
    titleAr: "س:35: [True/False] تناول الألياف الغذائية يساعد في تحسين صحة الجهاز الهضمي والوقاية من الإمساك.",
    titleEn: "Q35: [True/False] Adequate dietary fiber intake enhances gut microbiome health and mitigates chronic constipation.",
    required: true,
    citation: "إرشادات التغذية السريرية (WHO / Gastroenterology)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q36',
    number: 36,
    section: 3,
    type: 'boolean',
    titleAr: "س:36: [True/False] السكتة الدماغية تتطلب تدخلاً طبياً طارئاً وفورياً خلال الساعات الأولى.",
    titleEn: "Q36: [True/False] Acute stroke represents a critical medical emergency necessitating immediate intervention in the golden hours.",
    required: true,
    citation: "إرشادات F.A.S.T السريرية للسكتات الدماغية",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q37',
    number: 37,
    section: 3,
    type: 'choice',
    titleAr: "س:37: أعراض الالتواء العضلي المفاجئ نتعامل معها مبدئياً برمز R.I.C.E والذي يشير إلى:",
    titleEn: "Q37: Acute musculoskeletal sprains and strains are initially triaged using the clinical mnemonic R.I.C.E:",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( الراحة، الثلج، الضغط، والرفع (Rest, Ice, Compression, Elevation)", labelEn: "A. Rest, Ice, Compression, and Elevation", isCorrect: true },
      { value: 'B', labelAr: "ب( الجري، التدليك، الحمام الساخن", labelEn: "B. Immediate sprinting and hot thermal baths", isCorrect: false },
      { value: 'C', labelAr: "ج( الإهمال والانتظار", labelEn: "C. Passive neglect without immobilization", isCorrect: false }
    ]
  },
  {
    id: 'q38',
    number: 38,
    section: 3,
    type: 'boolean',
    titleAr: "س:38: [True/False] الأمراض الفيروسية يمكن التنبؤ بها ومنع انتشارها عبر التلقيح واللقاحات المعتمدة.",
    titleEn: "Q38: [True/False] Vaccine-preventable viral illnesses can be effectively controlled or eradicated via approved immunization schedules.",
    required: true,
    citation: "إرشادات التحصين العالمية لمنظمة الصحة العالمية (WHO EPI)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q39',
    number: 39,
    section: 3,
    type: 'choice',
    titleAr: "س:39: المعدل الطبيعي لعدد ضربات القلب أثناء الراحة للبالغين الأصحاء هو:",
    titleEn: "Q39: What is the normative resting heart rate range for healthy non-athletic adults?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( 20 - 40 نبضة/دقيقة", labelEn: "A. 20 - 40 bpm", isCorrect: false },
      { value: 'B', labelAr: "ب( 60 - 100 نبضة/دقيقة", labelEn: "B. 60 - 100 bpm", isCorrect: true },
      { value: 'C', labelAr: "ج( 140 - 180 نبضة/دقيقة", labelEn: "C. 140 - 180 bpm", isCorrect: false }
    ]
  },
  {
    id: 'q40',
    number: 40,
    section: 3,
    type: 'boolean',
    titleAr: "س:40: [True/False] قياس نسبة السكر التراكمي (HbA1c) يعكس متوسط مستويات السكر في الدم لآخر 3 أشهر.",
    titleEn: "Q40: [True/False] Hemoglobin A1c (HbA1c) quantifies average systemic blood glycemia over the preceding 2-3 months.",
    required: true,
    citation: "معايير الرعاية السريرية لمرضى السكري (ADA Standards)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q41',
    number: 41,
    section: 3,
    type: 'boolean',
    titleAr: "س:41: [True/False] الملح الزائد في الطعام يعد مقترناً بارتفاع ضغط الدم وتضخم العضلة القلبية.",
    titleEn: "Q41: [True/False] High dietary sodium intake is epidemiologically linked to systemic hypertension and left ventricular remodeling.",
    required: true,
    citation: "إرشادات منظمة الصحة العالمية لتقليل الصوديوم (WHO Sodium Guidelines)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q42',
    number: 42,
    section: 3,
    type: 'choice',
    titleAr: "س:42: ما المشروب الأكثر فاعلية في ترطيب الجسم وتعويض السوائل أثناء النشاط العادي؟",
    titleEn: "Q42: What fluid is most physiologically effective for basal daily hydration in healthy sedentary individuals?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( المشروبات الغازية", labelEn: "A. Carbonated sugar drinks", isCorrect: false },
      { value: 'B', labelAr: "ب( الماء النقي", labelEn: "B. Pure water", isCorrect: true },
      { value: 'C', labelAr: "ج( العصائر المحلاة", labelEn: "C. High-fructose sweetened juices", isCorrect: false }
    ]
  },
  {
    id: 'q43',
    number: 43,
    section: 3,
    type: 'boolean',
    titleAr: "س:43: [True/False] الفحوصات الطبية الدورية تساعد في الاكتشاف المبكر للأمراض قبل ظهور الأعراض.",
    titleEn: "Q43: [True/False] Periodic preventive screening panels enable early detection of chronic pathology before symptom manifestation.",
    required: true,
    citation: "إرشادات الطب الوقائي والفحص المبكر (USPSTF Guidelines)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q44',
    number: 44,
    section: 3,
    type: 'boolean',
    titleAr: "س:44: [True/False] مرض الصدفية (Psoriasis) مرض جلدي مناعي ذاتي وغير معدٍ إطلاقاً.",
    titleEn: "Q44: [True/False] Plaque Psoriasis is a chronic autoimmune, non-infectious inflammatory disease and cannot be spread by touch.",
    required: true,
    citation: "الأكاديمية الأمريكية للأمراض الجلدية (AAD / WHO)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q45',
    number: 45,
    section: 3,
    type: 'choice',
    titleAr: "س:45: الإجراء السليم لتفادي حدوث التسمم الغذائي في المنزل:",
    titleEn: "Q45: What is the cornerstone hygiene practice to prevent domestic foodborne enteropathogen contamination?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( فصل اللحوم النيئة عن الأطعمة الجاهزة", labelEn: "A. Segregating raw poultry/meat from ready-to-eat foods", isCorrect: true },
      { value: 'B', labelAr: "ب( ترك الطعام المكشوف في درجة حرارة الغرفة", labelEn: "B. Leaving prepared food uncovered at room temp", isCorrect: false },
      { value: 'C', labelAr: "ج( عدم غسل اليدين بعد التقطيع", labelEn: "C. Foregoing hand hygiene after raw meat handling", isCorrect: false }
    ]
  },
  {
    id: 'q46',
    number: 46,
    section: 3,
    type: 'boolean',
    titleAr: "س:46: [True/False] ممارسة التأمل والتنفس العميق يقلل من الاستجابة للضغط النفسي والقلق.",
    titleEn: "Q46: [True/False] Controlled diaphragmatic breathing and mindfulness meditation downregulate autonomic sympathetic arousal.",
    required: true,
    citation: "أبحاث علم الأعصاب وتخفيف القلق (Mind-Body Medicine)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q47',
    number: 47,
    section: 3,
    type: 'boolean',
    titleAr: "س:47: [True/False] الجروح العميقة الناتجة عن أدوات صدئة تتطلب مصل التيتانوس إذا لم تطعم مؤخراً.",
    titleEn: "Q47: [True/False] Deep puncture wounds from soiled/rusty objects require Tetanus toxoid booster if unimmunized in >5-10 years.",
    required: true,
    citation: "إرشادات CDC للوقاية من الكزاز (Tetanus Prophylaxis)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q48',
    number: 48,
    section: 3,
    type: 'choice',
    titleAr: "س:48: السلوك الأمثل للحفاظ على صحة العظام وتقويتها مع تقدم العمر:",
    titleEn: "Q48: What is the optimal combined strategy to preserve bone mineral density and forestall osteoporosis with age?",
    required: true,
    options: [
      { value: 'A', labelAr: "أ( تناول الكالسيوم مع فيتامين D وممارسة رياضة المقاومة", labelEn: "A. Adequate Calcium + Vitamin D coupled with resistance/weight-bearing exercise", isCorrect: true },
      { value: 'B', labelAr: "ب( الجلوس الطويل والراحة التامة", labelEn: "B. Sedentary prolonged bed rest", isCorrect: false },
      { value: 'C', labelAr: "ج( تقليل البروتين", labelEn: "C. Severe dietary protein restriction", isCorrect: false }
    ]
  },
  {
    id: 'q49',
    number: 49,
    section: 3,
    type: 'boolean',
    titleAr: "س:49: [True/False] الربو الشعبي هو التهاب مزمن في مجاري الهواء يمكن التحكم بأعراضه بالمبخرات والمستنشقات.",
    titleEn: "Q49: [True/False] Bronchial asthma is a chronic airway inflammatory disorder whose exacerbations are manageable via metered inhalers.",
    required: true,
    citation: "المبادرة العالمية للربو (GINA Guidelines)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: true },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: false }
    ]
  },
  {
    id: 'q50',
    number: 50,
    section: 3,
    type: 'boolean',
    titleAr: "س:50: [True/False] أجهزة التدقيق القائمة على الذكاء الاصطناعي تعتبر بديلاً قانونياً للتشخيص الطبي الرسمي.",
    titleEn: "Q50: [True/False] Artificial intelligence verification engines serve as a legal substitute for official licensed clinician diagnosis.",
    required: true,
    citation: "الإرشادات الأخلاقية والقانونية للذكاء الاصطناعي الطبي (WHO / FDA SaMD)",
    options: [
      { value: 'True', labelAr: "صح (True)", labelEn: "True", isCorrect: false },
      { value: 'False', labelAr: "خطأ (False)", labelEn: "False", isCorrect: true }
    ]
  },

  // ================= SECTION 4: ADVANCED OPTIONAL EXPERT & ENGINEER SECTION (Q51 - Q65) [15 QUESTIONS] =================
  {
    id: 'q51',
    number: 51,
    section: 4,
    type: 'scale',
    targetRole: 'clinicians',
    titleAr: "س:51: [اختياري - للخبراء] ما مدى دقة مواءمة محرك Osler's Hippocrates مع أدلة Cochrane Level 1؟",
    titleEn: "Q51: [Optional - Clinicians] How would you rate the fidelity of Osler's Hippocrates with Cochrane Level 1 Meta-Analyses?",
    required: false,
    scaleMin: 1,
    scaleMax: 5,
    scaleLabels: { minAr: "1 (ضعيف)", maxAr: "5 (ممتاز)", minEn: "1 (Poor)", maxEn: "5 (Gold Standard)" }
  },
  {
    id: 'q52',
    number: 52,
    section: 4,
    type: 'choice',
    targetRole: 'clinicians',
    titleAr: "س:52: [اختياري - للخبراء] هل تفضل ظهور النسبة المئوية للثقة أو الاكتفاء بالتدقيق النوعي للادعاءات؟",
    titleEn: "Q52: [Optional - Clinicians] Do you favor displaying numeric Confidence Percentages alongside qualitative verdict reports?",
    required: false,
    options: [
      { value: 'both', labelAr: "النسبة المئوية + التقرير النوعي", labelEn: "Confidence % + Qualitative Audit Report" },
      { value: 'qualitative_only', labelAr: "التقرير النوعي فقط", labelEn: "Qualitative Audit Report only" },
      { value: 'percentage_only', labelAr: "النسبة المئوية فقط", labelEn: "Confidence % only" }
    ]
  },
  {
    id: 'q53',
    number: 53,
    section: 4,
    type: 'textarea',
    targetRole: 'clinicians',
    titleAr: "س:53: [اختياري - للخبراء] كيف تقيم تغطية النظام لأمراض الجلد والتفرقة التشخيصية بين الإكزيما والقوباء؟",
    titleEn: "Q53: [Optional - Clinicians] What is your assessment of the system's differential diagnostic boundaries between Eczema & Tinea?",
    descriptionAr: "حقل نصي ممتد للملاحظات السريرية",
    descriptionEn: "Extended clinical peer-review commentary",
    required: false
  },
  {
    id: 'q54',
    number: 54,
    section: 4,
    type: 'choice',
    targetRole: 'clinicians',
    titleAr: "س:54: [اختياري - للخبراء] هل ترى أن تحذيرات السلامة الطبية (Disclaimers) كافية قانونياً وأخلاقياً؟",
    titleEn: "Q54: [Optional - Clinicians] Do you deem the automated medical disclaimers legally and ethically robust?",
    required: false,
    options: [
      { value: 'Yes', labelAr: "نعم (كافية تماماً)", labelEn: "Yes (Fully robust)" },
      { value: 'No', labelAr: "لا", labelEn: "No" },
      { value: 'NeedsStrengthening', labelAr: "تحتاج تدعيم إضافي", labelEn: "Needs further reinforcement" }
    ]
  },
  {
    id: 'q55',
    number: 55,
    section: 4,
    type: 'textarea',
    targetRole: 'clinicians',
    titleAr: "س:55: [اختياري - للخبراء] ما هي المراجع الطبية المعتمدة التي ترشح إضافتها لقاعدة المعرفة؟",
    titleEn: "Q55: [Optional - Clinicians] What peer-reviewed authoritative guidelines do you recommend adding to the RAG vector corpus?",
    descriptionAr: "حقل نصي ممتد",
    descriptionEn: "Recommended peer-reviewed guideline repositories",
    required: false
  },
  {
    id: 'q56',
    number: 56,
    section: 4,
    type: 'scale',
    targetRole: 'engineers',
    titleAr: "س:56: [اختياري - للمهندسين] ما رأيك في استخدام معمارية Hybrid RAG لتحسين استرجاع الأدلة الطبية؟",
    titleEn: "Q56: [Optional - Engineers] How would you evaluate the Hybrid RAG (Dense Embedding + Sparse BM25) architecture?",
    required: false,
    scaleMin: 1,
    scaleMax: 5,
    scaleLabels: { minAr: "1 (ضعيف)", maxAr: "5 (ممتاز ومبتكر)", minEn: "1 (Suboptimal)", maxEn: "5 (Exemplary)" }
  },
  {
    id: 'q57',
    number: 57,
    section: 4,
    type: 'choice',
    targetRole: 'engineers',
    titleAr: "س:57: [اختياري - للمهندسين] هل تعتقد أن التخزين المؤقت الدلالي (Semantic Cache) يضمن استجابة في أقل من 15ms؟",
    titleEn: "Q57: [Optional - Engineers] Does the vector Semantic Cache architecture reliably maintain sub-15ms lookup latencies?",
    required: false,
    options: [
      { value: 'Yes', labelAr: "نعم (<15ms محققة)", labelEn: "Yes (<15ms achieved)" },
      { value: 'NeedsImprovement', labelAr: "يحتاج تحسين إضافي", labelEn: "Needs tuning" },
      { value: 'No', labelAr: "لا", labelEn: "No" }
    ]
  },
  {
    id: 'q58',
    number: 58,
    section: 4,
    type: 'textarea',
    targetRole: 'engineers',
    titleAr: "س:58: [اختياري - للمهندسين] كيف تقيم قدرة نظام التبديل الآلي (Failover Cascade) على مواجهة انقطاع الخدمة؟",
    titleEn: "Q58: [Optional - Engineers] How robust is the deterministic multi-LLM failover cascade under simulated provider outages?",
    descriptionAr: "حقل نصي للملاحظات التقنية",
    descriptionEn: "Technical resilience and fault-tolerance feedback",
    required: false
  },
  {
    id: 'q59',
    number: 59,
    section: 4,
    type: 'scale',
    targetRole: 'engineers',
    titleAr: "س:59: [اختياري - للمهندسين] ما هو تقييمك لأمان نقل البيانات وربط الردود بجداول البيانات تلقائياً؟",
    titleEn: "Q59: [Optional - Engineers] How do you score the streaming data pipeline security and Google Sheets synchronization?",
    required: false,
    scaleMin: 1,
    scaleMax: 5,
    scaleLabels: { minAr: "1 (غير آمن)", maxAr: "5 (آمن ومحكم تماماً)", minEn: "1 (Insecure)", maxEn: "5 (Enterprise Secure)" }
  },
  {
    id: 'q60',
    number: 60,
    section: 4,
    type: 'textarea',
    targetRole: 'engineers',
    titleAr: "س:60: [اختياري - للمهندسين] اقتراحاتكم بشأن صيانة واجهات الـ API وموازنة الأحمال (Load Balancing):",
    titleEn: "Q60: [Optional - Engineers] Your recommendations for API rate-limiting, edge routing, and cloud load balancing:",
    descriptionAr: "حقل نصي ممتد",
    descriptionEn: "Infrastructure scaling recommendations",
    required: false
  },
  {
    id: 'q61',
    number: 61,
    section: 4,
    type: 'choice',
    titleAr: "س:61: هل تشجع مشاركة هذا الاستبيان مع زملائك في المجال الطبي أو الهندسي؟",
    titleEn: "Q61: Would you recommend and share this evaluation survey with your clinical or engineering peers?",
    required: true,
    options: [
      { value: 'Yes', labelAr: "نعم", labelEn: "Yes" },
      { value: 'No', labelAr: "لا", labelEn: "No" }
    ]
  },
  {
    id: 'q62',
    number: 62,
    section: 4,
    type: 'choice',
    titleAr: "س:62: هل ترغب في الانضمام إلى القائمة البريدية للتحديثات التجريبية الخاصة بالمنصة؟",
    titleEn: "Q62: Would you like to subscribe to the developer / clinician pilot newsletter for early platform updates?",
    required: true,
    options: [
      { value: 'Yes', labelAr: "نعم", labelEn: "Yes" },
      { value: 'No', labelAr: "لا", labelEn: "No" }
    ]
  },
  {
    id: 'q63',
    number: 63,
    section: 4,
    type: 'choice',
    titleAr: "س:63: ما هو الانطباع العام النهائي لك عن منصة Osler's Hippocrates؟",
    titleEn: "Q63: What is your overall final evaluation impression of Osler's Hippocrates Health AI platform?",
    required: true,
    options: [
      { value: 'excellent', labelAr: "ممتاز (Excellent)", labelEn: "Excellent" },
      { value: 'very_good', labelAr: "جيد جداً (Very Good)", labelEn: "Very Good" },
      { value: 'average', labelAr: "متوسط (Average)", labelEn: "Average" },
      { value: 'needs_work', labelAr: "يحتاج إلى تطوير كبير", labelEn: "Needs Significant Improvement" }
    ]
  },
  {
    id: 'q64',
    number: 64,
    section: 4,
    type: 'choice',
    titleAr: "س:64: هل تجد صعوبة في فهم المصطلحات التقنية أو الطبية باللغة العربية؟",
    titleEn: "Q64: Did you encounter any difficulty understanding technical AI or clinical terminology in Arabic?",
    required: true,
    options: [
      { value: 'No', labelAr: "لا (المصطلحات واضحة وسلسة)", labelEn: "No (Clear and accessible)" },
      { value: 'Sometimes', labelAr: "أحياناً", labelEn: "Sometimes" },
      { value: 'Yes', labelAr: "نعم (توجد صعوبة)", labelEn: "Yes (Challenging)" }
    ]
  },
  {
    id: 'q65',
    number: 65,
    section: 4,
    type: 'textarea',
    titleAr: "س:65: كلمة ختامية أو تعليق عام للجهة المفرزة والمشرفة على التقييم:",
    titleEn: "Q65: Final concluding remarks, reflections, or feedback for the supervisory medical-AI evaluation committee:",
    descriptionAr: "حقل نصي مفتوح",
    descriptionEn: "Open text feedback",
    required: false
  }
];
