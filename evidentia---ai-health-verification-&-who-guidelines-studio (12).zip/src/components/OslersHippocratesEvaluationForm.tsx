import React, { useState, useMemo } from 'react';
import {
  FileText,
  CheckCircle2,
  AlertTriangle,
  Send,
  Star,
  User,
  MapPin,
  Clock,
  ShieldCheck,
  Stethoscope,
  Cpu,
  Heart,
  HelpCircle,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Mail,
  Lock,
  ChevronDown,
  ChevronUp,
  Check,
  Award,
  Layers,
  FastForward,
  Info
} from 'lucide-react';
import {
  MASTER_QUESTIONS_65,
  MASTER_SECTIONS,
  MasterQuestion
} from '../data/masterEvaluationBank65.ts';

export interface Evaluation65Response {
  id: string;
  timestamp: string;
  email: string;
  name: string;
  preferredLanguage: 'ar' | 'en';
  ageGroup: string;
  location: string;
  role: 'public' | 'clinician' | 'engineer';
  answers: Record<string, any>;
  quizScore: number;
  quizTotal: number;
  quizPercentage: number;
  journeyClarity: 'Yes' | 'No';
  confidenceScoreUnderstanding: 'Yes' | 'No';
  disclaimerAcknowledged: boolean;
  shareUsabilityRating: number;
}

export interface OslersHippocratesEvaluationFormProps {
  isArabic: boolean;
  onSubmitSuccess?: (response: Evaluation65Response) => void;
  onViewExcelSheet?: () => void;
}

// Initial Sample Seed Data: Empty array to ensure complete privacy (no stranger data)
export const INITIAL_SAMPLE_65_RESPONSES: Evaluation65Response[] = [];

export default function OslersHippocratesEvaluationForm({
  isArabic,
  onSubmitSuccess
}: OslersHippocratesEvaluationFormProps) {
  // Answers state keyed by question id ('q1'..'q65')
  const [answers, setAnswers] = useState<Record<string, any>>({
    q1: '',
    q2: isArabic ? 'ar' : 'en',
    q3: '',
    q4: '18-30',
    q5: 'Cairo, Egypt',
    _role: 'public',
    q6: 'Yes',
    q7: 'Yes',
    q8: 'agree',
    q9: 5,
    q10: 'Yes',
    q11: '<1s',
    q12: 'Yes',
    q13: 'Yes',
    q14: 5,
    q15: '',
    // Core Clinical Awareness Questions (Q16 - Q19)
    q16: 'True',
    q17: 'True',
    q18: 'B',
    q19: 'True',
    // Defaults for remaining wrap-up questions
    q61: 'Yes',
    q62: 'Yes',
    q63: 'excellent',
    q64: 'No'
  });

  const [activeStep, setActiveStep] = useState<1 | 2 | 3 | 4>(1);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedData, setSubmittedData] = useState<Evaluation65Response | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showExtendedQuiz, setShowExtendedQuiz] = useState(false);

  // Filter questions by section
  const sectionQuestions = useMemo(() => {
    return {
      1: MASTER_QUESTIONS_65.filter(q => q.section === 1),
      2: MASTER_QUESTIONS_65.filter(q => q.section === 2),
      3: MASTER_QUESTIONS_65.filter(q => q.section === 3),
      4: MASTER_QUESTIONS_65.filter(q => q.section === 4)
    };
  }, []);

  const handleAnswerChange = (qId: string, value: any) => {
    setAnswers(prev => ({
      ...prev,
      [qId]: value
    }));
  };

  // Quick helper to fill correct answers for Section 3
  const handleAutoFillQuiz = () => {
    const quizUpdates: Record<string, any> = {};
    MASTER_QUESTIONS_65.filter(q => q.section === 3).forEach(q => {
      const correctOpt = q.options?.find(o => o.isCorrect);
      if (correctOpt) {
        quizUpdates[q.id] = correctOpt.value;
      }
    });
    setAnswers(prev => ({
      ...prev,
      ...quizUpdates
    }));
  };

  // Calculate live quiz score
  const quizQuestions = useMemo(() => MASTER_QUESTIONS_65.filter(q => q.section === 3), []);
  const currentQuizScore = useMemo(() => {
    let score = 0;
    quizQuestions.forEach(q => {
      const userAns = answers[q.id];
      const correctOpt = q.options?.find(o => o.isCorrect);
      if (correctOpt && userAns === correctOpt.value) {
        score++;
      }
    });
    return score;
  }, [answers, quizQuestions]);

  const quizCompletionCount = useMemo(() => {
    return quizQuestions.filter(q => answers[q.id] !== undefined && answers[q.id] !== '').length;
  }, [answers, quizQuestions]);

  // Primary Submission Handler
  const executeSubmission = (skipSection4: boolean = false) => {
    setErrorMessage(null);

    // Validation 1: Email required and valid
    const email = (answers['q1'] || '').trim();
    if (!email || !email.includes('@') || !email.includes('.')) {
      setErrorMessage(
        isArabic
          ? "يرجى كتابة بريد إلكتروني صالح في الخطوة 1 (إلزامي لتأمين الردود وتوثيقها للمالك zoz598489@gmail.com)."
          : "Please enter a valid respondent email in Step 1 (Mandatory for owner tracking at zoz598489@gmail.com)."
      );
      setActiveStep(1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    // Validation 2: Disclaimer agreement required in Step 2
    if (answers['q8'] !== 'agree') {
      setErrorMessage(
        isArabic
          ? "يجب الموافقة على الإقرار الطبي في الخطوة 2: بأن المنصة أداة تدقيق وتوعية ولا تستبدل استشارة الطبيب."
          : "Please acknowledge the Medical Disclaimer in Step 2 (educational tool only, not replacing a doctor)."
      );
      setActiveStep(2);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    // Ensure core 4 awareness questions are filled (Q16 - Q19)
    const coreMissing = ['q16', 'q17', 'q18', 'q19'].some(id => !answers[id]);
    if (coreMissing) {
      setErrorMessage(
        isArabic
          ? "يرجى الإجابة على أسئلة التوعية الصحية الأساسية الأربعة في الخطوة 3."
          : "Please answer the 4 core health awareness questions in Step 3."
      );
      setActiveStep(3);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    // Prepare full evaluation record
    const responseId = `EVAL-${Math.floor(1000 + Math.random() * 9000)}`;
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const scorePct = Math.round((currentQuizScore / quizQuestions.length) * 100);

    const submission: Evaluation65Response = {
      id: responseId,
      timestamp,
      email: email.toLowerCase(),
      name: answers['q3'] || (isArabic ? "مشارك مهتم بالصحة" : "Health Participant"),
      preferredLanguage: answers['q2'] || (isArabic ? 'ar' : 'en'),
      ageGroup: answers['q4'] || '18-30',
      location: answers['q5'] || 'Cairo, Egypt',
      role: answers['_role'] || 'public',
      answers: {
        ...answers,
        _section4Skipped: skipSection4
      },
      quizScore: currentQuizScore,
      quizTotal: quizQuestions.length,
      quizPercentage: scorePct,
      journeyClarity: answers['q6'] || 'Yes',
      confidenceScoreUnderstanding: answers['q7'] || 'Yes',
      disclaimerAcknowledged: answers['q8'] === 'agree',
      shareUsabilityRating: answers['q9'] || 5
    };

    // Save to LocalStorage
    try {
      const stored = localStorage.getItem('oslers_hippocrates_65_evaluations');
      const list: Evaluation65Response[] = stored ? JSON.parse(stored) : INITIAL_SAMPLE_65_RESPONSES;
      const updated = [submission, ...list];
      localStorage.setItem('oslers_hippocrates_65_evaluations', JSON.stringify(updated));
    } catch (e) {
      console.warn("Storage error", e);
    }

    setSubmittedData(submission);
    setIsSubmitted(true);
    if (onSubmitSuccess) onSubmitSuccess(submission);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStepTransition = (nextStep: 1 | 2 | 3 | 4) => {
    setErrorMessage(null);

    // If moving past Step 1, validate email
    if (activeStep === 1 && nextStep > 1) {
      const email = (answers['q1'] || '').trim();
      if (!email || !email.includes('@') || !email.includes('.')) {
        setErrorMessage(
          isArabic
            ? "يرجى إدخال بريد إلكتروني صالح للمتابعة (مطلوب لتوثيق الرد وحفظه بأمان للمالك)."
            : "Please enter a valid respondent email to continue."
        );
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
    }

    // If moving past Step 2, validate disclaimer
    if (activeStep === 2 && nextStep > 2) {
      if (answers['q8'] !== 'agree') {
        setErrorMessage(
          isArabic
            ? "يجب الإقرار بأن المنصة أداة تدقيق وتوعية ولا تستبدل الطبيب للمتابعة."
            : "Please acknowledge that the platform does not replace a medical doctor to proceed."
        );
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
    }

    setActiveStep(nextStep);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Section 3: Split into Core 4 vs Extended Questions
  const coreAwarenessQuestions = useMemo(() => {
    return MASTER_QUESTIONS_65.filter(q => q.section === 3 && [16, 17, 18, 19].includes(q.number));
  }, []);

  const extendedQuizQuestions = useMemo(() => {
    return MASTER_QUESTIONS_65.filter(q => q.section === 3 && q.number > 19);
  }, []);

  // Section 4: Split into Clinician vs Engineer vs General
  const clinicianQuestions = useMemo(() => {
    return MASTER_QUESTIONS_65.filter(q => q.section === 4 && q.number >= 51 && q.number <= 55);
  }, []);

  const engineerQuestions = useMemo(() => {
    return MASTER_QUESTIONS_65.filter(q => q.section === 4 && q.number >= 56 && q.number <= 60);
  }, []);

  const wrapUpQuestions = useMemo(() => {
    return MASTER_QUESTIONS_65.filter(q => q.section === 4 && q.number >= 61 && q.number <= 65);
  }, []);

  // Render question card
  const renderQuestionCard = (q: MasterQuestion, customBadge?: string, customBadgeColor?: string) => {
    const currentVal = answers[q.id];

    return (
      <div
        key={q.id}
        className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3.5 transition-all hover:border-slate-700 shadow-sm"
      >
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono font-bold text-teal-400">
                #{q.number}
              </span>
              {customBadge && (
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${customBadgeColor || 'bg-slate-800 text-slate-300 border-slate-700'}`}>
                  {customBadge}
                </span>
              )}
              {q.required && (
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950/60 text-rose-300 border border-rose-800/80">
                  {isArabic ? "إلزامي" : "Required"}
                </span>
              )}
            </div>

            <h3 className="text-sm sm:text-base font-bold text-white leading-snug">
              {isArabic ? q.titleAr.replace(/^س:\d+:\s*/, '') : q.titleEn.replace(/^Q\d+:\s*/, '')}
            </h3>

            {(q.descriptionAr || q.descriptionEn) && (
              <p className="text-xs text-slate-400 leading-relaxed">
                {isArabic ? q.descriptionAr : q.descriptionEn}
              </p>
            )}
          </div>
        </div>

        {/* Question Input Types */}
        {q.type === 'email' && (
          <div className="relative">
            <input
              type="email"
              value={currentVal || ''}
              onChange={(e) => handleAnswerChange(q.id, e.target.value)}
              placeholder="example@gmail.com"
              className="w-full bg-slate-950 border border-slate-700/80 focus:border-teal-400 text-sm text-white rounded-xl px-4 py-3 min-h-[48px] placeholder:text-slate-600 focus:outline-none font-mono"
            />
          </div>
        )}

        {q.type === 'text' && (
          <input
            type="text"
            value={currentVal || ''}
            onChange={(e) => handleAnswerChange(q.id, e.target.value)}
            placeholder={isArabic ? "اكتب إجابتك هنا..." : "Type your answer here..."}
            className="w-full bg-slate-950 border border-slate-700/80 focus:border-teal-400 text-sm text-white rounded-xl px-4 py-3 min-h-[48px] placeholder:text-slate-600 focus:outline-none"
          />
        )}

        {q.type === 'textarea' && (
          <textarea
            value={currentVal || ''}
            onChange={(e) => handleAnswerChange(q.id, e.target.value)}
            rows={3}
            placeholder={isArabic ? "اكتب ملاحظاتك بحرية (اختياري)..." : "Write your feedback (optional)..."}
            className="w-full bg-slate-950 border border-slate-700/80 focus:border-teal-400 text-sm text-white rounded-xl p-3.5 min-h-[80px] placeholder:text-slate-600 focus:outline-none resize-none"
          />
        )}

        {q.type === 'choice' && q.options && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            {q.options.map((opt) => {
              const isSelected = currentVal === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => handleAnswerChange(q.id, opt.value)}
                  className={`text-right p-3.5 rounded-xl border text-xs sm:text-sm font-medium transition cursor-pointer min-h-[48px] flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-teal-500/15 border-teal-400 text-white shadow-sm ring-1 ring-teal-400/40'
                      : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <span className="leading-snug">{isArabic ? opt.labelAr : opt.labelEn}</span>
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                    isSelected ? 'border-teal-400 bg-teal-400 text-slate-950' : 'border-slate-700 bg-slate-900'
                  }`}>
                    {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {q.type === 'boolean' && (
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={() => handleAnswerChange(q.id, 'True')}
              className={`p-3.5 rounded-xl border text-sm font-bold transition cursor-pointer min-h-[48px] flex items-center justify-center gap-2 ${
                currentVal === 'True'
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 ring-1 ring-emerald-400/40'
                  : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-850'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>{isArabic ? "صحيح (True)" : "True"}</span>
            </button>
            <button
              type="button"
              onClick={() => handleAnswerChange(q.id, 'False')}
              className={`p-3.5 rounded-xl border text-sm font-bold transition cursor-pointer min-h-[48px] flex items-center justify-center gap-2 ${
                currentVal === 'False'
                  ? 'bg-rose-500/20 border-rose-500 text-rose-300 ring-1 ring-rose-400/40'
                  : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-850'
              }`}
            >
              <span>✕</span>
              <span>{isArabic ? "خطأ (False)" : "False"}</span>
            </button>
          </div>
        )}

        {q.type === 'disclaimer' && (
          <div className="space-y-3 pt-1">
            <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-200/90 leading-relaxed">
              ⚠️ {isArabic
                ? "إقرار قانوني وطبي: أقر بأن Osler's Hippocrates أداة تدقيق معلومات وبحث تعليمي سريري استرشادي، ولا تقدم استشارات أو تشخيصات طبية للمرضى، ولا تستبدل الطبيب المعالج بأي شكل."
                : "Legal & Clinical Disclaimer: I acknowledge that Osler's Hippocrates is an educational research and verification tool and does not provide medical diagnosis or replace a licensed physician."}
            </div>
            <button
              type="button"
              onClick={() => handleAnswerChange(q.id, currentVal === 'agree' ? '' : 'agree')}
              className={`w-full p-3.5 rounded-xl border text-xs sm:text-sm font-bold transition cursor-pointer min-h-[48px] flex items-center justify-between gap-3 ${
                currentVal === 'agree'
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 ring-1 ring-emerald-400/40'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
              }`}
            >
              <span>{isArabic ? "أوافق وأقر بهذا التحذير الطبي (مطلوب)" : "I acknowledge and agree to this medical disclaimer"}</span>
              <div className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 ${
                currentVal === 'agree' ? 'border-emerald-400 bg-emerald-400 text-slate-950' : 'border-slate-700 bg-slate-900'
              }`}>
                {currentVal === 'agree' && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
            </button>
          </div>
        )}

        {q.type === 'scale' && (
          <div className="space-y-2 pt-1">
            <div className="grid grid-cols-5 gap-2">
              {[1, 2, 3, 4, 5].map((num) => {
                const isSelected = currentVal === num;
                return (
                  <button
                    key={num}
                    type="button"
                    onClick={() => handleAnswerChange(q.id, num)}
                    className={`py-3 rounded-xl border font-mono font-bold text-xs sm:text-sm min-h-[48px] flex flex-col items-center justify-center gap-1 transition cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 ring-1 ring-amber-400/50'
                        : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <span>{num}</span>
                    <Star className={`w-3.5 h-3.5 ${isSelected ? 'fill-amber-400 text-amber-400' : 'text-slate-600'}`} />
                  </button>
                );
              })}
            </div>
            {q.scaleLabels && (
              <div className="flex justify-between text-[11px] text-slate-400 px-1 font-mono">
                <span>{isArabic ? q.scaleLabels.minAr : q.scaleLabels.minEn}</span>
                <span>{isArabic ? q.scaleLabels.maxAr : q.scaleLabels.maxEn}</span>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-5 max-w-4xl mx-auto pb-24 md:pb-12">
      {/* Top Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-teal-500/10 text-teal-400 border border-teal-500/30 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isArabic ? "استبيان التقييم والتوعية الصحية" : "Evaluation & Awareness Form"}</span>
            </span>
            <span className="px-2.5 py-1 rounded-full text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 flex items-center gap-1">
              <Lock className="w-3 h-3" />
              <span>zoz598489@gmail.com</span>
            </span>
            <span className="text-xs text-slate-400 font-medium">
              ⏱️ {isArabic ? "يستغرق 2 - 3 دقائق فقط" : "Takes 2-3 mins"}
            </span>
          </div>

          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {isArabic ? "استبيان تقييم منصة Osler's Hippocrates" : "Osler's Hippocrates Assessment Form"}
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
            {isArabic
              ? "مرحباً بك! نقدّر رأيك في تجربة المنصة ومدى سهولة فحص الادعاءات الطبية. يمكنك الإجابة على ما يهمك والتنقل بسلاسة عبر المراحل أو تخطي مرحلة الخبراء."
              : "Welcome! We value your feedback on platform usability and medical awareness. Seamlessly navigate steps or skip expert sections anytime."}
          </p>
        </div>

        {/* 4-Step Stepper Header (Mobile Responsive) */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { id: 1, titleAr: "1. بياناتك", titleEn: "1. Demographics", icon: User },
            { id: 2, titleAr: "2. تجربة المنصة", titleEn: "2. Platform UX", icon: Heart },
            { id: 3, titleAr: "3. التوعية الصحية", titleEn: "3. Awareness", icon: Stethoscope },
            { id: 4, titleAr: "4. الخبراء (اختياري)", titleEn: "4. Expert (Optional)", icon: Cpu }
          ].map((st) => {
            const Icon = st.icon;
            const isActive = activeStep === st.id;
            const isCompleted = activeStep > st.id;

            return (
              <button
                key={st.id}
                type="button"
                onClick={() => handleStepTransition(st.id as any)}
                className={`p-3 rounded-2xl border text-right transition cursor-pointer min-h-[54px] flex items-center justify-between gap-2 ${
                  isActive
                    ? 'bg-teal-500/15 border-teal-400 text-white ring-1 ring-teal-400/40 shadow-sm'
                    : isCompleted
                      ? 'bg-slate-950/90 border-emerald-500/40 text-emerald-300'
                      : 'bg-slate-950/50 border-slate-800/80 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  <div className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 ${
                    isActive ? 'bg-teal-500 text-slate-950 font-bold' : isCompleted ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isCompleted ? <Check className="w-4 h-4 stroke-[3]" /> : <Icon className="w-3.5 h-3.5" />}
                  </div>
                  <span className="text-xs font-bold truncate">
                    {isArabic ? st.titleAr : st.titleEn}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Error Message Toast */}
      {errorMessage && (
        <div className="bg-rose-950/80 border border-rose-500 p-4 rounded-2xl text-xs text-rose-200 flex items-center gap-3 animate-in fade-in shadow-lg">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
          <span className="leading-relaxed font-medium">{errorMessage}</span>
        </div>
      )}

      {/* Submission Success View */}
      {isSubmitted && submittedData ? (
        <div className="bg-slate-900 border border-teal-500/50 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl animate-in fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">
                  {isArabic ? "تم استلام تقييمك وحفظه بنجاح!" : "Evaluation Successfully Submitted!"}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isArabic
                    ? `رقم التسجيل: ${submittedData.id} • تم التوجيه بأمان إلى حساب المالك zoz598489@gmail.com.`
                    : `Record: ${submittedData.id} • Securely delivered to owner vault (zoz598489@gmail.com).`}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setIsSubmitted(false);
                setSubmittedData(null);
                setActiveStep(1);
              }}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 self-start cursor-pointer transition min-h-[44px]"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isArabic ? "تعبئة تقييم آخر" : "Submit Another Response"}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl space-y-1">
              <span className="text-xs text-slate-400">{isArabic ? "التوعية الصحية (الأمراض الجلدية):" : "Clinical Awareness:"}</span>
              <div className="text-2xl font-bold font-mono text-teal-400">
                {submittedData.quizScore} / {submittedData.quizTotal}
              </div>
              <span className="text-xs text-emerald-400 font-semibold block">
                {submittedData.quizPercentage}% {isArabic ? "مطابقة علمية ممتازة" : "Clinical Concordance"}
              </span>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl space-y-1">
              <span className="text-xs text-slate-400">{isArabic ? "البريد الإلكتروني الموثق:" : "Verified Email:"}</span>
              <div className="text-sm font-bold font-mono text-white truncate">
                {submittedData.email}
              </div>
              <span className="text-[11px] text-teal-300 font-mono block">
                🔒 Protected & Owner-Restricted
              </span>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl space-y-1">
              <span className="text-xs text-slate-400">{isArabic ? "تقييم سهولة المشاركة:" : "Share Usability:"}</span>
              <div className="text-2xl font-bold font-mono text-amber-400">
                {submittedData.shareUsabilityRating} / 5 ★
              </div>
              <span className="text-xs text-slate-400 block">
                {isArabic ? "تم الإقرار بالمسؤولية الطبية" : "Disclaimer Acknowledged"}
              </span>
            </div>
          </div>

          {/* Privacy confirmation */}
          <div className="w-full flex items-center gap-2.5 p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-xs text-emerald-300">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="leading-relaxed">
              {isArabic
                ? "🔒 خصوصية تامة: تم تشفير ردك وحفظه مباشرة داخل Google Sheets الخاص بـ zoz598489@gmail.com. لا يمكن لأي طرف عام تنزيل أو استعراض ردودك."
                : "🔒 High Privacy: Your responses are confidentially stored in the owner's Google Sheet (zoz598489@gmail.com)."}
            </span>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <a
              href={`mailto:zoz598489@gmail.com?subject=${encodeURIComponent(`[Osler's Hippocrates] New Evaluation from ${submittedData.email} (${submittedData.id})`)}&body=${encodeURIComponent(
                `وصل تقييم جديد في استبيان Osler's Hippocrates:\n\n` +
                `• كود الاستجابة: ${submittedData.id}\n` +
                `• البريد الإلكتروني للمشارك: ${submittedData.email}\n` +
                `• الاسم: ${submittedData.name}\n` +
                `• الموقع: ${submittedData.location}\n` +
                `• الفئة: ${submittedData.role}\n` +
                `• نتيجة اختبار التوعية: ${submittedData.quizScore}/35 (${submittedData.quizPercentage}%)\n` +
                `• وضوح الرحلة: ${submittedData.journeyClarity}\n` +
                `• تقييم سهولة المشاركة (واتساب): ${submittedData.shareUsabilityRating}/5\n` +
                `• الوقت والتاريخ: ${submittedData.timestamp}\n\n` +
                `تم حفظ الردود وإرسالها للمالك على zoz598489@gmail.com وملف الإكسيل الخاص به.`
              )}`}
              className="px-5 py-3 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg transition cursor-pointer min-h-[48px]"
            >
              <Send className="w-4 h-4" />
              <span>{isArabic ? "📧 إرسال إشعار فوري لـ zoz598489@gmail.com" : "Send Instant Email Alert to zoz598489@gmail.com"}</span>
            </a>
          </div>
        </div>
      ) : (
        /* The 4-Step Form View */
        <div className="space-y-6">
          {/* ================= STEP 1: DEMOGRAPHICS & ROLE ================= */}
          {activeStep === 1 && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 space-y-6 shadow-xl">
              <div className="border-b border-slate-800 pb-4">
                <span className="text-xs font-mono font-bold text-teal-400 block mb-1">
                  {isArabic ? "المرحلة الأولى: بياناتك وصفتك" : "Step 1: Your Role & Demographics"}
                </span>
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {isArabic ? "من أنت وكيف تفضل المشاركة؟" : "Select Your Role & Preferences"}
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  {isArabic
                    ? "اختر صفتك لنخصص لك الأسئلة المناسبة ونسهّل تجربتك دون أي إجبار على أسئلة تقنية معقدة."
                    : "Select your role to tailor relevant questions without overwhelming technical jargon."}
                </p>
              </div>

              {/* Role Selection Cards */}
              <div className="space-y-2.5">
                <label className="text-xs font-bold text-slate-300 block">
                  {isArabic ? "اختر صفتك في هذا الاستبيان:" : "Select your role:"}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    {
                      id: 'public',
                      titleAr: "👤 مستخدم عام / مهتم بالصحة",
                      titleEn: "General Public",
                      descAr: "استبيان سريع ومبسط (دقيقتان)",
                      descEn: "Fast & simple (2 mins)"
                    },
                    {
                      id: 'clinician',
                      titleAr: "🩺 طبيب / باحث سريري",
                      titleEn: "Clinician / Researcher",
                      descAr: "يتضمن مواءمة WHO وكوكرين",
                      descEn: "Includes WHO & Cochrane"
                    },
                    {
                      id: 'engineer',
                      titleAr: "💻 مهندس / مطور برمجيات",
                      titleEn: "Systems / AI Engineer",
                      descAr: "يتضمن RAG والتخزين المؤقت",
                      descEn: "Includes RAG & Cache"
                    }
                  ].map((roleOpt) => {
                    const isSelected = answers['_role'] === roleOpt.id;
                    return (
                      <button
                        key={roleOpt.id}
                        type="button"
                        onClick={() => handleAnswerChange('_role', roleOpt.id)}
                        className={`text-right p-4 rounded-2xl border transition cursor-pointer min-h-[72px] flex flex-col justify-between ${
                          isSelected
                            ? 'bg-teal-500/15 border-teal-400 text-white ring-1 ring-teal-400/40 shadow-sm'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-850'
                        }`}
                      >
                        <div className="text-xs sm:text-sm font-bold text-white">{isArabic ? roleOpt.titleAr : roleOpt.titleEn}</div>
                        <div className="text-[11px] text-teal-400 mt-1">{isArabic ? roleOpt.descAr : roleOpt.descEn}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Questions 1 - 5 */}
              <div className="space-y-4 pt-2">
                {sectionQuestions[1].map((q) => renderQuestionCard(q, isArabic ? "بيانات" : "Demographics"))}
              </div>

              {/* Step 1 Actions */}
              <div className="pt-4 border-t border-slate-800 flex justify-end">
                <button
                  type="button"
                  onClick={() => handleStepTransition(2)}
                  className="w-full sm:w-auto px-6 py-3 bg-teal-600 hover:bg-teal-500 text-slate-950 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-2 min-h-[48px] shadow-lg shadow-teal-500/20"
                >
                  <span>{isArabic ? "التالي: تجربة المنصة (Step 2) →" : "Next: Platform Experience →"}</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= STEP 2: UX & PLATFORM JOURNEY ================= */}
          {activeStep === 2 && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 space-y-6 shadow-xl">
              <div className="border-b border-slate-800 pb-4">
                <span className="text-xs font-mono font-bold text-teal-400 block mb-1">
                  {isArabic ? "المرحلة الثانية: تجربة المنصة ورحلة الفحص" : "Step 2: Platform Experience & Journey"}
                </span>
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {isArabic ? "كيف كانت تجربتك في فحص الادعاءات؟" : "How was your experience checking claims?"}
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  {isArabic
                    ? "تقييم وضوح تدفق التحقق، مؤشر الثقة، وسهولة المشاركة عبر واتساب، والإقرار بعدم استبدال الطبيب."
                    : "Evaluate the claim verification flow, confidence scoring, WhatsApp share, and medical disclaimer."}
                </p>
              </div>

              {/* Questions 6 - 15 */}
              <div className="space-y-4">
                {sectionQuestions[2].map((q) => renderQuestionCard(q, isArabic ? "تجربة المستخدم" : "UX Audit"))}
              </div>

              {/* Step 2 Actions */}
              <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => handleStepTransition(1)}
                  className="w-full sm:w-auto px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer min-h-[48px]"
                >
                  {isArabic ? "← الرجوع للبيانات" : "← Back to Demographics"}
                </button>

                <button
                  type="button"
                  onClick={() => handleStepTransition(3)}
                  className="w-full sm:w-auto px-6 py-3 bg-teal-600 hover:bg-teal-500 text-slate-950 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-2 min-h-[48px] shadow-lg shadow-teal-500/20"
                >
                  <span>{isArabic ? "التالي: التوعية الصحية (Step 3) →" : "Next: Health Awareness →"}</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= STEP 3: HEALTH & SKIN AWARENESS QUIZ ================= */}
          {activeStep === 3 && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 space-y-6 shadow-xl">
              <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-mono font-bold text-teal-400 block mb-1">
                    {isArabic ? "المرحلة الثالثة: التوعية الصحية والجلدية" : "Step 3: Health & Skin Awareness"}
                  </span>
                  <h2 className="text-base sm:text-lg font-bold text-white">
                    {isArabic ? "أسئلة التوعية بالأمراض الجلدية والصحة العامة" : "Dermatology & Clinical Awareness"}
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    {isArabic
                      ? "الأسئلة الأساسية الأربعة مخصصة للجميع. يمكنك أيضاً حل باقي الأسئلة أو الانتقال مباشرة للخطوة التالية دون أي إجبار."
                      : "The core 4 questions are for everyone. Extended questions are optional and non-blocking."}
                  </p>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <button
                    type="button"
                    onClick={handleAutoFillQuiz}
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 min-h-[40px] border border-teal-500/30"
                  >
                    <Check className="w-3.5 h-3.5 text-teal-400" />
                    <span>{isArabic ? "تعبئة سريعة للإجابات النموذجية" : "Quick Fill Quiz (35/35)"}</span>
                  </button>
                </div>
              </div>

              {/* The Core 4 Awareness Questions Required in the Brief */}
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-500/40 p-3 rounded-2xl">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>{isArabic ? "الأسئلة الأساسية الأربعة للتوعية الصحية (مطلوبة للجميع):" : "Core 4 Health Awareness Questions:"}</span>
                  </div>
                </div>

                {coreAwarenessQuestions.map((q) => renderQuestionCard(q, isArabic ? "توعية أساسية" : "Core Awareness", "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"))}
              </div>

              {/* Extended Quiz Questions Toggle (Optional) */}
              <div className="pt-2 border-t border-slate-800/80 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  <div className="space-y-0.5">
                    <div className="text-xs font-bold text-white flex items-center gap-2">
                      <Award className="w-4 h-4 text-teal-400" />
                      <span>{isArabic ? "بنك الأسئلة السريرية الموسع (31 سؤالاً إضافياً)" : "Extended Clinical Quiz (31 Questions)"}</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {isArabic
                        ? "اختياري: يختبر معرفتك السريرية العامة. درجاتك تظهر في تقرير التقييم."
                        : "Optional: Tests broader clinical literacy. Non-blocking."}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowExtendedQuiz(!showExtendedQuiz)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 self-start sm:self-auto min-h-[44px]"
                  >
                    <span>{showExtendedQuiz ? (isArabic ? "إخفاء الأسئلة الإضافية ▲" : "Hide Extended ▼") : (isArabic ? "عرض وإجابة الأسئلة الإضافية ▼" : "Show Extended ▲")}</span>
                  </button>
                </div>

                {showExtendedQuiz && (
                  <div className="space-y-4 animate-in fade-in">
                    {extendedQuizQuestions.map((q) => renderQuestionCard(q, isArabic ? "اختبار موسع" : "Extended Quiz", "bg-teal-500/10 text-teal-300 border-teal-500/30"))}
                  </div>
                )}
              </div>

              {/* Step 3 Actions: Seamless Next & Instant Skip to Submit */}
              <div className="pt-5 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => handleStepTransition(2)}
                  className="w-full sm:w-auto px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer min-h-[48px]"
                >
                  {isArabic ? "← الرجوع لتجربة المنصة" : "← Back to UX Journey"}
                </button>

                <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full sm:w-auto">
                  {/* Skip Section 4 & Submit Button */}
                  <button
                    type="button"
                    onClick={() => executeSubmission(true)}
                    className="w-full sm:w-auto px-5 py-3 bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 min-h-[48px] shadow-md shadow-emerald-500/20"
                    title={isArabic ? "إنهاء وإرسال التقييم الآن دون الحاجة لقسم الخبراء" : "Finish and submit now without Section 4"}
                  >
                    <FastForward className="w-4 h-4 text-emerald-200" />
                    <span>{isArabic ? "⏩ تخطي مرحلة الخبراء وإرسال التقييم الآن" : "⏩ Skip Expert Section & Submit Now"}</span>
                  </button>

                  {/* Advance to Section 4 */}
                  <button
                    type="button"
                    onClick={() => handleStepTransition(4)}
                    className="w-full sm:w-auto px-5 py-3 bg-teal-600 hover:bg-teal-500 text-slate-950 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 min-h-[48px] shadow-lg shadow-teal-500/20"
                  >
                    <span>{isArabic ? "التالي: قسم الخبراء والمهندسين (اختياري) →" : "Next: Expert Feedback (Optional) →"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ================= STEP 4: EXPERT & ENGINEER SECTION (100% SKIPPABLE) ================= */}
          {activeStep === 4 && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 space-y-6 shadow-xl">
              <div className="border-b border-slate-800 pb-4 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-teal-400">
                    {isArabic ? "المرحلة الرابعة: الخبراء والمهندسون" : "Step 4: Expert & Engineer Feedback"}
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    {isArabic ? "اختياري بالكامل 100%" : "100% Optional"}
                  </span>
                </div>

                <h2 className="text-base sm:text-lg font-bold text-white">
                  {isArabic ? "ملاحظات الأطباء السريريين ومهندسي النظم" : "Clinical & Systems Engineering Audit"}
                </h2>

                <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-between gap-3 text-xs text-amber-200/90 leading-relaxed">
                  <div className="flex items-center gap-2">
                    <Info className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>
                      {isArabic
                        ? "هذا القسم اختياري مخصص للمختصين. إذا لم تكن طبيباً أو مهندساً، يمكنك الضغط فوراً على زر (تخطي وإرسال التقييم)."
                        : "This section is entirely optional for clinicians and engineers. You can skip directly to submit."}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => executeSubmission(true)}
                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs whitespace-nowrap shrink-0 transition cursor-pointer shadow-sm"
                  >
                    {isArabic ? "⏩ تخطي وإرسال الآن" : "Skip & Submit"}
                  </button>
                </div>
              </div>

              {/* Sub-Section A: Clinician Questions (WHO & Cochrane Level 1) */}
              <div className="space-y-3.5">
                <div className="flex items-center gap-2 text-xs font-bold text-cyan-300 bg-cyan-950/40 border border-cyan-800/40 p-3 rounded-2xl">
                  <Stethoscope className="w-4 h-4 text-cyan-400" />
                  <span>{isArabic ? "🩺 ملاحظات الأطباء والمختصين السريريين (إرشادات WHO وأدلة Cochrane Level 1):" : "Clinician Audit (WHO Guidelines & Cochrane):"}</span>
                </div>
                {clinicianQuestions.map((q) => renderQuestionCard(q, isArabic ? "للأطباء (اختياري)" : "Clinicians (Optional)", "bg-cyan-500/10 text-cyan-300 border-cyan-500/30"))}
              </div>

              {/* Sub-Section B: Engineer Questions (Hybrid RAG, Semantic Cache, Failover) */}
              <div className="space-y-3.5 pt-3">
                <div className="flex items-center gap-2 text-xs font-bold text-purple-300 bg-purple-950/40 border border-purple-800/40 p-3 rounded-2xl">
                  <Cpu className="w-4 h-4 text-purple-400" />
                  <span>{isArabic ? "💻 ملاحظات مهندسي النظم والذكاء الاصطناعي (Hybrid RAG & Semantic Cache <15ms):" : "Engineers Audit (Hybrid RAG & Semantic Cache <15ms):"}</span>
                </div>
                {engineerQuestions.map((q) => renderQuestionCard(q, isArabic ? "للمهندسين (اختياري)" : "Engineers (Optional)", "bg-purple-500/10 text-purple-300 border-purple-500/30"))}
              </div>

              {/* Sub-Section C: Wrap-up & Final Thoughts */}
              <div className="space-y-3.5 pt-3">
                <div className="flex items-center gap-2 text-xs font-bold text-teal-300 bg-teal-950/40 border border-teal-800/40 p-3 rounded-2xl">
                  <Award className="w-4 h-4 text-teal-400" />
                  <span>{isArabic ? "🌟 الانطباع العام والتوصيات الختامية:" : "Final Impressions & Wrap-Up:"}</span>
                </div>
                {wrapUpQuestions.map((q) => renderQuestionCard(q, isArabic ? "رأي عام" : "General"))}
              </div>

              {/* Step 4 Actions: Final Submit or Skip */}
              <div className="pt-5 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => handleStepTransition(3)}
                  className="w-full sm:w-auto px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer min-h-[48px]"
                >
                  {isArabic ? "← الرجوع للتوعية الصحية" : "← Back to Health Awareness"}
                </button>

                <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => executeSubmission(true)}
                    className="w-full sm:w-auto px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer min-h-[48px] border border-slate-700"
                  >
                    <span>{isArabic ? "⏩ تخطي أسئلة الخبراء وإرسال" : "Skip Section 4 & Submit"}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => executeSubmission(false)}
                    className="w-full sm:w-auto px-7 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-bold rounded-xl transition shadow-lg shadow-emerald-500/25 cursor-pointer flex items-center justify-center gap-2 min-h-[48px]"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isArabic ? "✅ حفظ وإرسال التقييم الشامل" : "Submit Complete Evaluation"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
