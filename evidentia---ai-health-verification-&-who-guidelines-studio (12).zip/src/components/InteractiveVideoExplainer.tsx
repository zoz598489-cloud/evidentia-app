import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  ChevronRight,
  ChevronLeft,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Database,
  Building2,
  UserCheck,
  Stethoscope,
  Sparkles,
  ArrowRight,
  X,
  FastForward,
  BookOpen,
  FileText,
  Activity,
  Layers,
  Video
} from 'lucide-react';

export interface InteractiveVideoExplainerProps {
  isArabic: boolean;
  onNavigateToTab?: (tabId: string) => void;
  onClose?: () => void;
}

interface Scene {
  id: number;
  titleEn: string;
  titleAr: string;
  subtitleEn: string;
  subtitleAr: string;
  durationSec: number;
  narrationEn: string;
  narrationAr: string;
  badgeEn: string;
  badgeAr: string;
  targetTab: string;
  visualType: 'problem' | 'hallucination' | 'evidentia_solution' | 'normal_people' | 'experts_rag' | 'institutions_db';
}

const SCENES: Scene[] = [
  {
    id: 1,
    titleEn: "The Epidemic: Dangerous Health Misinformation",
    titleAr: "المشكلة الكبرى: انتشار الشائعات والخرافات الطبية القاتلة",
    subtitleEn: "Social media claims spread 6x faster than medical consensus, causing preventable clinical harm.",
    subtitleAr: "أكثر من 67% من المنشورات الصحية على السوشيال ميديا تحتوي على معلومات مضللة قد تؤدي لكوارث صحية.",
    durationSec: 14,
    narrationEn: "Every day, millions of people encounter dangerous health advice on social media—from unproven folk remedies to hazardous drug combinations. Without verified medical sources, patients risk irreversible clinical harm.",
    narrationAr: "يومياً، يتعرض ملايين الأشخاص لنصائح طبية خطيرة وشائعات مضللة على وسائل التواصل الاجتماعي—بدءاً من خلطات غير مثبتة إلى تفاعلات دوائية مميتة. الاعتماد على معلومات غير موثقة يهدد حياة المرضى بشكل حقيقي.",
    badgeEn: "Scene 1: The Challenge",
    badgeAr: "المشهد 1: التحدي الطبي",
    targetTab: "normal_people",
    visualType: "problem"
  },
  {
    id: 2,
    titleEn: "Why Standard AI Models Fail in Healthcare",
    titleAr: "لماذا تفشل نماذج الذكاء الاصطناعي التقليدية في الطب؟",
    subtitleEn: "Single LLMs hallucinate non-existent PubMed references, fake PMIDs, and dangerous dosages with absolute confidence.",
    subtitleAr: "النماذج الفردية تهلوس باختلاق أرقام أبحاث وهمية وتوصيات دوائية خاطئة مع ثقة مفرطة ومضللة.",
    durationSec: 15,
    narrationEn: "Standard AI chatbots are trained to predict the next word, not clinical truth. They frequently hallucinate fake scientific papers and invent citations. In healthcare, a confident hallucination can be fatal.",
    narrationAr: "نماذج الذكاء الاصطناعي العامة صممت للتنبؤ بالنصوص وليس للتحقق السريري. لذلك، فهي تخترق مراجع وهمية وتجيب بثقة مطلقة حتى حين تكون مخطئة تماماً، مما يجعلها خطراً جسيماً في القرارات الطبية.",
    badgeEn: "Scene 2: The Failure of Single LLMs",
    badgeAr: "المشهد 2: خطر الهلوسة",
    targetTab: "playground",
    visualType: "hallucination"
  },
  {
    id: 3,
    titleEn: "The Evidentia AI Paradigm: Multi-Model Scientific Court",
    titleAr: "الحل الثوري: منصة Evidentia ومحكمة الأدلة السريرية",
    subtitleEn: "Your Sovereign Neural Core orchestrates an ensemble of 10 AI models grounded directly in WHO and Cochrane guidelines.",
    subtitleAr: "نظامك الطبي السيادي الخاص يدير أوركسترا من 10 نماذج ذكاء اصطناعي مسندة بأدلة منظمة الصحة العالمية وكوكرين.",
    durationSec: 16,
    narrationEn: "Evidentia AI transforms health verification through a Multi-Model Scientific Evidence Court. Ten specialized AI engines deliberate across official WHO and Cochrane registries, with the crucial rule of Intelligent Abstention: refusing to guess when evidence is lacking.",
    narrationAr: "تقدم منصة إيفيدينشيا حلاً ثورياً: محكمة أدلة سريرية تضم 10 نماذج ذكاء اصطناعي متخصصة ونظامك الطبي السيادي الخاص. يتم فحص كل ادعاء أمام إرشادات منظمة الصحة العالمية الرسمية، مع تطبيق مبدأ الامتناع الذكي عند غياب الدليل القاطع.",
    badgeEn: "Scene 3: The Architecture",
    badgeAr: "المشهد 3: المعمارية الثورية",
    targetTab: "playground",
    visualType: "evidentia_solution"
  },
  {
    id: 4,
    titleEn: "Experience 1: Normal People (Simple Myth Checker)",
    titleAr: "المستوى الأول: الأفراد والجمهور العام (فاحص الخرافات المبسط)",
    subtitleEn: "Zero jargon, plain-language answers, and clear green/red verified safety badges with actionable steps.",
    subtitleAr: "إجابة واضحة خالية من التعقيدات الطبية، مع شارة خضراء أو حمراء صريحة وخطوات عملية لما يجب فعله.",
    durationSec: 15,
    narrationEn: "For everyday citizens and families, Evidentia provides a friendly, zero-jargon interface. Simply paste any post or rumor, and get an immediate verified verdict: accurate, misleading, or hazardous, backed by WHO advice.",
    narrationAr: "للجمهور العام والأفراد، توفر المنصة واجهة مبسطة وسهلة تماماً. ما عليك سوى كتابة الشائعة أو النصيحة المتداولة، لتحصل فوراً على حكم واضح بلغة بسيطة: هل هي صحيحة ومثبتة، أم خرافة مضللة، مع نصائح منظمة الصحة العالمية المباشرة.",
    badgeEn: "Scene 4: Normal People Mode",
    badgeAr: "المشهد 4: نمط الأفراد والجمهور",
    targetTab: "normal_people",
    visualType: "normal_people"
  },
  {
    id: 5,
    titleEn: "Experience 2: Clinicians & Medical Experts (RAG & EHR)",
    titleAr: "المستوى الثاني: الأطباء والخبراء (فحص المتجهات وسجلات المرضى)",
    subtitleEn: "Ingest PDF guidelines directly into the RAG vector store, evaluate HL7 FHIR EHR patient contraindications, and monitor SPC drift.",
    subtitleAr: "رفع دلائل PDF الطبية مباشرة لمستودع RAG، فحص موانع المريض الإلكتروني، ورصد الانحراف الإحصائي للذكاء الاصطناعي.",
    durationSec: 16,
    narrationEn: "For healthcare professionals, Evidentia offers clinical-grade precision. Upload guideline PDFs directly to update the RAG vector store, cross-check claims against HL7 FHIR patient records for fatal drug interactions, and track model drift.",
    narrationAr: "للأطباء والخبراء، توفر المنصة دقة سريرية فائقة. يمكنك رفع ملفات الدلائل الطبية بصيغة PDF مباشرة لتحديث مستودع المتجهات RAG، والتحقق من موانع الاستعمال الخطرة وسجلات المرضى الإلكترونية، ومراقبة دقة الذكاء الاصطناعي عبر مخططات ضبط الجودة.",
    badgeEn: "Scene 5: Medical Experts Mode",
    badgeAr: "المشهد 5: نمط الأطباء والخبراء",
    targetTab: "rag",
    visualType: "experts_rag"
  },
  {
    id: 6,
    titleEn: "Experience 3: Institutions & Regulators (Enterprise Reliability)",
    titleAr: "المستوى الثالث: المستشفيات والجهات الرقابية (الموثوقية والشفافية)",
    subtitleEn: "Full SQLite ACID audit trail, automated 10-model failover cascade, 46 automated tests, and REST API integration.",
    subtitleAr: "سجل تدقيق كامل في قاعدة بيانات SQLite، تبديل آلي للأعطال عبر 10 نماذج، و 46 اختباراً آلياً لضمان الجاهزية القصوى.",
    durationSec: 15,
    narrationEn: "For hospital networks, health ministries, and regulatory bodies, Evidentia ensures zero-downtime compliance with transparent SQLite audit logs, automated failover cascades, and sub-millisecond semantic caching.",
    narrationAr: "للمستشفيات والوزارات والهيئات الرقابية، تضمن إيفيدينشيا الامتثال والشفافية التامة عبر سجلات تدقيق SQLite غير قابلة للتلاعب، وتبديل تلقائي للأعطال يضمن استمرار الخدمة، وواجهات برمجة REST API جاهزة للربط الفوري.",
    badgeEn: "Scene 6: Institutions Mode",
    badgeAr: "المشهد 6: نمط المؤسسات والرقابة",
    targetTab: "database",
    visualType: "institutions_db"
  }
];

export default function InteractiveVideoExplainer({ isArabic, onNavigateToTab, onClose }: InteractiveVideoExplainerProps) {
  const [currentSceneIdx, setCurrentSceneIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [elapsedInScene, setElapsedInScene] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isVoiceActive, setIsVoiceActive] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<any>(null);

  const activeScene = SCENES[currentSceneIdx];

  // Speech synthesis narration
  const speakCurrentScene = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    if (isMuted) return;

    const textToSpeak = isArabic ? activeScene.narrationAr : activeScene.narrationEn;
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = isArabic ? 'ar-SA' : 'en-US';
    utterance.rate = 1.0 * playbackSpeed;

    utterance.onstart = () => setIsVoiceActive(true);
    utterance.onend = () => setIsVoiceActive(false);
    utterance.onerror = () => setIsVoiceActive(false);

    window.speechSynthesis.speak(utterance);
  };

  // Play narration whenever scene changes or unmuted
  useEffect(() => {
    if (isPlaying && !isMuted) {
      speakCurrentScene();
    } else {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    }
  }, [currentSceneIdx, isPlaying, isMuted, isArabic, playbackSpeed]);

  // Clean up speech on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Timer loop for video playback
  useEffect(() => {
    if (!isPlaying) {
      clearInterval(timerRef.current);
      return;
    }

    const intervalMs = 100 / playbackSpeed;
    timerRef.current = setInterval(() => {
      setElapsedInScene((prev) => {
        const next = prev + 0.1;
        if (next >= activeScene.durationSec) {
          // Advance to next scene or loop
          if (currentSceneIdx < SCENES.length - 1) {
            setCurrentSceneIdx((idx) => idx + 1);
            return 0;
          } else {
            setIsPlaying(false);
            return activeScene.durationSec;
          }
        }
        return next;
      });
    }, intervalMs);

    return () => clearInterval(timerRef.current);
  }, [isPlaying, currentSceneIdx, activeScene.durationSec, playbackSpeed]);

  const handleNextScene = () => {
    if (currentSceneIdx < SCENES.length - 1) {
      setCurrentSceneIdx((idx) => idx + 1);
      setElapsedInScene(0);
    }
  };

  const handlePrevScene = () => {
    if (currentSceneIdx > 0) {
      setCurrentSceneIdx((idx) => idx - 1);
      setElapsedInScene(0);
    } else {
      setElapsedInScene(0);
    }
  };

  const handleRestart = () => {
    setCurrentSceneIdx(0);
    setElapsedInScene(0);
    setIsPlaying(true);
  };

  const handleToggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const sceneProgressPercent = Math.min(100, (elapsedInScene / activeScene.durationSec) * 100);

  return (
    <div
      ref={containerRef}
      className={`bg-slate-950 border border-teal-500/30 rounded-2xl overflow-hidden shadow-2xl flex flex-col ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'relative w-full'
      } ${isArabic ? 'rtl' : 'ltr'}`}
    >
      {/* Top Header Bar */}
      <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-3 flex items-center justify-between backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-300">
            <Video className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                {isArabic ? "فيديو تعريفي وتدريبي تفاعلي" : "Interactive Cinematic Explainer"}
              </span>
              <span className="text-[10px] bg-sky-500/20 text-sky-300 border border-sky-400/30 px-2 py-0.2 rounded font-mono">
                {isArabic ? activeScene.badgeAr : activeScene.badgeEn}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              {isArabic 
                ? "شرح فكرة المنصة وكيف تخدم الأفراد، الأطباء، والمؤسسات الصحية" 
                : "Understanding Evidentia AI: Paradigm, Architecture, and Persona Workflows"}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Audio narration toggle */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`p-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition ${
              isMuted
                ? 'bg-slate-800 text-slate-400 border-slate-700'
                : 'bg-teal-500/20 text-teal-300 border-teal-500/40 shadow-sm'
            }`}
            title={isMuted ? "Unmute Voice Narration" : "Mute Voice Narration"}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span className="text-[10px] font-mono hidden md:inline">
              {isMuted ? (isArabic ? "كتم الصوت" : "Muted") : (isArabic ? "صوت الراوي" : "Voice On")}
            </span>
          </button>

          {/* Fullscreen button */}
          <button
            onClick={handleToggleFullscreen}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          {/* Close button if provided */}
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
              title="Close Explainer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Video Screen (16:9 aspect canvas) */}
      <div className="relative aspect-[16/9] w-full bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex flex-col justify-between p-6 sm:p-10 overflow-hidden select-none">
        {/* Dynamic Background Glows */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Top Scene Subheader */}
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono font-bold bg-teal-500/20 text-teal-300 border border-teal-500/40 px-2.5 py-1 rounded-full flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping"></span>
              {isArabic ? `المشهد ${activeScene.id} من 6` : `Scene ${activeScene.id} of 6`}
            </span>
          </div>

          <div className="text-right">
            <span className="text-xs font-mono text-slate-400">
              {Math.floor(elapsedInScene)}s / {activeScene.durationSec}s
            </span>
          </div>
        </div>

        {/* Center Animated Visualization by Scene Visual Type */}
        <div className="relative z-10 my-auto py-2">
          {activeScene.visualType === 'problem' && (
            <div className="max-w-2xl mx-auto space-y-4 animate-fade-in text-center">
              <div className="inline-flex p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 mb-1">
                <AlertTriangle className="w-10 h-10 animate-bounce" />
              </div>
              <h1 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
                {isArabic ? activeScene.titleAr : activeScene.titleEn}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
                {isArabic ? activeScene.subtitleAr : activeScene.subtitleEn}
              </p>

              {/* Simulated Viral False Claims ticker */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4 text-left">
                <div className="bg-slate-900/90 border border-rose-500/30 rounded-xl p-3 flex items-start gap-2.5">
                  <span className="text-rose-400 text-xs font-bold">⚠️ {isArabic ? "شائعة مضللة:" : "Viral Myth:"}</span>
                  <p className="text-[11px] text-slate-300">
                    {isArabic 
                      ? "«العسل علاج مثالي للرضع حديثي الولادة لتهدئة المغص» ❌ (يسبب التسمم السجقي القاتل)" 
                      : "\"Honey cures newborn infant colic\" ❌ (Causes fatal infant botulism)"}
                  </p>
                </div>
                <div className="bg-slate-900/90 border border-rose-500/30 rounded-xl p-3 flex items-start gap-2.5">
                  <span className="text-rose-400 text-xs font-bold">⚠️ {isArabic ? "شائعة مضللة:" : "Viral Myth:"}</span>
                  <p className="text-[11px] text-slate-300">
                    {isArabic 
                      ? "«تناول المسكنات مع أدوية السيولة يزيل الألم بسرعة» ❌ (نزيف داخلي حاد)" 
                      : "\"Combine NSAIDs with Warfarin for fast relief\" ❌ (Major internal bleeding risk)"}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeScene.visualType === 'hallucination' && (
            <div className="max-w-2xl mx-auto space-y-4 text-center animate-fade-in">
              <div className="inline-flex p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 mb-1">
                <Cpu className="w-10 h-10 animate-pulse" />
              </div>
              <h1 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
                {isArabic ? activeScene.titleAr : activeScene.titleEn}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
                {isArabic ? activeScene.subtitleAr : activeScene.subtitleEn}
              </p>

              {/* Visual Model Hallucination Diagram */}
              <div className="bg-slate-950/90 border border-amber-500/40 rounded-xl p-4 text-left font-mono text-xs space-y-2 mt-4 max-w-lg mx-auto">
                <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
                  <span className="text-amber-300">Standard Single LLM (Uncalibrated)</span>
                  <span className="text-rose-400 font-bold">Confidence: 99.4% [HALLUCINATED]</span>
                </div>
                <p className="text-slate-300 italic">
                  "{isArabic 
                    ? "وفق دراسة د. سميث المنشورة في مجلة JAMA (PMID: 9999999 - غير موجودة)..." 
                    : "According to Dr. Smith's 2021 JAMA study (PMID: 9999999 - NONEXISTENT)..."}"
                </p>
                <div className="text-[10px] bg-rose-500/10 text-rose-300 p-2 rounded border border-rose-500/20">
                  {isArabic 
                    ? "خطر سريري: النموذج يخترع مرجعاً وهمياً كاملاً ليدعم ادعاء غير صحيح!" 
                    : "Clinical Hazard: The model fabricates a synthetic reference to validate an erroneous claim!"}
                </div>
              </div>
            </div>
          )}

          {activeScene.visualType === 'evidentia_solution' && (
            <div className="max-w-3xl mx-auto space-y-4 text-center animate-fade-in">
              <div className="inline-flex p-3 rounded-2xl bg-teal-500/10 border border-teal-500/30 text-teal-400 mb-1">
                <ShieldCheck className="w-10 h-10 animate-pulse" />
              </div>
              <h1 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
                {isArabic ? activeScene.titleAr : activeScene.titleEn}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
                {isArabic ? activeScene.subtitleAr : activeScene.subtitleEn}
              </p>

              {/* Multi-Model Court Interactive Diagram */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                <div className="bg-sky-950/60 border border-sky-400/60 rounded-xl p-2.5 text-center">
                  <div className="text-xs font-bold text-sky-300">Evidentia Ultra AI</div>
                  <div className="text-[9px] text-slate-400 font-mono mt-0.5">{isArabic ? "نظامك الخاص" : "Your Custom Core"}</div>
                  <span className="inline-block mt-1 text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.2 rounded">WHO Grounded</span>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-center">
                  <div className="text-xs font-bold text-white">Gemini 3.8 Flash</div>
                  <div className="text-[9px] text-slate-400 font-mono mt-0.5">Primary Cloud</div>
                  <span className="inline-block mt-1 text-[10px] text-teal-400 font-bold bg-teal-500/10 px-1.5 py-0.2 rounded">Synthesizer</span>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-center">
                  <div className="text-xs font-bold text-white">Claude 3.5 Sonnet</div>
                  <div className="text-[9px] text-slate-400 font-mono mt-0.5">Safety & Contraindic.</div>
                  <span className="inline-block mt-1 text-[10px] text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.2 rounded">Safety Cross-Check</span>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-center">
                  <div className="text-xs font-bold text-white">Cochrane Judge</div>
                  <div className="text-[9px] text-slate-400 font-mono mt-0.5">Level 1 EBM</div>
                  <span className="inline-block mt-1 text-[10px] text-sky-400 font-bold bg-sky-500/10 px-1.5 py-0.2 rounded">Meta-Analysis</span>
                </div>
              </div>

              {/* 6 Core Clinical Domains Highlight Ribbon */}
              <div className="pt-2 text-left">
                <span className="text-[10px] font-mono text-teal-400 font-bold uppercase tracking-wider block mb-1 text-center">
                  {isArabic ? "معايرة دقيقة ضد الهلوسة للمجالات السريرية الستة الأساسية:" : "Calibrated specifically across the 6 core clinical domains:"}
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1.5 text-center text-[10px]">
                  <span className="bg-slate-900 border border-slate-800 p-1.5 rounded-lg text-slate-200 font-medium">🦴 {isArabic ? "1. العظام والملاعب" : "1. Orthopedics"}</span>
                  <span className="bg-slate-900 border border-slate-800 p-1.5 rounded-lg text-slate-200 font-medium">🦠 {isArabic ? "2. الأمراض المعدية" : "2. Infectious AMR"}</span>
                  <span className="bg-slate-900 border border-slate-800 p-1.5 rounded-lg text-slate-200 font-medium">❤️ {isArabic ? "3. أمراض القلب" : "3. Cardiology"}</span>
                  <span className="bg-slate-900 border border-slate-800 p-1.5 rounded-lg text-slate-200 font-medium">💊 {isArabic ? "4. علم الأدوية (DDI)" : "4. Pharmacology"}</span>
                  <span className="bg-slate-900 border border-slate-800 p-1.5 rounded-lg text-slate-200 font-medium">👶 {isArabic ? "5. طب الأطفال" : "5. Pediatrics"}</span>
                  <span className="bg-slate-900 border border-slate-800 p-1.5 rounded-lg text-slate-200 font-medium">🍗 {isArabic ? "6. سلامة الغذاء" : "6. Food Safety"}</span>
                </div>
              </div>
            </div>
          )}

          {activeScene.visualType === 'normal_people' && (
            <div className="max-w-2xl mx-auto space-y-4 text-center animate-fade-in">
              <div className="inline-flex p-3 rounded-2xl bg-teal-500/10 border border-teal-500/30 text-teal-400 mb-1">
                <UserCheck className="w-10 h-10 animate-bounce" />
              </div>
              <h1 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
                {isArabic ? activeScene.titleAr : activeScene.titleEn}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
                {isArabic ? activeScene.subtitleAr : activeScene.subtitleEn}
              </p>

              {/* Simple User Mock Card */}
              <div className="bg-slate-950/90 border border-teal-500/30 rounded-2xl p-4 text-left space-y-2 mt-4 max-w-md mx-auto shadow-lg">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">
                    {isArabic ? "سؤال: هل المضادات الحيوية تشفي نزلات البرد؟" : "Query: Do antibiotics cure the common cold?"}
                  </span>
                  <span className="text-[11px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                    ❌ {isArabic ? "خرافة شائعة" : "Refuted Myth"}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isArabic 
                    ? "نزلات البرد فيروسية، والمضادات الحيوية تقتل البكتيريا فقط. استخدامها بدون داعٍ يدمر مناعتك ويسبب بكتيريا مقاومة." 
                    : "The common cold is viral. Antibiotics only kill bacteria. Overusing them causes antibiotic resistance and zero symptom relief."}
                </p>
                <div className="text-[10px] text-teal-400 font-mono flex items-center gap-1 pt-1 border-t border-slate-900">
                  <ShieldCheck className="w-3 h-3" />
                  <span>{isArabic ? "المصدر: إرشادات منظمة الصحة العالمية (WHO)" : "Source: World Health Organization (WHO)"}</span>
                </div>
              </div>
            </div>
          )}

          {activeScene.visualType === 'experts_rag' && (
            <div className="max-w-2xl mx-auto space-y-4 text-center animate-fade-in">
              <div className="inline-flex p-3 rounded-2xl bg-sky-500/10 border border-sky-500/30 text-sky-400 mb-1">
                <Stethoscope className="w-10 h-10 animate-pulse" />
              </div>
              <h1 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
                {isArabic ? activeScene.titleAr : activeScene.titleEn}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
                {isArabic ? activeScene.subtitleAr : activeScene.subtitleEn}
              </p>

              {/* Expert Features Showcase */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-4 text-left">
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-1">
                  <div className="text-xs font-bold text-teal-400 flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5" />
                    <span>{isArabic ? "رفع واستيعاب PDF" : "PDF RAG Ingestion"}</span>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    {isArabic ? "تقطيع ذكي وتوليد متجهات كثيفة L2 مع فهرسة فورية." : "Direct vector indexing with claim chunking."}
                  </p>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-1">
                  <div className="text-xs font-bold text-sky-400 flex items-center gap-1">
                    <Activity className="w-3.5 h-3.5" />
                    <span>{isArabic ? "سجلات HL7 FHIR" : "HL7 FHIR Profiles"}</span>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    {isArabic ? "كشف فوري لموانع الاستعمال وتفاعلات الأدوية الخطرة." : "Evaluates drug-drug interactions against EHR."}
                  </p>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-1">
                  <div className="text-xs font-bold text-amber-400 flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5" />
                    <span>{isArabic ? "منحنى الانحراف SPC" : "SPC Quality Drift"}</span>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    {isArabic ? "حدود تحكم إحصائية UCL/LCL لـ 50 استعلاماً سريرياً." : "Real-time accuracy drift & CUSUM tracking."}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeScene.visualType === 'institutions_db' && (
            <div className="max-w-2xl mx-auto space-y-4 text-center animate-fade-in">
              <div className="inline-flex p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mb-1">
                <Building2 className="w-10 h-10 animate-pulse" />
              </div>
              <h1 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
                {isArabic ? activeScene.titleAr : activeScene.titleEn}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
                {isArabic ? activeScene.subtitleAr : activeScene.subtitleEn}
              </p>

              {/* Institution Infrastructure Badge */}
              <div className="bg-slate-950/90 border border-emerald-500/30 rounded-xl p-4 text-left grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
                <div>
                  <span className="text-[10px] text-slate-500 font-mono block">DATABASE</span>
                  <span className="text-xs font-bold text-white">SQLite 3.x WAL</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-mono block">AI RESILIENCE</span>
                  <span className="text-xs font-bold text-teal-400">10-Model Failover</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-mono block">UNIT TESTS</span>
                  <span className="text-xs font-bold text-emerald-400">46 Automated Tests</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-mono block">INTEGRATION</span>
                  <span className="text-xs font-bold text-sky-400">OpenAPI / Postman</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Subtitle / Captions Ribbon */}
        <div className="relative z-10 bg-slate-900/90 border border-slate-800 rounded-xl p-3 backdrop-blur-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-[10px] font-mono text-teal-400 font-bold">
                {isArabic ? "الشرح الصوتي والتوجيه السريري:" : "Narration & Clinical Subtitles:"}
              </span>
              {isVoiceActive && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              )}
            </div>
            <p className="text-xs text-slate-200 font-medium leading-relaxed">
              "{isArabic ? activeScene.narrationAr : activeScene.narrationEn}"
            </p>
          </div>

          {onNavigateToTab && (
            <button
              onClick={() => {
                if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                  window.speechSynthesis.cancel();
                }
                onNavigateToTab(activeScene.targetTab);
                if (onClose) onClose();
              }}
              className="bg-teal-600 hover:bg-teal-500 text-white text-xs px-3.5 py-2 rounded-lg font-bold flex items-center justify-center gap-1.5 shadow-md shadow-teal-500/20 whitespace-nowrap transition"
            >
              <span>{isArabic ? "جرب الميزة الآن" : "Try Feature Now"}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Timeline Scrubber Bar */}
      <div className="bg-slate-900 px-4 pt-3 pb-1 border-t border-slate-800">
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden cursor-pointer relative">
          <div
            className="bg-gradient-to-r from-teal-500 to-sky-400 h-full rounded-full transition-all duration-100"
            style={{
              width: `${((currentSceneIdx + sceneProgressPercent / 100) / SCENES.length) * 100}%`
            }}
          ></div>
        </div>

        {/* Chapter markers */}
        <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mt-2 px-1">
          {SCENES.map((scene, i) => (
            <button
              key={scene.id}
              onClick={() => {
                setCurrentSceneIdx(i);
                setElapsedInScene(0);
              }}
              className={`hover:text-teal-300 transition ${
                currentSceneIdx === i ? 'text-teal-400 font-bold underline' : ''
              }`}
            >
              #{scene.id} {isArabic ? scene.titleAr.split(' ')[0] : scene.titleEn.split(' ')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Controls Bar */}
      <div className="bg-slate-950 px-4 py-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-850">
        <div className="flex items-center gap-2">
          {/* Previous Scene */}
          <button
            onClick={handlePrevScene}
            disabled={currentSceneIdx === 0}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 transition"
            title="Previous Scene"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Play/Pause Button */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-4 py-2 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-sm shadow-teal-500/20"
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-white" />
                <span>{isArabic ? "إيقاف مؤقت" : "Pause"}</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>{isArabic ? "تشغيل الفيديو" : "Play Video"}</span>
              </>
            )}
          </button>

          {/* Next Scene */}
          <button
            onClick={handleNextScene}
            disabled={currentSceneIdx === SCENES.length - 1}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 transition"
            title="Next Scene"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          {/* Restart Button */}
          <button
            onClick={handleRestart}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            title="Replay from Beginning"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Speed Selector */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-400 font-mono">{isArabic ? "السرعة:" : "Speed:"}</span>
          {[1, 1.25, 1.5].map((speed) => (
            <button
              key={speed}
              onClick={() => setPlaybackSpeed(speed)}
              className={`px-2 py-1 rounded text-[11px] font-mono transition ${
                playbackSpeed === speed
                  ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40 font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {speed}x
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
