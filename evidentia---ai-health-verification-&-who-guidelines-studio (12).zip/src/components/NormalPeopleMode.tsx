import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  HelpCircle,
  ShieldCheck,
  Volume2,
  VolumeX,
  ArrowRight,
  Sparkles,
  Heart,
  Baby,
  Pill,
  Salad,
  Activity,
  ThumbsUp,
  ThumbsDown,
  Info,
  Layers,
  Share2
} from 'lucide-react';

export interface NormalPeopleModeProps {
  isArabic: boolean;
  onSwitchToExpertCourt: (claimText: string) => void;
  onOpenVideoExplainer: () => void;
  onOpenShareProject?: () => void;
  initialDomainFilter?: string;
}

export const DOMAIN_TABS = [
  { id: "all", nameEn: "All 6 Domains", nameAr: "جميع المجالات الستة", icon: Sparkles },
  { id: "orthopedics", nameEn: "1. Sports Injuries & Orthopedics", nameAr: "1. العظام وإصابات الملاعب", icon: Activity },
  { id: "infectious_diseases", nameEn: "2. Infectious Diseases & AMR", nameAr: "2. الأمراض المعدية ومقاومة المضادات", icon: ShieldCheck },
  { id: "cardiology", nameEn: "3. Cardiology & Vascular", nameAr: "3. أمراض القلب وضغط الدم", icon: Heart },
  { id: "pharmacology", nameEn: "4. Pharmacology & Drug Safety (DDI)", nameAr: "4. الأدوية وسلامة التداخلات", icon: Pill },
  { id: "pediatrics", nameEn: "5. Pediatrics & Infant Care", nameAr: "5. صحة الرضع وطب الأطفال", icon: Baby },
  { id: "food_safety", nameEn: "6. Food Safety & Pathogens", nameAr: "6. سلامة الغذاء وميكروبيولوجيا التغذية", icon: Salad },
];

export const SIX_DOMAINS_MYTHS_DATA = [
  // 1. Orthopedics
  {
    id: "sprain_ice",
    domainId: "orthopedics",
    domainEn: "1. Sports Injuries & Orthopedics",
    domainAr: "1. طب العظام وإصابات الملاعب",
    icon: Activity,
    queryEn: "Should I put ice on an acute twisted ankle?",
    queryAr: "هل وضع الثلج على التواء الكاحل المفاجئ تصرف طبي سليم؟",
    verdict: "VERIFIED_TRUE",
    verdictLabelEn: "✅ True & Medically Proven (Recommended)",
    verdictLabelAr: "✅ كلام صحيح ومثبت طبياً (موصى به)",
    summaryEn: "Applying cold packs or ice wrapped in a damp towel for 15-20 minutes reduces swelling, dulls nerve pain, and protects tissues during the first 48 hours following an acute sprain.",
    summaryAr: "وضع كمادات الثلج ملفوفة بقطعة قماش رطبة لمدة 15 إلى 20 دقيقة خلال أول 48 ساعة من التواء المفصل يقلل التورم والالتهاب ويسكن الألم بفعالية كبيرة.",
    actionEn: "1. Follow RICE: Rest, Ice (15-20 min), Compression bandage, Elevate ankle.\n2. Never place bare ice directly on skin to prevent frostbite.\n3. If you cannot bear weight or hear a crack, get an X-ray to rule out a bone fracture.",
    actionAr: "1. طبق قاعدة RICE: راحة المفصل، ثلج (15-20 دقيقة)، رباط ضاغط خفيف، ورفع القدم.\n2. لا تضع الثلج مباشرة على الجلد العاري لتجنب عضة الصقيع.\n3. إذا كنت غير قادر على الوقوف أو سمعت صوت طقطقة عظمية، توجه فوراً لعمل أشعة للتأكد من عدم وجود كسر.",
    authority: "Cochrane Systematic Review & AAOS",
    authorityAr: "مراجعات كوكرين للطب المسند بالدليل والأكاديمية الأمريكية لجراحي العظام"
  },
  {
    id: "sprain_vs_fracture",
    domainId: "orthopedics",
    domainEn: "1. Sports Injuries & Orthopedics",
    domainAr: "1. طب العظام وإصابات الملاعب",
    icon: Activity,
    queryEn: "Is a severe ankle sprain the same as a bone fracture and needs a rigid plaster cast?",
    queryAr: "هل الالتواء الشديد مثل الكسر تماماً ويحتاج جبيرة جبسية كاملة لأشهر؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Misleading Myth (Entity Mismatch)",
    verdictLabelAr: "❌ خرافة مضللة (خطأ تشخيصي يضر المفصل)",
    summaryEn: "A sprain is a ligament stretch or tear, while a fracture is a structural bone break. Prolonged rigid plaster immobilization for simple ligament sprains causes chronic joint stiffness, muscle atrophy, and delayed functional recovery.",
    summaryAr: "الالتواء هو تمزق في الأربطة المفصلية، بينما الكسر هو انكسار في هيكل العظم. وضع جبيرة جبسية صلبة وتثبيت المفصل لأسابيع في الالتواءات البسيطة يؤدي لتيبس مزمن وضمور في العضلات وتأخر الشفاء.",
    actionEn: "1. Early functional mobilization with a supportive ankle brace yields superior outcomes for sprains.\n2. Plain radiography (X-ray via Ottawa Ankle Rules) is required if bone tenderness is present.\n3. Always have an orthopedic specialist confirm before casting.",
    actionAr: "1. الحركة الوظيفية المبكرة مع دعامة كاحل مرنة أفضل بكثير لعلاج الالتواءات مقارنة بالجبس الصلب.\n2. فحص الأشعة السينية ضروري فقط إذا وجد ألم شديد فوق عظام الكاحل (قواعد أوتاوا).\n3. لا تجبر المفصل بجبس صلب دون كشف طبي دقيق وتأكيد بالأشعة.",
    authority: "American Academy of Orthopaedic Surgeons (AAOS)",
    authorityAr: "الأكاديمية الأمريكية لجراحي العظام (AAOS)"
  },

  // 2. Infectious Diseases & AMR
  {
    id: "antibiotics_cold",
    domainId: "infectious_diseases",
    domainEn: "2. Infectious Diseases & AMR",
    domainAr: "2. الأمراض المعدية ومقاومة مضادات الميكروبات",
    icon: ShieldCheck,
    queryEn: "Do antibiotics cure the common cold and flu quickly?",
    queryAr: "هل المضاد الحيوي يعالج نزلات البرد والإنفلونزا ويسرع الشفاء؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Complete Myth (Ineffective & Harmful)",
    verdictLabelAr: "❌ خرافة خاطئة تماماً (لا تفيد وتضر مناعتك)",
    summaryEn: "Antibiotics kill bacteria, but colds, influenza, and seasonal coughs are caused by viruses. Taking antibiotics for viral infections will NOT cure you, will not prevent spreading it, and destroys your gut microbiome while creating dangerous superbugs.",
    summaryAr: "المضادات الحيوية مخصصة لقتل البكتيريا فقط، بينما نزلات البرد والإنفلونزا والتهاب الحلق الفيروسي تسببها فيروسات! تناول المضاد الحيوي للبرد لن يفيدك إطلاقاً وسيدمر بكتيريا الأمعاء النافعة ويخلق بكتيريا مقاومة.",
    actionEn: "1. Rest, hydrate with warm fluids, and use Paracetamol for fever.\n2. Viral colds naturally resolve in 5-7 days.\n3. Never take antibiotics without a doctor's explicit bacterial diagnosis.",
    actionAr: "1. الراحة التامة، شرب السوائل الدافئة، وتناول الباراسيتامول لتسكين الألم وخفض الحرارة.\n2. البرد الفيروسي يزول تلقائياً خلال 5 إلى 7 أيام.\n3. لا تتناول مضاداً حيوياً أبداً دون كشف طبي وتحليل يثبت وجود عدوى بكتيرية.",
    authority: "World Health Organization (WHO Antimicrobial Stewardship)",
    authorityAr: "منظمة الصحة العالمية (بروتوكول حماية مضادات الميكروبات)"
  },
  {
    id: "fever_starvation",
    domainId: "infectious_diseases",
    domainEn: "2. Infectious Diseases & AMR",
    domainAr: "2. الأمراض المعدية ومقاومة مضادات الميكروبات",
    icon: ShieldCheck,
    queryEn: "Should you starve a fever and stop drinking water to burn out viral infections?",
    queryAr: "هل تجويع المريض ومنع الماء أثناء الحمى يساعد على حرق الفيروسات؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Dangerous Folk Myth (Dehydration Hazard)",
    verdictLabelAr: "❌ خرافة شعبية خطيرة (تسبب جفافاً حاداً)",
    summaryEn: "Fever increases cellular metabolism and fluid loss through sweating. Withholding fluids or nutrition impairs immune leukocyte response and risks severe electrolyte imbalance, especially in children and the elderly.",
    summaryAr: "الحمى تزيد من استهلاك طاقة الجسم وفقدان السوائل عبر التعرق. حرمان المريض من السوائل أو الغذاء يضعف خلايا المناعة ويؤدي لجفاف حاد وهبوط خطير في الدورة الدموية.",
    actionEn: "1. Drink plenty of electrolyte fluids, oral rehydration solution, and broths.\n2. Eat light, nutrient-rich meals as tolerated.\n3. Monitor urine color—it should stay pale straw yellow.",
    actionAr: "1. الإكثار من شرب الماء ومحاليل الجفاف والشوربات الدافئة لتعويض السوائل المفقودة.\n2. تناول وجبات خفيفة ومغذية غنية بالفيتامينات.\n3. راقب لون البول للتأكد من رطوبة الجسم وتجنب الجفاف.",
    authority: "CDC & WHO Outbreak Guidelines",
    authorityAr: "مراكز السيطرة على الأمراض ومنظمة الصحة العالمية"
  },

  // 3. Cardiology & Vascular Health
  {
    id: "salt_hypertension",
    domainId: "cardiology",
    domainEn: "3. Cardiology & Vascular Medicine",
    domainAr: "3. أمراض القلب والأوعية الدموية وضغط الدم",
    icon: Heart,
    queryEn: "Does cutting back on salt really lower high blood pressure?",
    queryAr: "هل تقليل ملح الطعام يخفض ضغط الدم المرتفع فعلاً؟",
    verdict: "VERIFIED_TRUE",
    verdictLabelEn: "✅ Fully Proven Fact (Strong WHO Recommendation)",
    verdictLabelAr: "✅ حقيقة مثبتة بالكامل (توصية مشددة من WHO)",
    summaryEn: "Reducing daily salt intake to under 5 grams (one teaspoon per day, equivalent to 2,000 mg sodium) significantly lowers systolic blood pressure by 5 to 8 mmHg and dramatically slashes the risk of stroke and heart attack.",
    summaryAr: "خفض استهلاك الملح إلى أقل من ملعقة صغيرة يومياً (أقل من 5 غرام ملح أو 2000 ملغ صوديوم) يخفض ضغط الدم المرتفع بمقدار 5 إلى 8 درجات ويقلل خطر الإصابة بالجلطات القلبية والسكتات الدماغية.",
    actionEn: "1. Minimize canned, processed, and fast foods.\n2. Flavor food with lemon, garlic, and fresh herbs instead of table salt.\n3. Check nutrition labels for hidden sodium.",
    actionAr: "1. قلل من الأطعمة المصنعة والمعلبات والوجبات السريعة لأنها مليئة بالملح المخفي.\n2. استبدل الملح الزائد بالليمون والأعشاب الطبيعية والتوابل المفيدة.\n3. راقب قراءة ضغط الدم بانتظام مع طبيبك.",
    authority: "World Health Organization (WHO Sodium Directive)",
    authorityAr: "منظمة الصحة العالمية (توجيهات الصوديوم والقلب)"
  },
  {
    id: "pink_salt_myth",
    domainId: "cardiology",
    domainEn: "3. Cardiology & Vascular Medicine",
    domainAr: "3. أمراض القلب والأوعية الدموية وضغط الدم",
    icon: Heart,
    queryEn: "Does pink Himalayan salt not raise blood pressure like normal table salt?",
    queryAr: "هل ملح الهيمالايا الوردي آمن لمرضى الضغط ولا يرفع ضغط الدم مثل الملح الأبيض؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Marketing Myth (Same Sodium Impact)",
    verdictLabelAr: "❌ خرافة تسويقية مضللة (يحتوي على نفس الصوديوم)",
    summaryEn: "Pink Himalayan salt is chemically over 98% Sodium Chloride, exactly like regular table salt. The trace minerals give it color but do not counteract the vascular water retention and blood pressure elevation caused by sodium.",
    summaryAr: "ملح الهيمالايا الوردي يحتوي كيميائياً على أكثر من 98% كلوريد الصوديوم، وهو نفس مركب الملح الأبيض تماماً! المعادن الضئيلة تعطيه لوناً وردياً لكنها لا تمنع احتباس السوائل ولا تحمي شرايين مريض الضغط.",
    actionEn: "1. Treat all types of culinary salt (pink, sea, kosher, white) as having identical hypertensive impacts.\n2. Target < 2,000 mg total sodium daily regardless of source.\n3. Consult your cardiologist about DASH dietary pattern.",
    actionAr: "1. تعامل مع جميع أنواع الملح (الوردي، البحري، الخشن، الأبيض) على أنها ترفع الضغط بنفس الدرجة.\n2. احرص على عدم تجاوز 2000 ملغ صوديوم يومياً أياً كان نوع الملح.\n3. اتبع حمية DASH الغذائية المعتمدة لمرضى القلب والضغط.",
    authority: "American Heart Association (AHA) & WHO",
    authorityAr: "جمعية القلب الأمريكية ومنظمة الصحة العالمية"
  },

  // 4. Pharmacology & Drug Safety (DDI)
  {
    id: "warfarin_nsaids",
    domainId: "pharmacology",
    domainEn: "4. Pharmacology & Drug Safety (DDI)",
    domainAr: "4. علم الأدوية وسلامة الدواء والتداخلات الدوائية",
    icon: Pill,
    queryEn: "Can I take Ibuprofen or Aspirin for pain while taking blood thinners like Warfarin?",
    queryAr: "هل يمكنني تناول الإيبوبروفين أو الأسبرين كمسكن إذا كنت أتناول دواء سيولة مثل الوارفارين؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Black Box Danger (Severe Internal Bleeding Hazard)",
    verdictLabelAr: "❌ خطر جسيم وتحذير أسود من FDA (نزيف داخلي حاد)",
    summaryEn: "Combining NSAIDs (Ibuprofen, Naproxen, Aspirin) with oral anticoagulants drastically impairs platelet aggregation and causes severe gastrointestinal ulcers and fatal hemorrhage.",
    summaryAr: "تحذر هيئة الغذاء والدواء الأمريكية (FDA) بأعلى درجات التحذير: الجمع بين المسكنات (NSAIDs مثل البروفين والكتفلام) مع أدوية السيولة ومميعات الدم (مثل الوارفارين) يضاعف خطر حدوث نزيف معوي حاد قد يهدد الحياة.",
    actionEn: "1. Never take NSAIDs while on anticoagulant therapy without your doctor.\n2. Paracetamol (Acetaminophen) within safe dosage is generally the safer alternative for pain.\n3. Immediately seek emergency care if you notice black tarry stools or blood in urine.",
    actionAr: "1. لا تتناول أي مسكن من عائلة مضادات الالتهاب (NSAIDs) إذا كنت تتناول دواء سيولة.\n2. الباراسيتامول بجرعات معتدلة هو البديل الأكثر أماناً لتسكين الصداع والألم بعد إذن طبيبك.\n3. توجه للطوارئ فوراً إذا لاحظت برازاً أسود داكناً أو كدمات دموية مفاجئة.",
    authority: "US FDA Black Box Warning & RxNorm",
    authorityAr: "تحذيرات الصندوق الأسود لهيئة الغذاء والدواء الأمريكية (FDA)"
  },
  {
    id: "paracetamol_liver",
    domainId: "pharmacology",
    domainEn: "4. Pharmacology & Drug Safety (DDI)",
    domainAr: "4. علم الأدوية وسلامة الدواء والتداخلات الدوائية",
    icon: Pill,
    queryEn: "Is taking 8 grams of Paracetamol a day safe because it is available without prescription?",
    queryAr: "هل تناول جرعات مفرطة من الباراسيتامول آمن تماماً لأنه دواء يصرف بدون وصفة؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Fatal Toxicity Risk (Acute Liver Failure)",
    verdictLabelAr: "❌ خطر تسمم قاتل (فشل كبدي حاد)",
    summaryEn: "The maximum safe adult daily dose of Paracetamol is 4,000 mg (4 grams) in 24 hours. Exceeding this depletes hepatic glutathione, causing accumulation of the toxic metabolite NAPQI and irreversible acute liver necrosis.",
    summaryAr: "الحد الأقصى المطلق للجرعة اليومية للبالغين هو 4 غرامات (4000 ملغ) خلال 24 ساعة. تجاوز هذه الجرعة يدمر خلايا الكبد ويؤدي لفشل كبدي حاد قد يتطلب زراعة كبد عاجلة.",
    actionEn: "1. Keep total Paracetamol dose under 4,000 mg daily (or 2,000 mg if history of liver disease).\n2. Beware of combination cold medicines containing hidden Paracetamol.\n3. Space doses at least 4 to 6 hours apart.",
    actionAr: "1. لا تتجاوز 4000 ملغ يومياً (أو 2000 ملغ إذا كنت تعاني من مشاكل في الكبد).\n2. انتبه لأدوية البرد المركبة لأنها غالباً تحتوي على باراسيتامول مخفي.\n3. اترك فاصلاً زمنياً لا يقل عن 4 إلى 6 ساعات بين كل جرعة وأخرى.",
    authority: "FDA Acetaminophen Safety Guidelines",
    authorityAr: "توجيهات سلامة الأسيتامينوفين من هيئة الغذاء والدواء الأمريكية"
  },

  // 5. Pediatrics & Infant Care
  {
    id: "honey_infants",
    domainId: "pediatrics",
    domainEn: "5. Pediatrics & Infant Child Health",
    domainAr: "5. طب الأطفال وصحة الرضع والنمو",
    icon: Baby,
    queryEn: "Can I give honey to a baby under 1 year old for cough or colic?",
    queryAr: "هل مسموح بإعطاء العسل للرضيع قبل عمر سنة لعلاج الكحة أو المغص؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Extremely Dangerous Myth (Do NOT Do This)",
    verdictLabelAr: "❌ خرافة خطيرة جداً (ممنوع منعاً باتاً)",
    summaryEn: "Never give honey to babies under 12 months. Honey contains natural bacterial spores (Clostridium botulinum) that can grow inside an infant's immature digestive tract and cause Infant Botulism, a rare but life-threatening paralysis.",
    summaryAr: "يحظر إعطاء العسل للأطفال دون عمر سنة إطلاقاً! العسل قد يحتوي على جراثيم بكتيرية تسبب التسمم السجقي (Botulism) الذي قد يؤدي لشلل العضلات وصعوبة التنفس لدى الرضع.",
    actionEn: "1. If baby has a cough or colic, consult your pediatrician.\n2. Over 1 year old, honey is safe and can soothe coughs.\n3. Keep all raw and processed honey away from infants.",
    actionAr: "1. إذا كان طفلك يعاني من مغص أو كحة، استشر طبيب الأطفال ولا تعطِه أي عسل.\n2. بعد إتمام عمر سنة كاملة، يصبح العسل آمناً ومفيداً.\n3. راجع الطوارئ فوراً إذا تناول الرضيع عسلاً وظهر عليه خمول أو ضعف في الرضاعة.",
    authority: "World Health Organization (WHO) & CDC",
    authorityAr: "منظمة الصحة العالمية ومراكز مكافحة الأمراض"
  },
  {
    id: "mmr_autism_refuted",
    domainId: "pediatrics",
    domainEn: "5. Pediatrics & Infant Child Health",
    domainAr: "5. طب الأطفال وصحة الرضع والنمو",
    icon: Baby,
    queryEn: "Does the MMR vaccine cause autism in young children?",
    queryAr: "هل يسبب تطعيم الحصبة (MMR) اضطراب طيف التوحد عند الأطفال؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Conclusively Refuted Fraudulent Myth",
    verdictLabelAr: "❌ شائعة باطلة ودراسة مزورة دحضها العلم بالكامل",
    summaryEn: "Rigorous global epidemiologic studies analyzing millions of vaccinated children across 25 years conclusively confirm no causal association between the MMR vaccine and autism. Delaying vaccines exposes infants to lethal measles outbreaks.",
    summaryAr: "أثبتت الدراسات الوبائية العالمية المستفيضة على ملايين الأطفال على مدار 25 عاماً عدم وجود أي علاقة سببية إطلاقاً بين لقاح الحصبة (MMR) والتوحد. تأخير اللقاح يعرض الأطفال لخطر الوفاة بمضاعفات الحصبة والالتهاب الدماغي.",
    actionEn: "1. Follow the national routine immunization schedule.\n2. Vaccinate on time to safeguard against measles, mumps, and rubella.\n3. Consult your pediatrician regarding any vaccine concerns.",
    actionAr: "1. التزم بجدول التطعيمات الروتينية المقررة من وزارة الصحة ومنظمة الصحة العالمية.\n2. التطعيم في الموعد يحمي طفلك من مضاعفات الحصبة والنكاف الخطيرة.\n3. استشر طبيب الأطفال المعتمد لطمأنتك ولا تعتمد على شائعات الإنترنت.",
    authority: "WHO Global Advisory Committee on Vaccine Safety (GACVS)",
    authorityAr: "اللجنة الاستشارية العالمية لسلامة اللقاحات التابعة لـ WHO"
  },

  // 6. Food Safety & Nutrition
  {
    id: "chicken_room_temp",
    domainId: "food_safety",
    domainEn: "6. Food Safety & Foodborne Pathogens",
    domainAr: "6. سلامة الغذاء وميكروبيولوجيا التغذية",
    icon: Salad,
    queryEn: "Is leaving cooked chicken at room temperature overnight safe if reheated?",
    queryAr: "هل ترك الدجاج المطهو في حرارة الغرفة طوال الليل آمن إذا قمت بتسخينه جيداً؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Extremely Dangerous (Severe Food Poisoning Risk)",
    verdictLabelAr: "❌ تصرف خطير جداً (خطر تسمم غذائي شديد)",
    summaryEn: "Leaving poultry at room temperature for over 2 hours allows dangerous bacteria like Salmonella and Staphylococcus aureus to multiply exponentially and release heat-stable toxins that reheating does NOT destroy.",
    summaryAr: "ترك الدجاج أو اللحوم في حرارة الغرفة لأكثر من ساعتين يؤدي لتكاثر هائل لبكتيريا السالمونيلا وإفراز سموم بكتيرية مقاومة للحرارة؛ مما يعني أن تسخين الدجاج في الميكروويف أو الفرن لن يحميك من التسمم الحاد!",
    actionEn: "1. Discard any cooked poultry left out for more than 2 hours.\n2. Refrigerate leftovers promptly below 4°C (40°F).\n3. Reheat once to 74°C (165°F).",
    actionAr: "1. تخلص فوراً من أي طعام مطهو تُرك خارج الثلاجة لأكثر من ساعتين.\n2. احفظ الطعام المتبقي في الثلاجة تحت 4 درجات مئوية فور أن يبرد قليلاً.\n3. راجع الطبيب إذا أصبت بإسهال شديد أو قيء أو جفاف بعد تناول طعام مشكوك فيه.",
    authority: "USDA & FDA Food Safety Guidelines",
    authorityAr: "إرشادات سلامة الغذاء العالمية (FDA / USDA)"
  },
  {
    id: "wooden_cutting_board",
    domainId: "food_safety",
    domainEn: "6. Food Safety & Foodborne Pathogens",
    domainAr: "6. سلامة الغذاء وميكروبيولوجيا التغذية",
    icon: Salad,
    queryEn: "Can I cut fresh salad vegetables on the same unwashed board used for raw chicken?",
    queryAr: "هل يمكن تقطيع الخضار للسلطة على نفس لوح التقطيع بعد الدجاج النيئ دون غسيل؟",
    verdict: "DANGEROUS_MYTH",
    verdictLabelEn: "❌ Cross-Contamination Hazard (Campylobacter & Salmonella)",
    verdictLabelAr: "❌ تلوث تبادلي خطير (ينقل بكتيريا الكامبيلوباكتر والسالمونيلا)",
    summaryEn: "Raw poultry carries high titers of Salmonella and Campylobacter. Transferring raw meat juices to ready-to-eat foods like salads bypasses thermal cooking and causes severe bacterial gastroenteritis and sepsis.",
    summaryAr: "الدواجن النيئة تحمل بكتيريا السالمونيلا والكامبيلوباكتر. استخدام نفس لوح التقطيع أو السكين للخضار الطازج ينقل البكتيريا مباشرة إلى أمعائك دون أي طهي حراري يقتلها.",
    actionEn: "1. Use separate color-coded cutting boards (e.g. red for raw meat, green for produce).\n2. Wash boards, knives, and hands with hot soapy water after raw meat.\n3. Sanitize cutting boards with food-safe sanitizing solution.",
    actionAr: "1. استخدم لوحين تقطيع منفصلين: واحد مخصص للحوم النيئة والآخر للخضار والفواكه.\n2. اغسل الألواح والسكاكين بالماء الساخن والصابون بعد تقطيع اللحوم مباشرة.\n3. احرص على تعقيم أسطح المطبخ بانتظام.",
    authority: "USDA FSIS Cross-Contamination Protocols",
    authorityAr: "بروتوكولات هيئة سلامة الغذاء لمنع التلوث المتبادل"
  }
];

export default function NormalPeopleMode({
  isArabic,
  onSwitchToExpertCourt,
  onOpenVideoExplainer,
  onOpenShareProject,
  initialDomainFilter = "all"
}: NormalPeopleModeProps) {
  const [selectedDomain, setSelectedDomain] = useState<string>(initialDomainFilter);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedItem, setSelectedItem] = useState<typeof SIX_DOMAINS_MYTHS_DATA[0] | null>(SIX_DOMAINS_MYTHS_DATA[0]);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Audio readout for simple explanations
  const handleReadAloud = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    if (isSpeaking) {
      setIsSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = isArabic ? 'ar-SA' : 'en-US';
    utterance.rate = 1.0;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const filteredQueries = SIX_DOMAINS_MYTHS_DATA.filter(item => {
    const matchesDomain = selectedDomain === "all" || item.domainId === selectedDomain;
    const q = searchQuery.toLowerCase();
    const matchesSearch = !q || (
      item.queryEn.toLowerCase().includes(q) ||
      item.queryAr.includes(q) ||
      item.summaryEn.toLowerCase().includes(q) ||
      item.summaryAr.includes(q)
    );
    return matchesDomain && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Friendly Hero Banner */}
      <div className="bg-gradient-to-r from-teal-950/70 via-slate-900 to-emerald-950/50 border border-teal-500/30 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
                {isArabic ? "دليل الصحة المبسط للمجالات الستة" : "Simplified Health Truths across the 6 Domains"}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {isArabic ? "لغة بسيطة • خالية من التعقيد" : "Zero Jargon • Verified Medical Directives"}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isArabic 
                ? "هل هذه النصيحة صحيحة أم خرافة في المجالات الستة؟" 
                : "Is this advice medically sound, or a dangerous myth?"}
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {isArabic
                ? "تحقق من الشائعات الطبية الأكثر انتشاراً في مجالات: العظام وإصابات الملاعب، الأمراض المعدية، أمراض القلب، سلامة الأدوية، طب الأطفال، وسلامة الغذاء. إجابات صريحة خالية من التعقيد مدعومة بتوجيهات منظمة الصحة العالمية."
                : "Instantly check viral health claims across the 6 core domains: Orthopedics, Infectious Diseases, Cardiology, Drug Safety, Pediatrics, and Food Safety. Transparent red/green verdicts backed by WHO & CDC guidelines."}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-2.5">
            {onOpenShareProject && (
              <button
                onClick={onOpenShareProject}
                className="w-full sm:w-auto bg-slate-800/90 hover:bg-slate-700 text-teal-300 hover:text-white border border-teal-500/40 font-bold text-xs px-3.5 py-2.5 rounded-xl shadow-md flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-teal-400" />
                <span>{isArabic ? "مشاركة المنصة" : "Share Platform"}</span>
              </button>
            )}
            <button
              onClick={onOpenVideoExplainer}
              className="w-full sm:w-auto bg-gradient-to-r from-sky-600 to-teal-600 hover:from-sky-500 hover:to-teal-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-teal-500/20 flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isArabic ? "🎬 شاهد فيديو شرح المجالات الستة" : "Watch 6-Domains Video Explainer"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dedicated 6-Domains Filter Navigation Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
        <div>
          <span className="text-xs font-mono font-bold text-teal-400 uppercase tracking-wider block mb-2">
            {isArabic ? "اختر من المجالات الطبية الستة الأساسية:" : "Filter by the 6 Core Clinical Domains:"}
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-2">
            {DOMAIN_TABS.map((tab) => {
              const Icon = tab.icon;
              const isSelected = selectedDomain === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setSelectedDomain(tab.id);
                    // Select first matching item if available
                    const first = SIX_DOMAINS_MYTHS_DATA.find(i => tab.id === "all" || i.domainId === tab.id);
                    if (first) setSelectedItem(first);
                  }}
                  className={`p-2.5 rounded-xl border flex flex-col justify-between text-left transition ${
                    isSelected
                      ? 'bg-teal-500/20 border-teal-400 text-teal-200 font-bold shadow-md shadow-teal-500/10'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Icon className={`w-4 h-4 mb-1.5 ${isSelected ? 'text-teal-400' : 'text-slate-400'}`} />
                  <span className="text-xs leading-tight line-clamp-2">
                    {isArabic ? tab.nameAr : tab.nameEn}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Search Input Box */}
        <div className="relative pt-1">
          <Search className="w-5 h-5 text-teal-400 absolute left-4 top-4.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isArabic
                ? "ابحث في شائعات المجالات الستة (عسل للرضع، مضاد للبرد، ثلج على التواء، ملح الهيمالايا، وارفارين مع بروفين)..."
                : "Search claims across the 6 domains (honey infant, ice on sprain, antibiotic flu, pink salt, warfarin nsaids)..."
            }
            className="w-full bg-slate-950 border border-slate-700/80 rounded-xl pl-12 pr-4 py-3 text-sm text-slate-100 placeholder-slate-400 focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition"
          />
        </div>

        {/* Quick Questions in Selected Domain */}
        <div>
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2 font-mono">
            {isArabic ? "الادعاءات والشائعات المتاحة في هذا المجال:" : "Verified Claims & Clinical Myths in this Domain:"}
          </span>
          <div className="flex flex-wrap gap-2">
            {filteredQueries.map((item) => {
              const Icon = item.icon;
              const isSelected = selectedItem?.id === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className={`text-xs px-3 py-2 rounded-xl border flex items-center gap-2 transition text-left cursor-pointer ${
                    isSelected
                      ? 'bg-teal-500/20 border-teal-500 text-teal-200 font-bold shadow-md shadow-teal-500/10'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-teal-400' : 'text-slate-400'}`} />
                  <span className="line-clamp-1">{isArabic ? item.queryAr : item.queryEn}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Selected Claim Detailed Card */}
      {selectedItem && (
        <div className="bg-slate-900 border-2 border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-2xl">
          {/* Question & Verdict Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="space-y-1">
              <span className="text-xs font-mono text-teal-400 font-bold uppercase tracking-wider bg-teal-500/10 px-2.5 py-0.5 rounded border border-teal-500/20 inline-block">
                {isArabic ? selectedItem.domainAr : selectedItem.domainEn}
              </span>
              <h2 className="text-lg sm:text-xl font-bold text-white leading-snug mt-1">
                "{isArabic ? selectedItem.queryAr : selectedItem.queryEn}"
              </h2>
            </div>

            {/* Verdict Badge */}
            <div className="self-start sm:self-auto">
              <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold border shadow-sm ${
                selectedItem.verdict === 'VERIFIED_TRUE'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
              }`}>
                {isArabic ? selectedItem.verdictLabelAr : selectedItem.verdictLabelEn}
              </span>
            </div>
          </div>

          {/* Plain Language Summary */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-teal-300 flex items-center gap-2">
                <Info className="w-4 h-4 text-teal-400" />
                <span>{isArabic ? "الخلاصة بكلمات بسيطة وسهلة:" : "The Bottom Line in Plain Words:"}</span>
              </h3>

              <button
                onClick={() => handleReadAloud(isArabic ? selectedItem.summaryAr : selectedItem.summaryEn)}
                className={`text-xs px-2.5 py-1 rounded-lg border flex items-center gap-1.5 transition cursor-pointer ${
                  isSpeaking
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
                title="Read summary aloud"
              >
                {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-teal-400" />}
                <span className="text-[11px] font-mono">
                  {isSpeaking ? (isArabic ? "إيقاف الصوت" : "Stop Voice") : (isArabic ? "استمع صوتياً" : "Listen")}
                </span>
              </button>
            </div>

            <p className="text-sm text-slate-200 leading-relaxed bg-slate-950/70 border border-slate-800 p-4 rounded-xl">
              {isArabic ? selectedItem.summaryAr : selectedItem.summaryEn}
            </p>
          </div>

          {/* Actionable Steps Box */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>{isArabic ? "ماذا يجب أن تفعل عملياً؟" : "What Should You Do?"}</span>
            </h3>

            <div className="bg-slate-950/70 border border-slate-800 p-4 rounded-xl space-y-2 text-xs text-slate-300 whitespace-pre-line leading-relaxed font-mono">
              {isArabic ? selectedItem.actionAr : selectedItem.actionEn}
            </div>
          </div>

          {/* Official Source & Expert Deep-Dive */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-slate-800 text-xs">
            <div className="flex items-center gap-2 text-slate-400">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>
                {isArabic ? "المرجع الرسمي المعتمد:" : "Official Medical Source:"}{" "}
                <strong className="text-slate-200">{isArabic ? selectedItem.authorityAr : selectedItem.authority}</strong>
              </span>
            </div>

            <button
              onClick={() => onSwitchToExpertCourt(isArabic ? selectedItem.queryAr : selectedItem.queryEn)}
              className="text-teal-400 hover:text-teal-300 font-bold flex items-center gap-1.5 transition self-start sm:self-auto cursor-pointer"
            >
              <span>{isArabic ? "فحص الأدلة في محكمة الأطباء والخبراء" : "Deep-Dive in Scientific Evidence Court"}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
