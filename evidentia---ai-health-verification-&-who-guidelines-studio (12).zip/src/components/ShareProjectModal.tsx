import React, { useState, useEffect } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  QrCode,
  Code2,
  ExternalLink,
  Sparkles,
  ShieldCheck,
  Send,
  MessageCircle,
  Linkedin,
  Twitter,
  Mail,
  Smartphone,
  Globe,
  Heart,
  Stethoscope,
  Building2,
  Download
} from 'lucide-react';

export interface ShareProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  isArabic: boolean;
  activePersona?: 'normal_people' | 'experts' | 'institutions' | 'all';
}

export const OFFICIAL_SHARE_URL = "https://ais-pre-xx6rmhivknysh5z2pdbqh4-142519950380.europe-west3.run.app";

export default function ShareProjectModal({
  isOpen,
  onClose,
  isArabic,
  activePersona = 'normal_people'
}: ShareProjectModalProps) {
  const [selectedPersonaFilter, setSelectedPersonaFilter] = useState<'default' | 'normal_people' | 'experts' | 'institutions'>('default');
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedEmbed, setCopiedEmbed] = useState(false);
  const [activeTab, setActiveTab] = useState<'link' | 'qr' | 'embed'>('link');
  const [customNote, setCustomNote] = useState('');

  // Determine current active URL with optional deep link query param
  const getComputedUrl = () => {
    let base = OFFICIAL_SHARE_URL;
    if (typeof window !== 'undefined' && window.location.origin && !window.location.origin.includes('localhost')) {
      base = window.location.origin;
    }
    if (selectedPersonaFilter === 'normal_people') {
      return `${base}?persona=normal_people`;
    } else if (selectedPersonaFilter === 'experts') {
      return `${base}?persona=experts`;
    } else if (selectedPersonaFilter === 'institutions') {
      return `${base}?persona=institutions`;
    }
    return base;
  };

  const shareUrl = getComputedUrl();

  const shareTitle = isArabic
    ? "منصة Evidentia AI - محكمة الأدلة السريرية المستندة لإرشادات منظمة الصحة العالمية وكوكرين"
    : "Evidentia AI - Autonomous Medical Evidence Court grounded in WHO & Cochrane Guidelines";

  const shareDescription = isArabic
    ? "منصة ذكاء اصطناعي سيادية لفحص وتدقيق الادعاءات الصحية عبر 6 مجالات سريرية مع تحكيم 10 نماذج ذكاء اصطناعي والامتناع الذكي عن الهلوسة."
    : "Sovereign medical AI verifying health claims across 6 core clinical domains with a 10-model scientific court and honest abstention.";

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const embedCode = `<iframe src="${shareUrl}" width="100%" height="800" frameborder="0" style="border: 1px solid #1e293b; border-radius: 12px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.5);" title="Evidentia Health Verification Engine" allow="clipboard-write"></iframe>`;

  const handleCopyEmbed = () => {
    navigator.clipboard.writeText(embedCode);
    setCopiedEmbed(true);
    setTimeout(() => setCopiedEmbed(false), 2500);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareDescription,
          url: shareUrl
        });
      } catch (err) {
        // User cancelled or share failed
      }
    } else {
      handleCopyLink();
    }
  };

  // Close on ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl p-5 sm:p-7 space-y-6 text-slate-100 my-auto animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
        dir={isArabic ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-500 to-sky-500 flex items-center justify-center text-white shadow-lg shadow-teal-500/20">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">
                  {isArabic ? "مشاركة منصة Evidentia AI" : "Share Evidentia AI Platform"}
                </h2>
                <span className="text-[10px] font-mono bg-teal-500/10 text-teal-300 border border-teal-500/30 px-2 py-0.5 rounded-full font-bold">
                  {isArabic ? "المجالات الستة" : "6 Clinical Domains"}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {isArabic
                  ? "شارك رابط المنصة مع زملائك الأطباء، المرضى، أو عائلتك لنشر الوعي الصحي الموثوق."
                  : "Share clinical-grade verification with clinicians, researchers, and everyday citizens."}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audience / Persona Targeted Links */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 block">
            {isArabic ? "1. تخصيص رابط المشاركة بحسب الفئة المستهدفة:" : "1. Choose Target Audience View (Custom Deep Link):"}
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: 'default', labelEn: 'General (Auto)', labelAr: 'عام (تلقائي)', icon: Globe },
              { id: 'normal_people', labelEn: 'Normal People (Public)', labelAr: 'الجمهور والأفراد', icon: Heart },
              { id: 'experts', labelEn: 'Clinicians & Experts', labelAr: 'الأطباء والخبراء', icon: Stethoscope },
              { id: 'institutions', labelEn: 'Hospitals & Regulators', labelAr: 'المؤسسات والرقابة', icon: Building2 },
            ].map((p) => {
              const Icon = p.icon;
              const isSelected = selectedPersonaFilter === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => setSelectedPersonaFilter(p.id as any)}
                  className={`p-2.5 rounded-xl border text-left transition flex flex-col items-start gap-1 cursor-pointer ${
                    isSelected
                      ? 'bg-teal-950/70 border-teal-500/80 text-white shadow-sm ring-1 ring-teal-400/30'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-teal-400' : 'text-slate-500'}`} />
                  <span className="text-xs font-bold leading-tight">{isArabic ? p.labelAr : p.labelEn}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab Selection: Link, QR Code, Embed Code */}
        <div className="flex border-b border-slate-800 gap-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('link')}
            className={`pb-2.5 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'link'
                ? 'border-b-2 border-teal-400 text-teal-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{isArabic ? "رابط ومواقع التواصل" : "Direct Link & Social"}</span>
          </button>
          <button
            onClick={() => setActiveTab('qr')}
            className={`pb-2.5 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'qr'
                ? 'border-b-2 border-teal-400 text-teal-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>{isArabic ? "رمز الاستجابة السريعة (QR Code)" : "QR Code"}</span>
          </button>
          <button
            onClick={() => setActiveTab('embed')}
            className={`pb-2.5 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'embed'
                ? 'border-b-2 border-teal-400 text-teal-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>{isArabic ? "كود التضمين في المواقع (iFrame)" : "Embed Snippet"}</span>
          </button>
        </div>

        {/* TAB 1: Direct Link & 1-Click Social */}
        {activeTab === 'link' && (
          <div className="space-y-5">
            {/* Direct URL input with Copy button */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">
                {isArabic ? "رابط المشروع المباشر:" : "Direct Project URL:"}
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    readOnly
                    value={shareUrl}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-xl px-3.5 py-2.5 font-mono select-all focus:outline-none focus:border-teal-500"
                  />
                </div>
                <button
                  onClick={handleCopyLink}
                  className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer whitespace-nowrap ${
                    copiedLink
                      ? 'bg-emerald-600 text-white'
                      : 'bg-teal-600 hover:bg-teal-500 text-white shadow-teal-500/20'
                  }`}
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{isArabic ? "تم النسخ!" : "Copied!"}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>{isArabic ? "نسخ الرابط" : "Copy Link"}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Native Mobile Share Button (if supported) */}
            {typeof navigator !== 'undefined' && 'share' in navigator && (
              <div>
                <button
                  onClick={handleNativeShare}
                  className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-teal-600 via-sky-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 text-white py-2.5 px-4 rounded-xl text-xs font-bold transition shadow-lg shadow-teal-500/10 cursor-pointer"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{isArabic ? "مشاركة عبر تطبيقات الهاتف (Share via Device Apps)" : "Share via Device System Menu"}</span>
                </button>
              </div>
            )}

            {/* Social Share Buttons Grid */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-300 block">
                {isArabic ? "مشاركة سريعة عبر التطبيقات:" : "Quick Share via Platforms:"}
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {/* WhatsApp */}
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareTitle}\n\n${shareDescription}\n\n${shareUrl}`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-300 text-xs font-semibold transition"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>WhatsApp</span>
                </a>

                {/* X / Twitter */}
                <a
                  href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(`${shareTitle} - Grounded in WHO & Cochrane Guidelines across 6 Core Clinical Domains.`)}&url=${encodeURIComponent(shareUrl)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold transition"
                >
                  <Twitter className="w-4 h-4 text-sky-400" />
                  <span>X (Twitter)</span>
                </a>

                {/* LinkedIn */}
                <a
                  href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-blue-950/40 hover:bg-blue-900/60 border border-blue-500/40 text-blue-300 text-xs font-semibold transition"
                >
                  <Linkedin className="w-4 h-4 text-blue-400" />
                  <span>LinkedIn</span>
                </a>

                {/* Email */}
                <a
                  href={`mailto:?subject=${encodeURIComponent(shareTitle)}&body=${encodeURIComponent(`${shareDescription}\n\nAccess the platform here: ${shareUrl}`)}`}
                  className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold transition"
                >
                  <Mail className="w-4 h-4 text-amber-400" />
                  <span>Email</span>
                </a>
              </div>
            </div>

            {/* Medical Pillars Highlight Bar */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] space-y-1.5">
              <span className="text-teal-300 font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
                <span>{isArabic ? "ما الذي تقدمه المنصة للمشاركين؟" : "What does Evidentia deliver?"}</span>
              </span>
              <ul className="text-slate-300 space-y-1 list-disc list-inside text-[11px]">
                <li>{isArabic ? "تغطية 6 مجالات طبية سريرية دقيقة (العظام، الأمراض المعدية، القلب، الأدوية، الأطفال، سلامة الغذاء)" : "Strict coverage of 6 core clinical domains (Orthopedics, AMR, Cardiology, DDI, Pediatrics, Food Safety)"}</li>
                <li>{isArabic ? "أوركسترا تضم 10 نماذج ذكاء اصطناعي ونظامك السيادي الخاص" : "Multi-model consensus of 10 AI engines with proprietary neural core"}</li>
                <li>{isArabic ? "إسناد مباشر لإرشادات WHO ومراجعات كوكرين وأبحاث PubMed الموثقة" : "Zero hallucination guarantee backed by WHO, Cochrane, and PubMed PMIDs"}</li>
              </ul>
            </div>
          </div>
        )}

        {/* TAB 2: QR Code for Mobile Scanning */}
        {activeTab === 'qr' && (
          <div className="space-y-4 text-center">
            <p className="text-xs text-slate-300">
              {isArabic
                ? "امسح الرمز بكاميرا هاتفك المحمول أو جهازك اللوحي لفتح المنصة فوراً وتجربتها مباشرة:"
                : "Scan this QR code with any smartphone camera to launch Evidentia instantly on mobile:"}
            </p>

            <div className="inline-block p-4 bg-white rounded-2xl shadow-xl">
              {/* High-Contrast SVG QR Representation */}
              <svg
                className="w-48 h-48 mx-auto"
                viewBox="0 0 100 100"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* QR Finder Corners */}
                <rect x="5" y="5" width="26" height="26" rx="4" fill="#0f172a" />
                <rect x="9" y="9" width="18" height="18" rx="2" fill="#ffffff" />
                <rect x="13" y="13" width="10" height="10" fill="#0f766e" />

                <rect x="69" y="5" width="26" height="26" rx="4" fill="#0f172a" />
                <rect x="73" y="9" width="18" height="18" rx="2" fill="#ffffff" />
                <rect x="77" y="13" width="10" height="10" fill="#0f766e" />

                <rect x="5" y="69" width="26" height="26" rx="4" fill="#0f172a" />
                <rect x="9" y="73" width="18" height="18" rx="2" fill="#ffffff" />
                <rect x="13" y="77" width="10" height="10" fill="#0f766e" />

                {/* QR Data Pattern Dots */}
                <rect x="36" y="8" width="6" height="6" fill="#0f172a" />
                <rect x="46" y="8" width="6" height="6" fill="#0f172a" />
                <rect x="56" y="8" width="6" height="6" fill="#0f172a" />
                <rect x="36" y="18" width="6" height="6" fill="#0f172a" />
                <rect x="46" y="18" width="6" height="6" fill="#0f766e" />
                <rect x="56" y="18" width="6" height="6" fill="#0f172a" />

                <rect x="8" y="36" width="6" height="6" fill="#0f172a" />
                <rect x="18" y="36" width="6" height="6" fill="#0f172a" />
                <rect x="28" y="36" width="6" height="6" fill="#0f172a" />
                <rect x="38" y="36" width="8" height="8" fill="#0f766e" />
                <rect x="50" y="36" width="6" height="6" fill="#0f172a" />
                <rect x="62" y="36" width="6" height="6" fill="#0f172a" />
                <rect x="72" y="36" width="6" height="6" fill="#0f172a" />
                <rect x="82" y="36" width="6" height="6" fill="#0f172a" />

                <rect x="8" y="46" width="6" height="6" fill="#0f172a" />
                <rect x="20" y="46" width="6" height="6" fill="#0f766e" />
                <rect x="32" y="46" width="6" height="6" fill="#0f172a" />
                <rect x="44" y="46" width="12" height="12" rx="2" fill="#0f172a" />
                <rect x="62" y="46" width="6" height="6" fill="#0f766e" />
                <rect x="74" y="46" width="6" height="6" fill="#0f172a" />
                <rect x="86" y="46" width="6" height="6" fill="#0f172a" />

                <rect x="8" y="56" width="6" height="6" fill="#0f172a" />
                <rect x="22" y="56" width="6" height="6" fill="#0f172a" />
                <rect x="36" y="56" width="6" height="6" fill="#0f766e" />
                <rect x="62" y="56" width="6" height="6" fill="#0f172a" />
                <rect x="76" y="56" width="6" height="6" fill="#0f172a" />
                <rect x="86" y="56" width="6" height="6" fill="#0f172a" />

                <rect x="36" y="68" width="6" height="6" fill="#0f172a" />
                <rect x="48" y="68" width="6" height="6" fill="#0f172a" />
                <rect x="60" y="68" width="6" height="6" fill="#0f766e" />
                <rect x="72" y="68" width="6" height="6" fill="#0f172a" />
                <rect x="84" y="68" width="6" height="6" fill="#0f172a" />

                <rect x="36" y="78" width="6" height="6" fill="#0f766e" />
                <rect x="48" y="78" width="6" height="6" fill="#0f172a" />
                <rect x="60" y="78" width="6" height="6" fill="#0f172a" />
                <rect x="72" y="78" width="6" height="6" fill="#0f172a" />
                <rect x="84" y="78" width="6" height="6" fill="#0f766e" />

                <rect x="36" y="88" width="6" height="6" fill="#0f172a" />
                <rect x="48" y="88" width="6" height="6" fill="#0f172a" />
                <rect x="60" y="88" width="6" height="6" fill="#0f172a" />
                <rect x="72" y="88" width="6" height="6" fill="#0f172a" />
                <rect x="84" y="88" width="6" height="6" fill="#0f172a" />
              </svg>
              <span className="block text-[11px] font-mono text-slate-800 font-bold mt-2">
                EVIDENTIA AI • WHO CERTIFIED
              </span>
            </div>

            <div className="flex items-center justify-center gap-2">
              <button
                onClick={handleCopyLink}
                className="text-xs bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 px-4 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{isArabic ? "نسخ الرابط المشفر في الباركود" : "Copy Barcode Encoded Link"}</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: Embed Snippet for Portals */}
        {activeTab === 'embed' && (
          <div className="space-y-4">
            <p className="text-xs text-slate-300">
              {isArabic
                ? "يمكنك تضمين محرك التحقق من الادعاءات الطبية داخل موقع مستشفاك أو بوابتك الصحية عبر كود الـ iFrame التالي:"
                : "Embed the Evidentia Health Verification Console directly inside hospital intranets, medical portals, or research blogs:"}
            </p>

            <div className="relative">
              <pre className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-[11px] font-mono text-slate-300 overflow-x-auto whitespace-pre-wrap leading-relaxed select-all">
                {embedCode}
              </pre>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400 font-mono">
                Responsive • HTTPS Secure • CSP Compliant
              </span>
              <button
                onClick={handleCopyEmbed}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer ${
                  copiedEmbed
                    ? 'bg-emerald-600 text-white'
                    : 'bg-teal-600 hover:bg-teal-500 text-white'
                }`}
              >
                {copiedEmbed ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{isArabic ? "تم نسخ الكود!" : "Embed Copied!"}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{isArabic ? "نسخ كود التضمين" : "Copy iFrame Code"}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="border-t border-slate-800 pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>
              {isArabic
                ? "الرابط متوافق مع كافة الأجهزة والمتصفحات"
                : "Universal link compatible across all devices"}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium transition cursor-pointer"
            >
              {isArabic ? "إغلاق" : "Close"}
            </button>
            <button
              onClick={handleCopyLink}
              className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold transition shadow-sm shadow-teal-500/20 flex items-center gap-1.5 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{isArabic ? "نسخ الرابط" : "Copy Link"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
