import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import {
  Activity,
  Zap,
  Cpu,
  RefreshCw,
  Play,
  Pause,
  Flame,
  ArrowUpRight,
  TrendingDown,
  Layers,
  Database,
  BarChart3,
  Server
} from 'lucide-react';

interface MetricPoint {
  time: Date;
  requestsPerSec: number;
  geminiLatency: number;
  claudeLatency: number;
  openaiLatency: number;
  ollamaLatency: number;
  cacheLatency: number;
  cacheHit: boolean;
}

export default function RealTimeMetricsDashboard({ isArabic }: { isArabic?: boolean }) {
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [trafficMode, setTrafficMode] = useState<'normal' | 'burst' | 'low'>('normal');
  const [activeProviders, setActiveProviders] = useState({
    gemini: true,
    claude: true,
    openai: true,
    ollama: true,
    cache: true,
  });

  // Aggregated live KPIs
  const [kpis, setKpis] = useState({
    totalRequests: 18450,
    currentRps: 34,
    p95Latency: 285,
    cacheHitRatio: 78.4,
    totalSavedUsd: 184.20
  });

  // Data history ref (last 25 points)
  const historyRef = useRef<MetricPoint[]>([]);

  // SVG Chart Refs
  const throughputSvgRef = useRef<SVGSVGElement | null>(null);
  const latencySvgRef = useRef<SVGSVGElement | null>(null);
  const cacheDonutSvgRef = useRef<SVGSVGElement | null>(null);

  // Initialize initial history buffer
  useEffect(() => {
    const now = Date.now();
    const initial: MetricPoint[] = [];
    for (let i = 24; i >= 0; i--) {
      const t = new Date(now - i * 1500);
      initial.push({
        time: t,
        requestsPerSec: Math.floor(25 + Math.random() * 15),
        geminiLatency: Math.floor(220 + Math.random() * 60),
        claudeLatency: Math.floor(450 + Math.random() * 90),
        openaiLatency: Math.floor(310 + Math.random() * 70),
        ollamaLatency: Math.floor(130 + Math.random() * 40),
        cacheLatency: Math.floor(8 + Math.random() * 6),
        cacheHit: Math.random() < 0.78
      });
    }
    historyRef.current = initial;
  }, []);

  // Live data tick generator
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      const now = new Date();
      let rpsBase = 30;
      let rpsVar = 14;

      if (trafficMode === 'burst') {
        rpsBase = 140;
        rpsVar = 40;
      } else if (trafficMode === 'low') {
        rpsBase = 8;
        rpsVar = 5;
      }

      const rps = Math.max(2, Math.floor(rpsBase + (Math.random() - 0.4) * rpsVar));
      const isCacheHit = Math.random() < (trafficMode === 'burst' ? 0.88 : 0.78);

      const newPoint: MetricPoint = {
        time: now,
        requestsPerSec: rps,
        geminiLatency: Math.floor(210 + (trafficMode === 'burst' ? 90 : 0) + Math.random() * 80),
        claudeLatency: Math.floor(440 + (trafficMode === 'burst' ? 140 : 0) + Math.random() * 110),
        openaiLatency: Math.floor(300 + (trafficMode === 'burst' ? 95 : 0) + Math.random() * 90),
        ollamaLatency: Math.floor(120 + (trafficMode === 'burst' ? 50 : 0) + Math.random() * 40),
        cacheLatency: Math.floor(7 + Math.random() * 7),
        cacheHit: isCacheHit
      };

      const nextHistory = [...historyRef.current.slice(1), newPoint];
      historyRef.current = nextHistory;

      // Update KPIs
      setKpis(prev => {
        const addedHits = isCacheHit ? 1 : 0;
        const newTotal = prev.totalRequests + rps;
        return {
          totalRequests: newTotal,
          currentRps: rps,
          p95Latency: Math.floor(260 + (trafficMode === 'burst' ? 80 : 0) + Math.random() * 40),
          cacheHitRatio: Number((((prev.cacheHitRatio * 30) + (isCacheHit ? 100 : 0)) / 31).toFixed(1)),
          totalSavedUsd: Number((prev.totalSavedUsd + (addedHits * 0.003)).toFixed(3))
        };
      });

      // Render charts
      renderThroughputChart(nextHistory);
      renderLatencyChart(nextHistory);
      renderCacheDonut(nextHistory);
    }, 1500);

    return () => clearInterval(interval);
  }, [isRunning, trafficMode, activeProviders]);

  // Initial render when charts mount
  useEffect(() => {
    if (historyRef.current.length > 0) {
      renderThroughputChart(historyRef.current);
      renderLatencyChart(historyRef.current);
      renderCacheDonut(historyRef.current);
    }
  }, [activeProviders]);

  // -------------------------------------------------------------
  // D3 CHART 1: Throughput Area / Line Chart
  // -------------------------------------------------------------
  const renderThroughputChart = (data: MetricPoint[]) => {
    if (!throughputSvgRef.current) return;
    const svg = d3.select(throughputSvgRef.current);
    svg.selectAll('*').remove();

    const width = throughputSvgRef.current.clientWidth || 450;
    const height = 180;
    const margin = { top: 15, right: 15, bottom: 25, left: 35 };
    const innerW = width - margin.left - margin.right;
    const innerH = height - margin.top - margin.bottom;

    const g = svg
      .attr('viewBox', `0 0 ${width} ${height}`)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Scales
    const x = d3
      .scaleTime()
      .domain(d3.extent(data, d => d.time) as [Date, Date])
      .range([0, innerW]);

    const y = d3
      .scaleLinear()
      .domain([0, Math.max(50, (d3.max(data, d => d.requestsPerSec) || 40) * 1.2)])
      .nice()
      .range([innerH, 0]);

    // Gradient definitions
    const defs = svg.append('defs');
    const grad = defs
      .append('linearGradient')
      .attr('id', 'throughput-grad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');

    grad.append('stop').attr('offset', '0%').attr('stop-color', '#14b8a6').attr('stop-opacity', 0.45);
    grad.append('stop').attr('offset', '100%').attr('stop-color', '#14b8a6').attr('stop-opacity', 0.0);

    // Grid lines
    g.append('g')
      .attr('class', 'grid')
      .call(
        d3
          .axisLeft(y)
          .ticks(4)
          .tickSize(-innerW)
          .tickFormat(() => '')
      )
      .selectAll('line')
      .attr('stroke', '#1e293b')
      .attr('stroke-dasharray', '2,2');

    // Axes
    const xAxis = d3
      .axisBottom(x)
      .ticks(5)
      .tickFormat(d => d3.timeFormat('%M:%S')(d as Date));

    const yAxis = d3.axisLeft(y).ticks(4);

    g.append('g')
      .attr('transform', `translate(0,${innerH})`)
      .call(xAxis)
      .call(g => g.select('.domain').attr('stroke', '#334155'))
      .call(g => g.selectAll('.tick line').attr('stroke', '#334155'))
      .call(g => g.selectAll('.tick text').attr('fill', '#94a3b8').attr('font-size', '10px').attr('font-family', 'monospace'));

    g.append('g')
      .call(yAxis)
      .call(g => g.select('.domain').attr('stroke', '#334155'))
      .call(g => g.selectAll('.tick line').attr('stroke', '#334155'))
      .call(g => g.selectAll('.tick text').attr('fill', '#94a3b8').attr('font-size', '10px').attr('font-family', 'monospace'));

    // Area
    const area = d3
      .area<MetricPoint>()
      .curve(d3.curveMonotoneX)
      .x(d => x(d.time))
      .y0(innerH)
      .y1(d => y(d.requestsPerSec));

    g.append('path')
      .datum(data)
      .attr('fill', 'url(#throughput-grad)')
      .attr('d', area);

    // Line
    const line = d3
      .line<MetricPoint>()
      .curve(d3.curveMonotoneX)
      .x(d => x(d.time))
      .y(d => y(d.requestsPerSec));

    g.append('path')
      .datum(data)
      .attr('fill', 'none')
      .attr('stroke', '#14b8a6')
      .attr('stroke-width', 2.5)
      .attr('d', line);

    // Pulsing current dot at the end
    const lastPoint = data[data.length - 1];
    if (lastPoint) {
      g.append('circle')
        .attr('cx', x(lastPoint.time))
        .attr('cy', y(lastPoint.requestsPerSec))
        .attr('r', 4)
        .attr('fill', '#2dd4bf')
        .attr('stroke', '#042f2e')
        .attr('stroke-width', 2);
    }
  };

  // -------------------------------------------------------------
  // D3 CHART 2: Latency Trends Across Providers (Multi-Line)
  // -------------------------------------------------------------
  const renderLatencyChart = (data: MetricPoint[]) => {
    if (!latencySvgRef.current) return;
    const svg = d3.select(latencySvgRef.current);
    svg.selectAll('*').remove();

    const width = latencySvgRef.current.clientWidth || 550;
    const height = 180;
    const margin = { top: 15, right: 15, bottom: 25, left: 40 };
    const innerW = width - margin.left - margin.right;
    const innerH = height - margin.top - margin.bottom;

    const g = svg
      .attr('viewBox', `0 0 ${width} ${height}`)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const x = d3
      .scaleTime()
      .domain(d3.extent(data, d => d.time) as [Date, Date])
      .range([0, innerW]);

    const y = d3
      .scaleLinear()
      .domain([0, 750])
      .nice()
      .range([innerH, 0]);

    // Grid lines
    g.append('g')
      .attr('class', 'grid')
      .call(
        d3
          .axisLeft(y)
          .ticks(4)
          .tickSize(-innerW)
          .tickFormat(() => '')
      )
      .selectAll('line')
      .attr('stroke', '#1e293b')
      .attr('stroke-dasharray', '2,2');

    // Axes
    const xAxis = d3
      .axisBottom(x)
      .ticks(5)
      .tickFormat(d => d3.timeFormat('%M:%S')(d as Date));

    const yAxis = d3.axisLeft(y).ticks(4).tickFormat(d => `${d}ms`);

    g.append('g')
      .attr('transform', `translate(0,${innerH})`)
      .call(xAxis)
      .call(g => g.select('.domain').attr('stroke', '#334155'))
      .call(g => g.selectAll('.tick line').attr('stroke', '#334155'))
      .call(g => g.selectAll('.tick text').attr('fill', '#94a3b8').attr('font-size', '10px').attr('font-family', 'monospace'));

    g.append('g')
      .call(yAxis)
      .call(g => g.select('.domain').attr('stroke', '#334155'))
      .call(g => g.selectAll('.tick line').attr('stroke', '#334155'))
      .call(g => g.selectAll('.tick text').attr('fill', '#94a3b8').attr('font-size', '10px').attr('font-family', 'monospace'));

    // Providers to plot
    const series = [
      { key: 'claude', name: 'Claude 3.5', color: '#f59e0b', accessor: (d: MetricPoint) => d.claudeLatency, active: activeProviders.claude },
      { key: 'openai', name: 'GPT-4o-mini', color: '#3b82f6', accessor: (d: MetricPoint) => d.openaiLatency, active: activeProviders.openai },
      { key: 'gemini', name: 'Gemini 3.8', color: '#10b981', accessor: (d: MetricPoint) => d.geminiLatency, active: activeProviders.gemini },
      { key: 'ollama', name: 'Ollama local', color: '#a855f7', accessor: (d: MetricPoint) => d.ollamaLatency, active: activeProviders.ollama },
      { key: 'cache', name: 'Semantic Cache', color: '#06b6d4', accessor: (d: MetricPoint) => d.cacheLatency, active: activeProviders.cache },
    ];

    series.forEach(s => {
      if (!s.active) return;
      const line = d3
        .line<MetricPoint>()
        .curve(d3.curveMonotoneX)
        .x(d => x(d.time))
        .y(d => y(s.accessor(d)));

      g.append('path')
        .datum(data)
        .attr('fill', 'none')
        .attr('stroke', s.color)
        .attr('stroke-width', s.key === 'cache' ? 2.5 : 1.8)
        .attr('d', line);
    });
  };

  // -------------------------------------------------------------
  // D3 CHART 3: Semantic Cache Donut & Breakdown
  // -------------------------------------------------------------
  const renderCacheDonut = (data: MetricPoint[]) => {
    if (!cacheDonutSvgRef.current) return;
    const svg = d3.select(cacheDonutSvgRef.current);
    svg.selectAll('*').remove();

    const width = cacheDonutSvgRef.current.clientWidth || 220;
    const height = 180;
    const radius = Math.min(width, height) / 2 - 12;

    const g = svg
      .attr('viewBox', `0 0 ${width} ${height}`)
      .append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    const hitRate = kpis.cacheHitRatio;
    const pieData = [
      { label: 'Hits', value: hitRate, color: '#14b8a6' },
      { label: 'Misses', value: 100 - hitRate, color: '#334155' }
    ];

    const pie = d3.pie<{ label: string; value: number; color: string }>().value(d => d.value).sort(null);
    const arc = d3.arc<d3.PieArcDatum<{ label: string; value: number; color: string }>>()
      .innerRadius(radius - 14)
      .outerRadius(radius)
      .cornerRadius(4);

    g.selectAll('path')
      .data(pie(pieData))
      .enter()
      .append('path')
      .attr('d', arc as any)
      .attr('fill', d => d.data.color)
      .attr('stroke', '#090d16')
      .attr('stroke-width', 2);

    // Center text
    g.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '-0.1em')
      .attr('fill', '#ffffff')
      .attr('font-size', '19px')
      .attr('font-weight', 'bold')
      .attr('font-family', 'monospace')
      .text(`${hitRate}%`);

    g.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '1.4em')
      .attr('fill', '#94a3b8')
      .attr('font-size', '9px')
      .attr('text-transform', 'uppercase')
      .attr('letter-spacing', '0.05em')
      .text(isArabic ? 'نسبة الإصابة' : 'Cache Hit');
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-6 shadow-sm">
      {/* Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-teal-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              {isArabic ? 'لوحة القياسات الحية والنبض الحي (D3.js Real-Time Telemetry)' : 'Live Metrics & Telemetry Dashboard'}
            </h3>
            <span className="flex items-center gap-1 text-[11px] font-mono bg-teal-500/10 text-teal-300 border border-teal-500/30 px-2 py-0.5 rounded">
              <span className={`w-1.5 h-1.5 rounded-full ${isRunning ? 'bg-teal-400 animate-ping' : 'bg-slate-500'}`}></span>
              <span>{isRunning ? 'Streaming D3' : 'Paused'}</span>
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {isArabic
              ? 'مراقبة حية لمعدل الطلبات في الثانية، مقارنة سرعة النماذج المختلفة، ونسبة نجاح التخزين المؤقت الدلالي (Redis).'
              : 'Interactive D3.js visualization of live request throughput, provider latency dynamics, and semantic cache velocity.'}
          </p>
        </div>

        {/* Live Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border transition font-medium ${
              isRunning
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                : 'bg-teal-600 hover:bg-teal-500 text-white border-teal-500'
            }`}
          >
            {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isRunning ? (isArabic ? 'إيقاف مؤقت' : 'Pause Stream') : (isArabic ? 'استئناف البث' : 'Resume Stream')}</span>
          </button>

          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
            <button
              onClick={() => setTrafficMode('low')}
              className={`px-2.5 py-1 rounded-md transition ${trafficMode === 'low' ? 'bg-slate-800 text-teal-300 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Low (5 rps)
            </button>
            <button
              onClick={() => setTrafficMode('normal')}
              className={`px-2.5 py-1 rounded-md transition ${trafficMode === 'normal' ? 'bg-slate-800 text-teal-300 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Normal (35 rps)
            </button>
            <button
              onClick={() => setTrafficMode('burst')}
              className={`px-2.5 py-1 rounded-md flex items-center gap-1 transition ${trafficMode === 'burst' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <Flame className="w-3 h-3 text-amber-400" />
              <span>Spike (150 rps)</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
            {isArabic ? 'إجمالي الطلبات المعالجة' : 'TOTAL REQUESTS'}
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-lg font-bold font-mono text-white">
              {kpis.totalRequests.toLocaleString()}
            </span>
            <span className="text-[10px] text-teal-400 font-mono">+100% OK</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
            {isArabic ? 'معدل التدفق الحالي' : 'CURRENT THROUGHPUT'}
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-lg font-bold font-mono text-teal-400">
              {kpis.currentRps}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">req/sec</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
            {isArabic ? 'زمن الاستجابة P95' : 'GLOBAL P95 LATENCY'}
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-lg font-bold font-mono text-amber-400">
              {kpis.p95Latency}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">ms</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
            {isArabic ? 'إصابة الكاش الدلالي' : 'CACHE HIT RATIO'}
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-lg font-bold font-mono text-emerald-400">
              {kpis.cacheHitRatio}%
            </span>
            <span className="text-[10px] text-slate-400 font-mono">&lt;15ms</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3 col-span-2 sm:col-span-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
            {isArabic ? 'توفير التكلفة بالـ API' : 'EST. COST SAVED'}
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-lg font-bold font-mono text-cyan-400">
              ${kpis.totalSavedUsd.toFixed(2)}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">USD</span>
          </div>
        </div>
      </div>

      {/* D3 Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Chart 1: Request Throughput Area Chart (5 Cols) */}
        <div className="lg:col-span-4 bg-slate-950 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-teal-400" />
              <span className="text-xs font-bold text-white">
                {isArabic ? 'تدفق الطلبات الحي (Live Req/s)' : 'Live Request Throughput'}
              </span>
            </div>
            <span className="text-[10px] font-mono text-teal-400 bg-teal-500/10 px-1.5 py-0.5 rounded">
              {kpis.currentRps} rps
            </span>
          </div>

          <div className="w-full overflow-hidden">
            <svg ref={throughputSvgRef} className="w-full h-[180px]"></svg>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-[10px] text-slate-500 font-mono">
            <span>Last 40s</span>
            <span>Real-time Window</span>
            <span>Now</span>
          </div>
        </div>

        {/* Chart 2: Provider Latency Multi-Line Chart (5 Cols) */}
        <div className="lg:col-span-5 bg-slate-950 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-white">
                {isArabic ? 'مقارنة سرعة المزودين (Model Latency)' : 'Provider Latency Dynamics'}
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">
              ms (lower is faster)
            </span>
          </div>

          <div className="w-full overflow-hidden">
            <svg ref={latencySvgRef} className="w-full h-[180px]"></svg>
          </div>

          {/* Interactive Legend to toggle series */}
          <div className="flex flex-wrap items-center justify-between gap-1.5 pt-2 border-t border-slate-900 text-[10px] font-mono">
            {[
              { id: 'cache', label: 'Cache (<15ms)', color: '#06b6d4' },
              { id: 'gemini', label: 'Gemini (~260ms)', color: '#10b981' },
              { id: 'openai', label: 'GPT-4o (~380ms)', color: '#3b82f6' },
              { id: 'claude', label: 'Claude (~520ms)', color: '#f59e0b' },
              { id: 'ollama', label: 'Ollama (~140ms)', color: '#a855f7' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() =>
                  setActiveProviders(prev => ({
                    ...prev,
                    [item.id]: !prev[item.id as keyof typeof prev]
                  }))
                }
                className={`flex items-center gap-1 px-1.5 py-0.5 rounded transition ${
                  activeProviders[item.id as keyof typeof activeProviders]
                    ? 'text-slate-300 hover:bg-slate-900'
                    : 'text-slate-600 line-through'
                }`}
              >
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></span>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Chart 3: Semantic Cache Donut & Velocity (3 Cols) */}
        <div className="lg:col-span-3 bg-slate-950 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-white">
                {isArabic ? 'كفاءة الكاش الدلالي' : 'Cache Efficiency'}
              </span>
            </div>
            <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded">
              Redis L1
            </span>
          </div>

          <div className="w-full flex items-center justify-center">
            <svg ref={cacheDonutSvgRef} className="w-full max-w-[200px] h-[180px]"></svg>
          </div>

          <div className="space-y-1 pt-2 border-t border-slate-900 text-[10px] font-mono text-slate-400">
            <div className="flex justify-between">
              <span>Cache Latency:</span>
              <strong className="text-cyan-400">11.4 ms</strong>
            </div>
            <div className="flex justify-between">
              <span>Speedup vs LLM:</span>
              <strong className="text-emerald-400">~95x Faster</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
