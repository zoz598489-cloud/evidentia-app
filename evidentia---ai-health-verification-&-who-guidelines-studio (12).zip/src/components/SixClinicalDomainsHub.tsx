import React from 'react';
import {
  Activity,
  Heart,
  Pill,
  Baby,
  Salad,
  ShieldCheck,
  Building2,
  ExternalLink,
  ChevronRight,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Sparkles
} from 'lucide-react';

export interface ClinicalDomain {
  id: string;
  nameEn: string;
  nameAr: string;
  authorityEn: string;
  authorityAr: string;
  iconName: string;
  descriptionEn: string;
  descriptionAr: string;
  criticalRuleEn: string;
  criticalRuleAr: string;
  commonMythEn: string;
  commonMythAr: string;
  verifiedFactEn: string;
  verifiedFactAr: string;
  evidenceLevel: string;
  sampleClaimForVerification: string;
  badgeColor: string;
}

export const SIX_CORE_DOMAINS: ClinicalDomain[] = [
  {
    id: "orthopedics",
    nameEn: "Sports Injuries & Orthopedics",
    nameAr: "1. طب العظام وإصابات الملاعب",
    authorityEn: "American Academy of Orthopaedic Surgeons (AAOS) / Cochrane Musculoskeletal",
    authorityAr: "الأكاديمية الأمريكية لجراحي العظام ومجموعة كوكرين للهيكل العظمي",
    iconName: "Activity",
    descriptionEn: "Acute ligament sprains, ankle inversion trauma, cryotherapy protocols, and preventing misdiagnosis between sprains and fractures.",
    descriptionAr: "التواءات الكاحل والأربطة الحادة، بروتوكولات RICE والكمادات الباردة، والتمييز الدقيق بين التواء الأربطة والكسور العظمية.",
    criticalRuleEn: "RICE Protocol: Ice application for 15-20 min in first 48 hours reduces swelling and pain. Conflating ligament sprains with fractures risks joint deformity.",
    criticalRuleAr: "بروتوكول RICE: وضع الثلج 15-20 دقيقة خلال أول 48 ساعة يقلل التورم. الخلط بين التواء الرباط والكسر العظمي يسبب تشوهات مفصلية.",
    commonMythEn: "A ligament sprain is identical to a fracture and requires the same rigid plaster cast immobilization.",
    commonMythAr: "الالتواء في المفصل مثله مثل الكسر العظمي ويحتاج جبيرة جبسية كاملة ومثبتة لأشهر.",
    verifiedFactEn: "Applying cold packs to an acute ankle sprain reduces swelling, pain, and tissue metabolism during the first 48 hours.",
    verifiedFactAr: "وضع الثلج على التواء الكاحل الحاد يقلل التورم والألم ونشاط الأنسجة خلال أول 48 ساعة.",
    evidenceLevel: "Oxford CEBM Level 1: Systematic Review",
    sampleClaimForVerification: "Applying ice to an acute ankle sprain reduces swelling and pain during the first 48 hours.",
    badgeColor: "emerald"
  },
  {
    id: "infectious_diseases",
    nameEn: "Infectious Diseases & Antimicrobial Resistance (AMR)",
    nameAr: "2. الأمراض المعدية ومقاومة مضادات الميكروبات",
    authorityEn: "World Health Organization (WHO) Global AMR / CDC",
    authorityAr: "منظمة الصحة العالمية (بروتوكول مقاومة المضادات الحيوية) و CDC",
    iconName: "ShieldCheck",
    descriptionEn: "Global surveillance of antimicrobial resistance, bacterial vs viral differentiation, hand hygiene standards, and sepsis response.",
    descriptionAr: "مكافحة مقاومة مضادات الميكروبات، التمييز بين العدوى الفيروسية والبكتيرية، تعقيم الأيدي، والتدخل السريع لحالات الإنتان.",
    criticalRuleEn: "Antibiotics ONLY kill bacteria. They are completely ineffective against viral infections (influenza, common cold, viral bronchitis).",
    criticalRuleAr: "المضادات الحيوية تستهدف الجدار الخلوي للبكتيريا فقط، ولا تؤثر إطلاقاً على الفيروسات كالإنفلونزا والبرد والتهاب الشعب الفيروسي.",
    commonMythEn: "Taking Amoxicillin or Azithromycin cures the flu and prevents viral colds from worsening.",
    commonMythAr: "تناول المضاد الحيوي مثل أوجمنتين أو زيثروماكس يعالج الإنفلونزا ويمنع تطور نزلة البرد.",
    verifiedFactEn: "Antibiotics are ineffective against viral infections such as the common cold, influenza, and viral bronchitis.",
    verifiedFactAr: "المضادات الحيوية غير فعالة إطلاقاً ضد العدوى الفيروسية مثل نزلات البرد والإنفلونزا والتهاب الشعب الفيروسي.",
    evidenceLevel: "Oxford CEBM Level 1: Universal WHO Practice Guideline",
    sampleClaimForVerification: "Antibiotics are ineffective against viral infections such as the common cold, influenza, and viral bronchitis.",
    badgeColor: "sky"
  },
  {
    id: "cardiology",
    nameEn: "Cardiology & Vascular Medicine",
    nameAr: "3. أمراض القلب والأوعية الدموية وضغط الدم",
    authorityEn: "World Health Organization (WHO) / American Heart Association (AHA)",
    authorityAr: "منظمة الصحة العالمية وجمعية القلب الأمريكية (AHA)",
    iconName: "Heart",
    descriptionEn: "Essential hypertension control, dietary sodium limits, myocardial infarction acute care, and ischemic stroke prevention.",
    descriptionAr: "السيطرة على ضغط الدم الأساسي، معايير تقليل الصوديوم في الغذاء، بروتوكولات الجلطة القلبية الحادة، والوقاية من السكتات.",
    criticalRuleEn: "Restricting daily sodium intake to < 2,000 mg/day (< 5g of salt) lowers systolic blood pressure and reduces stroke/MI risk.",
    criticalRuleAr: "خفض مدخول الصوديوم اليومي لأقل من 2,000 ملغ (أقل من 5 غرام ملح طعام) يخفض ضغط الدم الانقباضي ويقلل السكتات الدماغية.",
    commonMythEn: "Natural sea salt or pink Himalayan salt does not raise blood pressure and can be eaten in unlimited amounts.",
    commonMythAr: "ملح الهيمالايا الوردي والملح الصخري لا يرفع ضغط الدم إطلاقاً ويمكن تناوله بلا قيود.",
    verifiedFactEn: "Reducing sodium intake to less than 2,000 mg/day (less than 5 grams of salt per day) lowers blood pressure and cardiovascular disease risk.",
    verifiedFactAr: "توصي منظمة الصحة العالمية بخفض مدخول الصوديوم إلى أقل من 2000 ملغ/يوم (أقل من 5 غرام ملح) لخفض ضغط الدم المرتفع.",
    evidenceLevel: "Oxford CEBM Level 1: WHO Practice Guideline",
    sampleClaimForVerification: "Reducing sodium intake to less than 2,000 mg/day in adults significantly lowers blood pressure and cardiovascular risk.",
    badgeColor: "rose"
  },
  {
    id: "pharmacology",
    nameEn: "Pharmacology & Drug-Drug Interactions (DDI)",
    nameAr: "4. علم الأدوية وسلامة الدواء والتداخلات الدوائية",
    authorityEn: "US Food and Drug Administration (FDA) / RxNorm / EMA",
    authorityAr: "هيئة الغذاء والدواء الأمريكية (FDA) ووكالة الأدوية الأوروبية",
    iconName: "Pill",
    descriptionEn: "High-hazard medication co-administration, black box warnings, renal dosing adjustments, and anticoagulant hemorrhage risk.",
    descriptionAr: "التفاعلات الدوائية الحادة، تحذيرات الصندوق الأسود من FDA، ضبط الجرعات لمرضى الكلى، ومخاطر النزيف مع مميعات الدم.",
    criticalRuleEn: "Concomitant use of NSAIDs (Ibuprofen, Naproxen) with oral anticoagulants (Warfarin) exponentially multiplies gastrointestinal bleeding risk.",
    criticalRuleAr: "الجمع بين مضادات الالتهاب غير الستيرويدية (كالبروفين) ومسيلات الدم الفموية (كالوارفارين) يضاعف خطر النزيف الهضمي الحاد.",
    commonMythEn: "You can safely take Ibuprofen or Aspirin for headaches while on prescription blood thinners without telling your doctor.",
    commonMythAr: "يمكن تناول الإيبوبروفين والأسبرين بحرية لعلاج الصداع حتى لو كنت تتناول أدوية سيولة الدم دون استشارة الطبيب.",
    verifiedFactEn: "Concomitant use of nonsteroidal anti-inflammatory drugs (NSAIDs) with oral anticoagulants drastically elevates major gastrointestinal bleeding hazards.",
    verifiedFactAr: "تحذر هيئة الغذاء والدواء الأمريكية من أن الجمع بين المسكنات (NSAIDs) ومسيلات الدم (Warfarin) يرفع خطر النزيف الهضمي الحاد.",
    evidenceLevel: "Oxford CEBM Level 1: FDA Black Box Regulatory Warning",
    sampleClaimForVerification: "Concomitant use of nonsteroidal anti-inflammatory drugs with Warfarin drastically elevates major bleeding hazards.",
    badgeColor: "purple"
  },
  {
    id: "pediatrics",
    nameEn: "Pediatrics & Infant Child Health",
    nameAr: "5. طب الأطفال وصحة الرضع والنمو",
    authorityEn: "American Academy of Pediatrics (AAP) / WHO / UNICEF",
    authorityAr: "الأكاديمية الأمريكية لطب الأطفال (AAP) ومنظمة الصحة العالمية واليونيسيف",
    iconName: "Baby",
    descriptionEn: "Infant botulism prevention, exclusive breastfeeding recommendations, vaccination safety standards, and developmental milestones.",
    descriptionAr: "الوقاية من التسمم السجقي عند الرضع، الرضاعة الطبيعية المطلقة، أمان اللقاحات ونفي الشائعات، والمراحل النمائية للطفل.",
    criticalRuleEn: "Honey is strictly contraindicated for infants under 12 months due to Clostridium botulinum spores causing infant botulism.",
    criticalRuleAr: "يحظر إطعام العسل للرضع دون عمر 12 شهراً إطلاقاً بسبب احتواء العسل على أبواغ بكتيريا كلوستريديوم المسببة للتسمم السجقي.",
    commonMythEn: "Dipping an infant's pacifier in pure raw honey soothes newborn colic and improves digestion safely.",
    commonMythAr: "غمس لهاية الرضيع في العسل الطبيعي يهدئ المغص ويقوي مناعة المولود الجديد في أشهره الأولى.",
    verifiedFactEn: "Honey should never be fed to infants under 12 months of age due to the risk of infant botulism caused by Clostridium botulinum spores.",
    verifiedFactAr: "يحظر إطعام العسل للرضع دون عمر 12 شهراً إطلاقاً بسبب خطر التسمم السجقي (Infant Botulism) القاتل.",
    evidenceLevel: "Oxford CEBM Level 1: Universal Pediatric Advisory",
    sampleClaimForVerification: "Honey should never be fed to infants under 12 months of age due to the risk of infant botulism.",
    badgeColor: "amber"
  },
  {
    id: "food_safety",
    nameEn: "Food Safety & Foodborne Pathogens",
    nameAr: "6. سلامة الغذاء وميكروبيولوجيا التغذية",
    authorityEn: "USDA Food Safety Inspection Service (FSIS) / US FDA / WHO",
    authorityAr: "هيئة سلامة الغذاء الأمريكية (USDA / FDA) وإرشادات WHO لسلامة الأغذية",
    iconName: "Salad",
    descriptionEn: "Temperature danger zones, foodborne bacterial growth (Salmonella, Campylobacter, E. coli), cross-contamination, and cooking thresholds.",
    descriptionAr: "منطقة الخطر الحرارية للأطعمة، تكاثر بكتيريا السالمونيلا والكامبيلوباكتر، التلوث المتبادل، ودرجات حرارة الطهي الآمنة.",
    criticalRuleEn: "2-Hour Rule: Perishable cooked poultry or meats left in the danger zone (4°C - 60°C / 40°F - 140°F) for over 2 hours must be discarded.",
    criticalRuleAr: "قاعدة الساعتين: الأطعمة المطهوة واللحوم المتروكة في حرارة الغرفة (بين 4 و 60 مئوية) لأكثر من ساعتين يجب التخلص منها فوراً.",
    commonMythEn: "Reheating room-temperature cooked chicken to high heat completely destroys all bacterial toxins and makes it safe.",
    commonMythAr: "تسخين الدجاج المتروك طوال الليل على حرارة عالية يقتل كل البكتيريا ويجعله صالحاً للأكل تماماً.",
    verifiedFactEn: "Leaving cooked chicken at room temperature for over two hours allows rapid bacterial proliferation of Salmonella and Campylobacter.",
    verifiedFactAr: "ترك الدجاج المطهو في حرارة الغرفة لأكثر من ساعتين يؤدي لتكاثر سريع لبكتيريا السالمونيلا والكامبيلوباكتر وإفراز سموم مقاومة للحرارة.",
    evidenceLevel: "Oxford CEBM Level 1: Regulatory Standard",
    sampleClaimForVerification: "Leaving cooked chicken at room temperature for over two hours allows rapid proliferation of Salmonella.",
    badgeColor: "teal"
  }
];

export interface SixClinicalDomainsHubProps {
  isArabic: boolean;
  selectedDomainId?: string;
  onSelectDomain: (domainId: string) => void;
  onVerifyClaim: (claimText: string) => void;
}

export default function SixClinicalDomainsHub({
  isArabic,
  selectedDomainId,
  onSelectDomain,
  onVerifyClaim
}: SixClinicalDomainsHubProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950/60 to-slate-900 border border-teal-500/30 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-500/40 px-3 py-1 rounded-full flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                {isArabic ? "المجالات السريرية الستة المعتمدة" : "The 6 Core Clinical Domains"}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {isArabic ? "معايرة دقيقة ضد الهلوسة" : "Zero-Hallucination Calibrated"}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              {isArabic 
                ? "تخصص المنصة في المجالات الطبية الستة الأساسية ذات الخطورة العالية" 
                : "Calibrated Specifically for the 6 High-Stakes Clinical Domains"}
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              {isArabic
                ? "تم تدريب محرك Evidentia ونظامك السيادي الخاص ومعايرة مستودع المتجهات RAG ومحكمة الأدلة خصيصاً لتغطية هذه المجالات الستة الحيوية، حيث تؤدي النصيحة الخاطئة لأضرار سريرية مباشرة."
                : "Evidentia AI and your Sovereign Neural Core are rigorously benchmarked across these 6 high-stakes clinical domains, grounding every assertion in official WHO, Cochrane, and FDA guidelines."}
            </p>
          </div>
        </div>
      </div>

      {/* Domain Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {SIX_CORE_DOMAINS.map((domain) => {
          const isSelected = selectedDomainId === domain.id;
          return (
            <div
              key={domain.id}
              onClick={() => onSelectDomain(domain.id)}
              className={`rounded-2xl p-5 border transition flex flex-col justify-between cursor-pointer space-y-4 ${
                isSelected
                  ? 'bg-slate-900 border-teal-400 ring-2 ring-teal-500/30 shadow-xl'
                  : 'bg-slate-950/90 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold bg-teal-500/10 text-teal-300 border border-teal-500/30 px-2 py-0.5 rounded">
                    {domain.evidenceLevel.split(':')[0]}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">Domain #{domain.id}</span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white line-clamp-1">
                    {isArabic ? domain.nameAr : domain.nameEn}
                  </h3>
                  <span className="text-[11px] text-teal-400 font-medium block mt-0.5 line-clamp-1">
                    {isArabic ? domain.authorityAr : domain.authorityEn}
                  </span>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {isArabic ? domain.descriptionAr : domain.descriptionEn}
                </p>

                {/* Critical Rule Highlight */}
                <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-[11px] space-y-1">
                  <span className="text-amber-400 font-bold block flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-amber-400" />
                    <span>{isArabic ? "القاعدة السريرية المشددة:" : "Clinical Directive:"}</span>
                  </span>
                  <p className="text-slate-300 leading-relaxed font-mono line-clamp-2">
                    {isArabic ? domain.criticalRuleAr : domain.criticalRuleEn}
                  </p>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onVerifyClaim(domain.sampleClaimForVerification);
                  }}
                  className="text-xs text-teal-400 hover:text-teal-300 font-bold flex items-center gap-1 transition"
                >
                  <span>{isArabic ? "فحص ادعاء في هذا المجال" : "Test Domain in Court"}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <ChevronRight className={`w-4 h-4 text-slate-500 ${isSelected ? 'text-teal-400' : ''}`} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
