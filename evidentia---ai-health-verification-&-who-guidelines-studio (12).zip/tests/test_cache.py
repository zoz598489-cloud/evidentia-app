"""Unit tests for evidentia.cache (semantic vector caching)."""

import unittest
from evidentia.cache import SemanticCache

class TestSemanticCache(unittest.TestCase):
    def setUp(self):
        self.cache = SemanticCache(default_threshold=0.72)

    def test_cache_miss_then_hit(self):
        q1 = "Does applying ice to an acute ankle sprain reduce swelling?"
        cached, score = self.cache.lookup(q1)
        self.assertIsNone(cached)

        # Store response
        sample_res = {"verdict": "VERIFIED_ACCURATE", "match": "LIB-001"}
        self.cache.store(q1, sample_res)

        # Exact query lookup
        hit_res, sim = self.cache.lookup(q1)
        self.assertIsNotNone(hit_res)
        self.assertEqual(hit_res["verdict"], "VERIFIED_ACCURATE")
        self.assertEqual(sim, 1.0)

        # Semantically similar query lookup (should hit threshold >= 0.72)
        q2 = "Does ice on acute ankle sprains help reduce swelling?"
        similar_hit, sim2 = self.cache.lookup(q2)
        self.assertIsNotNone(similar_hit)
        self.assertGreaterEqual(sim2, 0.72)

    def test_cache_stats(self):
        stats = self.cache.get_stats()
        self.assertIn("hits", stats)
        self.assertIn("misses", stats)
        self.assertIn("hit_ratio", stats)

if __name__ == "__main__":
    unittest.main()
