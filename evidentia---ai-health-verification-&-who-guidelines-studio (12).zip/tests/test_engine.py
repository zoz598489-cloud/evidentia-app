"""Unit tests for evidentia.engine and intelligent abstention."""

import unittest
from evidentia.engine import VerificationEngine

class TestEngine(unittest.TestCase):
    def setUp(self):
        self.engine = VerificationEngine()

    def test_verified_accurate_claim(self):
        # Matches LIB-001 (ice on sprain)
        claim = "Applying ice to an acute ankle sprain reduces swelling and pain."
        res = self.engine.check_claim(claim)
        self.assertEqual(res["verdict"], "VERIFIED_ACCURATE")
        self.assertFalse(res["abstained"])
        self.assertGreaterEqual(res["match_score"], 0.50)

    def test_refuted_claim_with_negation(self):
        # Matches LIB-001 but user negates the affirmative truth
        claim = "Applying ice to an acute ankle sprain does not reduce swelling."
        res = self.engine.check_claim(claim)
        self.assertEqual(res["verdict"], "REFUTED")
        self.assertFalse(res["abstained"])

    def test_intelligent_abstention_on_unknown_claim(self):
        # Completely unknown claim outside indexed knowledge base
        claim = "Drinking warm celery juice through a copper straw cures all migraines permanently."
        res = self.engine.check_claim(claim)
        self.assertTrue(res["abstained"])
        self.assertIn("ABSTAIN", res["verdict"])
        self.assertIsNotNone(res["abstain_reason"])

    def test_full_post_verification_pipeline(self):
        post = "Applying ice to an acute ankle sprain reduces swelling. Also, leaving cooked chicken out at room temp for 4 hours is dangerous."
        res = self.engine.verify_full_post(post, use_cache=False)
        self.assertEqual(res["status"], "COMPLETED")
        self.assertEqual(res["claims_count"], 2)
        self.assertIn("overall_verdict", res)

if __name__ == "__main__":
    unittest.main()
