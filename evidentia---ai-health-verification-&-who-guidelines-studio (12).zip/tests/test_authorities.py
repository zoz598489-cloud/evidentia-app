"""
tests/test_authorities.py — Unit Tests for World Health Organization (WHO) and
Authoritative Global Health Bodies Connector & Search Engine.
"""

import unittest
from evidentia.authoritative_sources import AUTHORITATIVE_REGISTRY, CONNECTED_ORGANIZATIONS

class TestAuthoritativeSources(unittest.TestCase):
    def setUp(self):
        self.registry = AUTHORITATIVE_REGISTRY

    def test_connected_organizations_registry(self):
        orgs = self.registry.get_connected_organizations()
        self.assertGreaterEqual(len(orgs), 5)
        org_ids = [o["id"] for o in orgs]
        self.assertIn("WHO", org_ids)
        self.assertIn("CDC", org_ids)
        self.assertIn("COCHRANE", org_ids)
        self.assertIn("NIH_PUBMED", org_ids)
        self.assertIn("NICE", org_ids)

        # Check WHO details
        who = next(o for o in orgs if o["id"] == "WHO")
        self.assertEqual(who["tier"], 1)
        self.assertEqual(who["trust_score"], 100)
        self.assertTrue(who["portal_url"].startswith("https://www.who.int"))

    def test_who_antibiotic_resistance_guideline_search_en(self):
        results = self.registry.search("Do antibiotics work against viral influenza or colds?", top_k=2)
        self.assertGreater(len(results), 0)
        top = results[0]
        self.assertEqual(top["organization"], "WHO")
        self.assertIn("antimicrobial-resistance", top["official_url"])
        self.assertGreater(top["match_score"], 0.40)

    def test_who_antibiotic_resistance_guideline_search_ar(self):
        results = self.registry.search("هل المضادات الحيوية تعالج نزلات البرد الفيروسية والإنفلونزا؟", top_k=2)
        self.assertGreater(len(results), 0)
        top = results[0]
        self.assertEqual(top["organization"], "WHO")
        self.assertIn("منظمة الصحة العالمية", top["organization_full_ar"])

    def test_cochrane_and_cdc_sprain_cryotherapy(self):
        results = self.registry.search("Applying ice to acute ankle sprains reduces swelling and edema", top_k=3)
        self.assertGreater(len(results), 0)
        matched_orgs = [r["organization"] for r in results]
        self.assertTrue("COCHRANE" in matched_orgs or "CDC" in matched_orgs)

    def test_who_salt_reduction_hypertension(self):
        results = self.registry.search("تقليل الملح والصوديوم يقلل ضغط الدم والسكتات القلبية", top_k=2)
        self.assertGreater(len(results), 0)
        top = results[0]
        self.assertEqual(top["organization"], "WHO")
        self.assertIn("salt-reduction", top["official_url"])

    def test_verification_against_who_concurrence(self):
        res = self.registry.verify_against_who_and_authorities("Antibiotics do not kill influenza viruses")
        self.assertTrue(res["has_authoritative_grounding"])
        self.assertTrue(res["who_concurrence"]["concurred"])
        self.assertIsNotNone(res["primary_source"])
        self.assertTrue(res["primary_source"]["official_url"].startswith("https://www.who.int"))

if __name__ == "__main__":
    unittest.main()
