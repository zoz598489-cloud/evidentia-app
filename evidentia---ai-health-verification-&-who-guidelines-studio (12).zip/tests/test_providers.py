"""
tests/test_providers.py — Unit tests for Evidentia Multi-Model Orchestrator & Sovereign AI Engine.
"""
import unittest
import json
from evidentia.providers import (
    ORCHESTRATOR,
    EvidentiaUltraCustomAIProvider,
    MedPaLMConsensusProvider,
    CochraneMetaAnalyticJudgeProvider,
    ClinicalPharmacologyAgentProvider,
    PublicHealthEpidemiologyAgentProvider
)

class TestModelOrchestration(unittest.TestCase):
    def setUp(self):
        self.orchestrator = ORCHESTRATOR
        self.custom_engine = EvidentiaUltraCustomAIProvider()

    def test_ensemble_count_and_sovereign_core(self):
        # Must have at least 10 models in orchestrator
        self.assertGreaterEqual(len(self.orchestrator.providers), 10)
        self.assertIn("evidentia_ultra", self.orchestrator.providers)
        self.assertIn("medpalm", self.orchestrator.providers)
        self.assertIn("cochrane_judge", self.orchestrator.providers)
        self.assertIn("rx_agent", self.orchestrator.providers)
        self.assertIn("epidemiology_ai", self.orchestrator.providers)
        # Primary cascade order starts with evidentia_ultra
        self.assertEqual(self.orchestrator.cascade_order[0], "evidentia_ultra")

    def test_evidentia_ultra_who_grounding_refutes_antibiotics_for_viruses(self):
        res = self.custom_engine.generate("Antibiotics are necessary for viral colds and influenza.")
        data = json.loads(res["content"])
        self.assertEqual(data["stance"], "REFUTED")
        self.assertTrue(data["who_grounded"])
        self.assertGreaterEqual(data["confidence"], 0.95)

    def test_evidentia_ultra_supports_who_sodium_guideline(self):
        res = self.custom_engine.generate("Reducing sodium intake under 2000 mg/day lowers high blood pressure.")
        data = json.loads(res["content"])
        self.assertEqual(data["stance"], "SUPPORTED")
        self.assertTrue(data["who_grounded"])
        self.assertGreaterEqual(data["confidence"], 0.90)

    def test_specialized_clinical_subagents(self):
        # Cochrane Judge
        cochrane = CochraneMetaAnalyticJudgeProvider()
        res_c = cochrane.generate("Ice on acute ankle sprain reduces edema.")
        self.assertIn("SUPPORTED", res_c["content"])

        # RxNorm / FDA DDI Agent
        rx = ClinicalPharmacologyAgentProvider()
        res_rx = rx.generate("Combining high-dose NSAID with Warfarin causes severe bleeding.")
        self.assertIn("SUPPORTED", res_rx["content"])

        # Public Health Epidemiology Agent
        epi = PublicHealthEpidemiologyAgentProvider()
        res_epi = epi.generate("Leaving poultry at ambient temperature over two hours causes Salmonella outbreak.")
        self.assertIn("SUPPORTED", res_epi["content"])

    def test_orchestrator_execute_fallback(self):
        # Fallback cascade should resolve successfully
        res = self.orchestrator.execute_with_fallback(
            prompt="Does ice on sprained ankle reduce swelling?",
            preferred_provider="evidentia_ultra"
        )
        self.assertEqual(res["status"], "success")
        self.assertIn("evidentia_ultra", res["provider"])

if __name__ == "__main__":
    unittest.main()
