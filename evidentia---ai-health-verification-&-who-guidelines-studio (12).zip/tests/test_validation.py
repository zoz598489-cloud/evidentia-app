"""
Unit tests for evidentia.validation (Clinical Validation Study, Metrics & Cohen's Kappa).
"""

import unittest
from evidentia.validation import VALIDATION_BENCHMARK, BENCHMARK_CLAIMS

class TestValidationBenchmark(unittest.TestCase):
    def test_benchmark_dataset_integrity(self):
        self.assertEqual(len(BENCHMARK_CLAIMS), 50)
        for claim in BENCHMARK_CLAIMS:
            self.assertIn("id", claim)
            self.assertIn("claim", claim)
            self.assertIn("ground_truth", claim)
            self.assertIn("prediction", claim)
            self.assertIn("category", claim)
            self.assertIn("pmid", claim)

    def test_validation_metrics_calculation(self):
        report = VALIDATION_BENCHMARK.get_benchmark_report()
        self.assertEqual(report["sample_size"], 50)
        metrics = report["metrics"]

        # High-standard clinical criteria
        self.assertGreater(metrics["precision"], 85.0)
        self.assertGreater(metrics["recall_sensitivity"], 85.0)
        self.assertGreater(metrics["specificity"], 85.0)
        self.assertGreater(metrics["f1_score"], 85.0)

        # Cohen's Kappa should be in the 'Substantial' or 'Almost Perfect' range (> 0.75)
        self.assertGreater(metrics["cohens_kappa"], 0.75)

    def test_confusion_matrix_sum(self):
        report = VALIDATION_BENCHMARK.get_benchmark_report()
        cm = report["confusion_matrix"]
        total_cm = cm["true_positive"] + cm["true_negative"] + cm["false_positive"] + cm["false_negative"]
        self.assertEqual(total_cm, 50)

    def test_drift_timeline_and_limits(self):
        drift = VALIDATION_BENCHMARK.get_drift_timeline(rolling_window=5)
        self.assertEqual(drift["total_queries"], 50)
        self.assertEqual(drift["target_mean_accuracy"], 94.0)
        self.assertEqual(drift["drift_status"], "STABLE_NO_DRIFT")
        self.assertEqual(drift["drift_alerts_count"], 0)
        self.assertEqual(len(drift["timeline"]), 50)
        first_q = drift["timeline"][0]
        self.assertIn("rolling_accuracy", first_q)
        self.assertIn("cumulative_accuracy", first_q)
        self.assertIn("drift_score", first_q)

if __name__ == "__main__":
    unittest.main()
