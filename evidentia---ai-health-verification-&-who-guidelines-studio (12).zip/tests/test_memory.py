"""Unit tests for evidentia.memory (short-term & long-term conversation context)."""

import unittest
from evidentia.memory import ConversationSession, MemoryManager

class TestMemory(unittest.TestCase):
    def test_session_lifecycle(self):
        sess = ConversationSession(max_short_term_turns=2)
        sess.add_interaction("User says hi", "Assistant says hello")
        self.assertEqual(len(sess.short_term_buffer), 2)
        self.assertEqual(sess.long_term_summary, "")

    def test_buffer_compression_to_long_term_memory(self):
        sess = ConversationSession(max_short_term_turns=1)
        # Adding more turns triggers compression of oldest turns into long-term summary
        sess.add_interaction("Question 1 about ankle sprain", "Answer 1 about ice")
        sess.add_interaction("Question 2 about chicken temperature", "Answer 2 about 2 hours limit")
        sess.add_interaction("Question 3 about eczema cream", "Answer 3 about emollients")

        self.assertGreater(len(sess.long_term_summary), 0)
        self.assertIn("Question 1", sess.long_term_summary)
        context = sess.get_full_context_prompt()
        self.assertIn("Historical Conversation Summary", context)

    def test_memory_manager(self):
        mgr = MemoryManager()
        s1 = mgr.get_or_create_session("sess_alpha")
        s2 = mgr.get_or_create_session("sess_alpha")
        self.assertEqual(s1.session_id, s2.session_id)
        self.assertEqual(len(mgr.list_sessions()), 1)

if __name__ == "__main__":
    unittest.main()
