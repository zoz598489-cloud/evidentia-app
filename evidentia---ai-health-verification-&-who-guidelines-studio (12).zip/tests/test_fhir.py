"""
Unit tests for evidentia.fhir (HL7 FHIR R4 & Drug-Drug/Contraindication checker).
"""

import unittest
from evidentia.fhir import FHIR_ENGINE, SAMPLE_FHIR_PROFILES, KNOWN_CONTRAINDICATIONS

class TestFHIRIntegration(unittest.TestCase):
    def test_sample_profiles_structure(self):
        self.assertIn("PAT-01", SAMPLE_FHIR_PROFILES)
        self.assertIn("PAT-02", SAMPLE_FHIR_PROFILES)
        self.assertIn("PAT-03", SAMPLE_FHIR_PROFILES)
        self.assertIn("PAT-04", SAMPLE_FHIR_PROFILES)

        pat2 = SAMPLE_FHIR_PROFILES["PAT-02"]
        self.assertEqual(pat2["resourceType"], "Patient")
        self.assertTrue(len(pat2["conditions"]) > 0)
        self.assertTrue(len(pat2["medications"]) > 0)

    def test_healthy_patient_no_contraindications(self):
        pat1 = SAMPLE_FHIR_PROFILES["PAT-01"]
        result = FHIR_ENGINE.evaluate_claim_with_patient(
            claim_text="Applying ice to an acute ankle sprain reduces edema.",
            patient_profile=pat1
        )
        self.assertTrue(result["safe_for_patient"])
        self.assertEqual(result["alerts_count"], 0)

    def test_anticoagulated_patient_nsaid_interaction(self):
        # Patient 4 is on Warfarin (anticoagulant)
        pat4 = SAMPLE_FHIR_PROFILES["PAT-04"]
        result = FHIR_ENGINE.evaluate_claim_with_patient(
            claim_text="Take high-dose Ibuprofen or Aspirin for pain relief.",
            patient_profile=pat4
        )
        self.assertFalse(result["safe_for_patient"])
        self.assertTrue(result["alerts_count"] >= 1)
        categories = [a["category"] for a in result["alerts"]]
        self.assertIn("DRUG_DRUG_INTERACTION", categories)

    def test_asthma_patient_beta_blocker_contraindication(self):
        # Patient 3 has asthma
        pat3 = SAMPLE_FHIR_PROFILES["PAT-03"]
        result = FHIR_ENGINE.evaluate_claim_with_patient(
            claim_text="Start Propranolol (beta blocker) for stress reduction.",
            patient_profile=pat3
        )
        self.assertFalse(result["safe_for_patient"])
        categories = [a["category"] for a in result["alerts"]]
        self.assertIn("DISEASE_DRUG_CONTRAINDICATION", categories)

    def test_allergy_detection(self):
        # Patient 2 has severe Penicillin allergy
        pat2 = SAMPLE_FHIR_PROFILES["PAT-02"]
        result = FHIR_ENGINE.evaluate_claim_with_patient(
            claim_text="Take amoxicillin or penicillin for bacterial sore throat.",
            patient_profile=pat2
        )
        self.assertFalse(result["safe_for_patient"])
        categories = [a["category"] for a in result["alerts"]]
        self.assertIn("KNOWN_PATIENT_ALLERGY", categories)

if __name__ == "__main__":
    unittest.main()
