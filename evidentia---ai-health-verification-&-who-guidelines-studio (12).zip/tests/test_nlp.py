"""Unit tests for evidentia.nlp (compatible with Python 3.10, 3.11, 3.12)"""

import unittest
from evidentia.nlp import (
    normalize_text,
    tokenize,
    detect_negation,
    is_affirmatively_phrased,
    extract_medical_entities,
    calculate_entity_mismatch_penalty,
    split_claims,
    ChunkingStrategy
)

class TestNLP(unittest.TestCase):
    def test_normalization_english(self):
        raw = "Antibiotics Do Not Cure Cold!!"
        norm = normalize_text(raw)
        self.assertEqual(norm, "antibiotics do not cure cold")

    def test_normalization_arabic(self):
        raw = "المُضادّات الحَيَويّة لا تُعالِج الإنفلونزا!"
        norm = normalize_text(raw)
        # Tashkeel removed and alef normalized
        self.assertNotIn("ُ", norm)
        self.assertIn("المضادات الحيويه", norm)

    def test_detect_negation(self):
        self.assertTrue(detect_negation("Antibiotics do not work for viruses"))
        self.assertTrue(detect_negation("وضع الثلج ليس ضارا"))
        self.assertFalse(detect_negation("Ice reduces ankle swelling"))
        self.assertFalse(detect_negation("المضادات الحيوية مخصصة للبكتيريا"))

    def test_affirmative_phrasing_rule(self):
        # Evidentia design rule: library facts must be phrased affirmatively
        affirmative_fact = "Applying ice to an acute ankle sprain reduces swelling"
        negative_fact = "Never apply hot water to an acute ankle sprain"
        self.assertTrue(is_affirmatively_phrased(affirmative_fact))
        self.assertFalse(is_affirmatively_phrased(negative_fact))

    def test_entity_mismatch_penalty(self):
        claim_ents = extract_medical_entities("A sprain is as serious as a fracture")
        evidence_ents = extract_medical_entities("Applying ice to an acute ankle sprain reduces pain")
        penalty = calculate_entity_mismatch_penalty(claim_ents, evidence_ents)
        # 'fracture' is in claim but missing in evidence -> penalty > 0
        self.assertGreater(penalty, 0.0)

    def test_split_claims(self):
        text = "Ice helps sprains. Leaving chicken out causes Salmonella; antibiotics do not treat viruses."
        claims = split_claims(text)
        self.assertGreaterEqual(len(claims), 2)

    def test_chunking_strategies(self):
        text = "Fact one about orthopedics.\n\nFact two about food safety.\n\nFact three about skin diseases."
        paras = ChunkingStrategy.paragraph_boundary(text, min_chars=10)
        self.assertEqual(len(paras), 3)

        tokens_chunk = ChunkingStrategy.sliding_window("word " * 100, chunk_size=30, overlap=10)
        self.assertGreater(len(tokens_chunk), 2)

if __name__ == "__main__":
    unittest.main()
