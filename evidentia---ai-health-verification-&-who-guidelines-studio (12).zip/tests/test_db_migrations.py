"""Unit tests for evidentia.db migrations."""

import os
import tempfile
import unittest
from evidentia.db import MigrationRunner, get_connection

class TestMigrations(unittest.TestCase):
    def setUp(self):
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db.close()
        self.runner = MigrationRunner(db_path=self.temp_db.name)

    def tearDown(self):
        if os.path.exists(self.temp_db.name):
            os.remove(self.temp_db.name)

    def test_migration_lifecycle(self):
        # 1. Initially all migrations pending
        statuses = self.runner.status()
        self.assertGreaterEqual(len(statuses), 3)
        self.assertTrue(all(not s["applied"] for s in statuses))

        # 2. Run migrate up
        applied = self.runner.migrate_up()
        self.assertGreaterEqual(len(applied), 3)

        # 3. Status now all applied
        after_statuses = self.runner.status()
        self.assertTrue(all(s["applied"] for s in after_statuses))
        self.assertTrue(all(s["checksum_match"] is True for s in after_statuses))

        # 4. Verify tables exist in DB
        conn = get_connection(self.temp_db.name)
        cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row["name"] for row in cur.fetchall()]
        conn.close()

        self.assertIn("evidence_library", tables)
        self.assertIn("document_chunks", tables)
        self.assertIn("ai_audit_log", tables)
        self.assertIn("schema_migrations", tables)
        self.assertIn("evaluation_queries", tables)
        self.assertIn("clinical_evaluations", tables)

if __name__ == "__main__":
    unittest.main()
