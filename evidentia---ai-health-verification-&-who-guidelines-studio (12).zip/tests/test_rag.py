"""Unit tests for evidentia.rag and vector search."""

import unittest
from evidentia.rag import InMemoryVectorStore, DocumentChunk, RAGPipeline
from evidentia.embeddings import compute_cosine_similarity

class TestRAG(unittest.TestCase):
    def setUp(self):
        self.store = InMemoryVectorStore()
        self.doc1 = DocumentChunk("doc1", "Applying ice to an acute ankle sprain reduces swelling.")
        self.doc2 = DocumentChunk("doc2", "Salmonella bacteria grows quickly in warm cooked poultry.")
        self.store.add_documents([self.doc1, self.doc2])

    def test_vector_similarity(self):
        v1 = [1.0, 0.0, 0.0]
        v2 = [1.0, 0.0, 0.0]
        v3 = [0.0, 1.0, 0.0]
        self.assertAlmostEqual(compute_cosine_similarity(v1, v2), 1.0)
        self.assertAlmostEqual(compute_cosine_similarity(v1, v3), 0.0)

    def test_hybrid_search(self):
        results = self.store.search_hybrid("ice for ankle sprain", top_k=2)
        self.assertGreater(len(results), 0)
        self.assertEqual(results[0].doc.doc_id, "doc1")

    def test_rag_pipeline_ingest_and_retrieve(self):
        pipeline = RAGPipeline()
        ids = pipeline.ingest_document(
            text="Vitamin D deficiency can be diagnosed with a 25-hydroxy vitamin D blood test.\n\nAdequate sunlight and fortified foods support bone health.",
            title="Bone Health and Vitamin D",
            field="general_medicine",
            authority="Endocrine Society Clinical Guidelines"
        )
        self.assertGreater(len(ids), 0)
        retrieved = pipeline.retrieve_evidence_for_claim("blood test for vitamin D", top_k=1)
        self.assertGreater(len(retrieved), 0)
        self.assertIn("vitamin d", retrieved[0].doc.text.lower())

    def test_ingest_document_metadata_and_persistence(self):
        pipeline = RAGPipeline()
        result = pipeline.ingest_document(
            text="Early administration of intravenous crystalloid fluids is critical in pediatric septic shock.\nVasoactive infusions should be initiated if shock is fluid-refractory.",
            title="WHO 2024 Pediatric Sepsis Directive",
            field="pediatrics",
            authority="World Health Organization (WHO)",
            evidence_level="Level 1: Clinical Practice Guideline",
            chunk_strategy="semantic_claim"
        )
        self.assertTrue(hasattr(result, "document_id"))
        self.assertGreater(result.stats["total_tokens_est"], 10)
        self.assertEqual(result.title, "WHO 2024 Pediatric Sepsis Directive")

        # Test listing ingested documents
        docs = pipeline.get_ingested_documents()
        self.assertTrue(any(d.get("title") == "WHO 2024 Pediatric Sepsis Directive" or d.get("authority") == "World Health Organization (WHO)" for d in docs))

        # Test document deletion
        del_count = pipeline.delete_document(result.document_id)
        self.assertGreaterEqual(del_count, 1)

    def test_ingest_chunking_strategies(self):
        pipeline = RAGPipeline()
        text = "Section 1: Screening protocol. Section 2: Therapeutic management. Section 3: Adverse event monitoring."
        res_sw = pipeline.ingest_document(text, "Strategy Test SW", "general_medicine", "WHO", chunk_strategy="sliding_window")
        res_sc = pipeline.ingest_document(text, "Strategy Test SC", "general_medicine", "WHO", chunk_strategy="semantic_claim")
        res_pg = pipeline.ingest_document(text, "Strategy Test PG", "general_medicine", "WHO", chunk_strategy="paragraph")
        self.assertGreater(len(res_sw), 0)
        self.assertGreater(len(res_sc), 0)
        self.assertGreater(len(res_pg), 0)

if __name__ == "__main__":
    unittest.main()

